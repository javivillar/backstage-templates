"""Probes for Kubernetes: /health/live (the process answers) and /health/ready (so do the
things it depends on: each registered check)."""

from collections.abc import Awaitable, Callable

import structlog
from fastapi import APIRouter, Response

Check = Callable[[], Awaitable[None]]   # returns when healthy, raises when not
log = structlog.get_logger(__name__)


def health_router(checks: dict[str, Check]) -> APIRouter:
    router = APIRouter(prefix="/health", include_in_schema=False)

    @router.get("/live")
    async def live() -> dict[str, str]:
        return {"status": "ok"}

    @router.get("/ready")
    async def ready(response: Response) -> dict[str, object]:
        results: dict[str, str] = {}
        for name, check in checks.items():
            try:
                await check()
                results[name] = "ok"
            except Exception as exc:
                log.warning("readiness_check_failed", check=name, error=str(exc))
                results[name] = "failed"
        healthy = all(v == "ok" for v in results.values())
        if not healthy:
            response.status_code = 503
        return {"status": "ok" if healthy else "failed", "checks": results}

    return router
