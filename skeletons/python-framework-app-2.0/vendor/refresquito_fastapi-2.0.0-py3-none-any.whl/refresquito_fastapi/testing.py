"""Helpers to test a service built with the framework, without a Keycloak.

    tokens = TokenFactory()
    app = create_app(settings, routers=[router], token_verifier=tokens.verifier())

    async with client_for(app) as client:
        response = await client.get("/pets", headers=tokens.headers("ana", roles=["petstore-viewer"]))
        assert_problem(await client.get("/pets/999", headers=...), 404, "not_found")
"""

import json
import time
from typing import Any

import httpx
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import FastAPI

from .auth import TokenVerifier
from .errors import PROBLEM_JSON

TEST_ISSUER = "https://iam.test/realms/test"


class TokenFactory:
    """Signs tokens like a Keycloak realm would, with a key made for the test run."""

    def __init__(self, issuer: str = TEST_ISSUER, client_id: str | None = None) -> None:
        self.issuer = issuer
        self.client_id = client_id
        self.kid = "test-key"
        self._key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    @property
    def jwks(self) -> dict[str, Any]:
        jwk = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(self._key.public_key()))
        return {"keys": [{**jwk, "kid": self.kid, "use": "sig", "alg": "RS256"}]}

    def verifier(self, **options: Any) -> TokenVerifier:
        """A verifier that trusts this factory and never goes to the network."""
        options.setdefault("client_id", self.client_id)
        return TokenVerifier(self.issuer, jwks=self.jwks, **options)

    def token(
        self,
        username: str = "test-user",
        *,
        roles: list[str] | None = None,
        client_roles: list[str] | None = None,
        expires_in: int = 300,
        **claims: Any,
    ) -> str:
        now = int(time.time())
        payload: dict[str, Any] = {
            "iss": self.issuer,
            "sub": f"id-{username}",
            "preferred_username": username,
            "email": f"{username}@example.test",
            "iat": now,
            "exp": now + expires_in,
            "realm_access": {"roles": roles or []},
        }
        if client_roles and self.client_id:
            payload["resource_access"] = {self.client_id: {"roles": client_roles}}
        payload.update(claims)
        return jwt.encode(payload, self._key, algorithm="RS256", headers={"kid": self.kid})

    def headers(self, username: str = "test-user", **options: Any) -> dict[str, str]:
        """The Authorization header of a request made by that user."""
        return {"Authorization": f"Bearer {self.token(username, **options)}"}


def client_for(app: FastAPI, **options: Any) -> httpx.AsyncClient:
    """An HTTP client that calls the application in memory. Use it with `async with`."""
    options.setdefault("base_url", "http://test")
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), **options)


def assert_problem(response: httpx.Response, status: int, code: str | None = None) -> dict[str, Any]:
    """The answer is an error in the format of the framework; returns its body."""
    assert response.status_code == status, f"expected {status}, got {response.status_code}: {response.text}"
    assert response.headers["content-type"].startswith(PROBLEM_JSON), response.headers["content-type"]
    body: dict[str, Any] = response.json()
    assert body["status"] == status
    if code is not None:
        assert body["code"] == code, f"expected code {code}, got {body['code']}"
    return body
