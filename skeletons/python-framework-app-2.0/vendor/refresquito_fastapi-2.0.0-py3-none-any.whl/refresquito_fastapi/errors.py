"""Errors of a service and their one answer format: RFC 9457 problem details.

Raise an AppError (or a subclass) anywhere; the handlers turn it, validation errors, HTTP
errors and anything unexpected into the same JSON document:

    {"type": "about:blank", "title": "Not Found", "status": 404, "code": "not_found",
     "detail": "Pet 7 does not exist", "instance": "/pets/7", "request_id": "..."}
"""

from http import HTTPStatus
from typing import Any

import structlog
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

PROBLEM_JSON = "application/problem+json"
log = structlog.get_logger(__name__)


class AppError(Exception):
    """Base of the errors a service raises on purpose."""

    status: int = 500
    code: str = "internal_error"

    def __init__(self, detail: str | None = None, *, code: str | None = None, **extra: Any) -> None:
        super().__init__(detail or HTTPStatus(self.status).phrase)
        self.detail = detail
        if code:
            self.code = code
        self.extra = extra


class BadRequestError(AppError):
    status, code = 400, "bad_request"


class UnauthorizedError(AppError):
    status, code = 401, "unauthorized"


class ForbiddenError(AppError):
    status, code = 403, "forbidden"


class NotFoundError(AppError):
    status, code = 404, "not_found"


class ConflictError(AppError):
    status, code = 409, "conflict"


class ValidationError(AppError):
    status, code = 422, "validation_error"


def problem(request: Request, status: int, code: str, detail: str | None = None, **extra: Any) -> JSONResponse:
    body: dict[str, Any] = {
        "type": "about:blank",
        "title": HTTPStatus(status).phrase,
        "status": status,
        "code": code,
        "instance": request.url.path,
    }
    if detail:
        body["detail"] = detail
    request_id = getattr(request.state, "request_id", None)
    if request_id:
        body["request_id"] = request_id
    body.update(extra)
    headers = {"WWW-Authenticate": "Bearer"} if status == 401 else None
    return JSONResponse(body, status_code=status, media_type=PROBLEM_JSON, headers=headers)


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def app_error(request: Request, exc: AppError) -> JSONResponse:
        return problem(request, exc.status, exc.code, exc.detail, **exc.extra)

    @app.exception_handler(RequestValidationError)
    async def request_validation(request: Request, exc: RequestValidationError) -> JSONResponse:
        errors = [
            {"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]} for e in exc.errors()
        ]
        return problem(request, 422, "validation_error", "The request is not valid", errors=errors)

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = HTTPStatus(exc.status_code).phrase.lower().replace(" ", "_")
        detail = exc.detail if isinstance(exc.detail, str) and exc.detail != HTTPStatus(exc.status_code).phrase else None
        return problem(request, exc.status_code, code, detail)

    @app.exception_handler(Exception)
    async def unexpected(request: Request, exc: Exception) -> JSONResponse:
        # the cause goes to the log, never to the caller
        log.error("unhandled_error", exc_info=exc)
        return problem(request, 500, "internal_error", "Unexpected error")

    try:
        from sqlalchemy.exc import IntegrityError
    except ImportError:   # the service does not use the database extra
        return

    @app.exception_handler(IntegrityError)
    async def integrity(request: Request, exc: IntegrityError) -> JSONResponse:
        log.warning("integrity_error", error=str(exc.orig))
        return problem(request, 409, "conflict", "It conflicts with data that already exists")
