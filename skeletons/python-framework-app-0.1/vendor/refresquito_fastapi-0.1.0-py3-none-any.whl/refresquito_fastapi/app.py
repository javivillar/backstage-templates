"""create_app: a FastAPI application with everything of the framework already wired."""

from collections.abc import AsyncIterator, Callable, Sequence
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from typing import Any

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import metrics
from .auth import TokenVerifier
from .errors import install_error_handlers
from .health import Check, health_router
from .logging import RequestContextMiddleware, configure_logging
from .settings import Settings

Lifespan = Callable[[FastAPI], AbstractAsyncContextManager[None]]


def create_app(
    settings: Settings | None = None,
    *,
    title: str | None = None,
    version: str = "0.0.0",
    routers: Sequence[APIRouter] = (),
    readiness_checks: dict[str, Check] | None = None,
    lifespan: Lifespan | None = None,
    token_verifier: TokenVerifier | None = None,
    database: Any = None,
    **fastapi_options: Any,
) -> FastAPI:
    """Build the application of a service.

    It gets: JSON logs with a request ID, the error format, request metrics on /metrics, probes
    on /health, the token verifier of the Keycloak realm (if RQ_OIDC_ISSUER is set) and the
    database (if RQ_DATABASE_URL is set), each with its readiness check. `token_verifier` and
    `database` replace the ones built from the settings: that is how tests plug theirs in.
    """
    settings = settings or Settings()
    configure_logging(settings.log_level, settings.log_format, settings.app_name)

    checks: dict[str, Check] = dict(readiness_checks or {})
    if token_verifier is None and settings.oidc_issuer:
        token_verifier = TokenVerifier(
            settings.oidc_issuer,
            jwks_url=settings.oidc_jwks_url,
            audience=settings.oidc_audience,
            client_id=settings.oidc_client_id,
            ca_file=settings.oidc_ca_file,
        )
        checks.setdefault("oidc", token_verifier.ready)
    if database is None and settings.database_url:
        from .db import Database  # only with the [db] extra installed

        database = Database(settings.database_url)
    if database is not None:
        checks.setdefault("database", database.ping)

    @asynccontextmanager
    async def run(app: FastAPI) -> AsyncIterator[None]:
        try:
            if lifespan is not None:
                async with lifespan(app):
                    yield
            else:
                yield
        finally:
            if database is not None:
                await database.dispose()

    app = FastAPI(title=title or settings.app_name, version=version, lifespan=run, **fastapi_options)
    app.state.settings = settings
    app.state.token_verifier = token_verifier
    app.state.database = database

    install_error_handlers(app)
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,
            allow_methods=["*"],
            allow_headers=["*"],
            expose_headers=["X-Request-ID"],
        )
    # added last, so it is the outermost: it also sees what the other middleware answers
    app.add_middleware(RequestContextMiddleware, app_name=settings.app_name)

    app.include_router(health_router(checks))
    app.include_router(metrics.router)
    for router in routers:
        app.include_router(router)
    return app
