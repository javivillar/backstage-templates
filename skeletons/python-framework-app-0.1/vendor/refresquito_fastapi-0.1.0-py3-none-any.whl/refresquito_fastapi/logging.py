"""Structured logs: one JSON object per line, ready for Fluent Bit and Loki.

Every line written while a request is served carries its request_id. The request itself is
logged once, when it ends: method, path, status, duration and the user if it had a token.
"""

import logging
import sys
import time
import uuid
from collections.abc import Awaitable, Callable, MutableMapping
from typing import Any

import structlog

from . import metrics

Scope = MutableMapping[str, Any]
Message = MutableMapping[str, Any]
QUIET_PATHS = ("/health", "/metrics")   # probes and scrapes: no access log, no metrics


class _StdoutHandler(logging.StreamHandler):   # type: ignore[type-arg]
    """Writes to whatever sys.stdout is now, so a test that captures the output sees the logs."""

    @property
    def stream(self) -> Any:
        return sys.stdout

    @stream.setter
    def stream(self, value: Any) -> None:
        pass


def configure_logging(level: str = "INFO", fmt: str = "json", app_name: str = "service") -> None:
    shared: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
    ]
    renderer: Any = (
        structlog.dev.ConsoleRenderer() if fmt == "console" else structlog.processors.JSONRenderer()
    )
    structlog.configure(
        processors=[*shared, structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=False,
    )
    # the standard library loggers (uvicorn, sqlalchemy, the service's own) use the same format
    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.processors.format_exc_info,
            renderer,
        ],
    )
    handler = _StdoutHandler()
    handler.setFormatter(formatter)
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
    for name in ("uvicorn", "uvicorn.error"):
        logging.getLogger(name).handlers[:] = []
        logging.getLogger(name).propagate = True
    # one access line per request is written by RequestContextMiddleware
    logging.getLogger("uvicorn.access").handlers[:] = []
    logging.getLogger("uvicorn.access").propagate = False
    structlog.contextvars.clear_contextvars()
    structlog.contextvars.bind_contextvars(app=app_name)


class RequestContextMiddleware:
    """Request ID, access log and request metrics. Pure ASGI, so it adds no task per request."""

    def __init__(self, app: Callable[..., Awaitable[None]], app_name: str = "service") -> None:
        self.app = app
        self.app_name = app_name
        self.log = structlog.get_logger("access")

    async def __call__(self, scope: Scope, receive: Callable[..., Any], send: Callable[..., Any]) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
        request_id = headers.get("x-request-id") or uuid.uuid4().hex
        scope.setdefault("state", {})["request_id"] = request_id
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(app=self.app_name, request_id=request_id)
        status = 500
        start = time.perf_counter()

        async def send_with_id(message: Message) -> None:
            nonlocal status
            if message["type"] == "http.response.start":
                status = message["status"]
                message.setdefault("headers", []).append((b"x-request-id", request_id.encode()))
            await send(message)

        try:
            await self.app(scope, receive, send_with_id)
        finally:
            path = scope.get("path", "")
            if not path.startswith(QUIET_PATHS):
                seconds = time.perf_counter() - start
                # the route template (/pets/{pet_id}), so metrics do not grow with every ID
                route = getattr(scope.get("route"), "path", None) or "unmatched"
                metrics.observe(scope.get("method", ""), route, status, seconds)
                user = scope["state"].get("user")
                self.log.info(
                    "request",
                    method=scope.get("method"),
                    path=path,
                    status=status,
                    duration_ms=round(seconds * 1000, 1),
                    user=getattr(user, "username", None),
                )
