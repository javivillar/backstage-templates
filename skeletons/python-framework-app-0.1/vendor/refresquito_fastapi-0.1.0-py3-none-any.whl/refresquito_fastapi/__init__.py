"""refresquito-fastapi: what every FastAPI service of the Refresquito platform needs, once.

The database helpers are in refresquito_fastapi.db (extra `db`) and the test helpers in
refresquito_fastapi.testing.
"""

from .app import create_app
from .auth import CurrentUser, TokenVerifier, User, current_user, require_roles
from .errors import (
    AppError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    UnauthorizedError,
    ValidationError,
)
from .pagination import Page, PageParams, PageParamsDep
from .settings import Settings

__version__ = "0.1.0"
__all__ = [
    "AppError",
    "BadRequestError",
    "ConflictError",
    "CurrentUser",
    "ForbiddenError",
    "NotFoundError",
    "Page",
    "PageParams",
    "PageParamsDep",
    "Settings",
    "TokenVerifier",
    "UnauthorizedError",
    "User",
    "ValidationError",
    "create_app",
    "current_user",
    "require_roles",
]
