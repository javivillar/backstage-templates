"""Keycloak: who is calling, from the bearer token of the request.

The token is a JWT signed by the realm. It is validated here (signature against the keys of the
realm, issuer, expiry and audience) without calling Keycloak on each request: the keys are read
once and again only when a token arrives signed with an unknown one.

Audience (3.0): a token is for this service when its client (`azp`, the client that asked for it)
is the client of the service, or when the client of the service (or `audience`) is in its `aud`.
A token of another application of the same realm is refused (401, `invalid_audience`), whatever
its roles say.

    @router.get("/pets")
    async def list_pets(user: CurrentUser): ...

    @router.post("/pets", dependencies=[Depends(require_roles("petstore-admin"))])
    async def create_pet(...): ...
"""

import time
from typing import Annotated, Any

import httpx
import jwt
import structlog
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from .errors import ForbiddenError, UnauthorizedError

log = structlog.get_logger(__name__)
ALGORITHMS = ["RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "PS256"]
REFRESH_EVERY = 30.0   # seconds between two reads of the keys, at most


class User(BaseModel):
    """The caller, as its token describes it."""

    sub: str
    username: str
    email: str | None = None
    name: str | None = None
    roles: frozenset[str] = frozenset()   # realm roles plus the roles of the service's client
    claims: dict[str, Any] = {}

    def has_role(self, *roles: str) -> bool:
        """True if it has any of them."""
        return bool(self.roles.intersection(roles))


class TokenVerifier:
    def __init__(
        self,
        issuer: str,
        *,
        jwks_url: str | None = None,
        audience: str | None = None,
        client_id: str | None = None,
        ca_file: str | None = None,
        jwks: dict[str, Any] | None = None,
        verify_audience: bool = True,
    ) -> None:
        self.issuer = issuer.rstrip("/")
        self.jwks_url = jwks_url or f"{self.issuer}/protocol/openid-connect/certs"
        self.audience = audience
        self.client_id = client_id
        # who a token must be for: the client of the service and the extra audience; nobody named, nothing to check
        self.accepted = frozenset(a for a in (client_id, audience) if a) if verify_audience else frozenset()
        self._verify: str | bool = ca_file or True
        self._keys: dict[str, jwt.PyJWK] = {}
        self._static = jwks is not None   # keys given by the caller (tests): never fetched
        self._last_fetch = 0.0
        if jwks:
            self._load(jwks)

    def _load(self, jwks: dict[str, Any]) -> None:
        self._keys = {k["kid"]: jwt.PyJWK(k) for k in jwks.get("keys", []) if k.get("use", "sig") == "sig"}

    async def _refresh(self) -> None:
        if self._static or time.monotonic() - self._last_fetch < REFRESH_EVERY:
            return
        self._last_fetch = time.monotonic()
        try:
            async with httpx.AsyncClient(verify=self._verify, timeout=10) as client:
                response = await client.get(self.jwks_url)
                response.raise_for_status()
            self._load(response.json())
        except (httpx.HTTPError, ValueError) as exc:
            log.error("jwks_fetch_failed", url=self.jwks_url, error=str(exc))

    async def ready(self) -> None:
        """Readiness check: the keys of the realm can be read."""
        if not self._keys:
            self._last_fetch = 0.0
            await self._refresh()
        if not self._keys:
            raise RuntimeError(f"no signing keys from {self.jwks_url}")

    async def verify(self, token: str) -> User:
        try:
            kid = jwt.get_unverified_header(token).get("kid")
        except jwt.PyJWTError as exc:
            raise UnauthorizedError("The token is not a valid JWT") from exc
        if kid not in self._keys:
            await self._refresh()
        key = self._keys.get(kid)
        if key is None:
            raise UnauthorizedError("The token is signed with an unknown key")
        try:
            claims = jwt.decode(
                token,
                key.key,
                algorithms=ALGORITHMS,
                issuer=self.issuer,
                options={"verify_aud": False, "require": ["exp", "iss", "sub"]},
            )
        except jwt.ExpiredSignatureError as exc:
            raise UnauthorizedError("The token has expired", code="token_expired") from exc
        except jwt.PyJWTError as exc:
            raise UnauthorizedError(f"The token is not valid: {exc}") from exc
        if self.accepted and not self._for_me(claims):
            raise UnauthorizedError("The token was not issued for this service", code="invalid_audience")
        roles = set(claims.get("realm_access", {}).get("roles", []))
        if self.client_id:
            roles.update(claims.get("resource_access", {}).get(self.client_id, {}).get("roles", []))
        return User(
            sub=claims["sub"],
            username=claims.get("preferred_username") or claims["sub"],
            email=claims.get("email"),
            name=claims.get("name"),
            roles=frozenset(roles),
            claims=claims,
        )


    def _for_me(self, claims: dict[str, Any]) -> bool:
        aud = claims.get("aud") or []
        audiences = {aud} if isinstance(aud, str) else set(aud)
        return claims.get("azp") in self.accepted or bool(audiences & self.accepted)


_bearer = HTTPBearer(auto_error=False, description="Access token of the Keycloak realm")


async def current_user(
    request: Request, credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)]
) -> User:
    verifier: TokenVerifier | None = getattr(request.app.state, "token_verifier", None)
    if verifier is None:
        raise RuntimeError("No token verifier: set RQ_OIDC_ISSUER or pass token_verifier to create_app")
    if credentials is None:
        raise UnauthorizedError("Missing bearer token")
    user = await verifier.verify(credentials.credentials)
    request.state.user = user   # the access log reads it
    structlog.contextvars.bind_contextvars(user=user.username)
    return user


CurrentUser = Annotated[User, Depends(current_user)]


def require_roles(*roles: str) -> Any:
    """Dependency: the caller must have at least one of these roles."""

    async def check(user: CurrentUser) -> User:
        if not user.has_role(*roles):
            raise ForbiddenError(f"It needs one of these roles: {', '.join(roles)}")
        return user

    return check
