"""Helpers to test a service built with the framework, without a Keycloak.

    tokens = TokenFactory()
    app = create_app(settings, routers=[router], token_verifier=tokens.verifier())

    async with client_for(app) as client:
        response = await client.get("/pets", headers=tokens.headers("ana", roles=["petstore-viewer"]))
        assert_problem(await client.get("/pets/999", headers=...), 404, "not_found")

The platform blocks, in memory (no Camunda, Activepieces, S3 or Alfresco):

    processes = FakeProcesses()
    processes.deploy("review", tasks=["Review"])
    app = create_app(settings, routers=[router], token_verifier=..., platform=platform_with(processes))
    ...
    assert processes.started[0].business_key == "pet-1"
"""

import itertools
import json
import time
from collections.abc import Mapping
from typing import Any

import httpx
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import FastAPI

from .auth import TokenVerifier
from .errors import PROBLEM_JSON, NotFoundError, ServiceUnavailableError
from .platform import Block, Platform
from .platform.flows import FlowAnswer, Flows
from .platform.processes import Processes, ProcessInstance, Task

TEST_ISSUER = "https://iam.test/realms/test"


class TokenFactory:
    """Signs tokens like a Keycloak realm would, with a key made for the test run."""

    def __init__(self, issuer: str = TEST_ISSUER, client_id: str | None = None) -> None:
        self.issuer = issuer
        self.client_id = client_id
        self.kid = "test-key"
        self._key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    @property
    def jwks(self) -> dict[str, Any]:
        jwk = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(self._key.public_key()))
        return {"keys": [{**jwk, "kid": self.kid, "use": "sig", "alg": "RS256"}]}

    def verifier(self, **options: Any) -> TokenVerifier:
        """A verifier that trusts this factory and never goes to the network."""
        options.setdefault("client_id", self.client_id)
        return TokenVerifier(self.issuer, jwks=self.jwks, **options)

    def token(
        self,
        username: str = "test-user",
        *,
        roles: list[str] | None = None,
        client_roles: list[str] | None = None,
        expires_in: int = 300,
        **claims: Any,
    ) -> str:
        now = int(time.time())
        payload: dict[str, Any] = {
            "iss": self.issuer,
            "sub": f"id-{username}",
            "preferred_username": username,
            "email": f"{username}@example.test",
            "iat": now,
            "exp": now + expires_in,
            "realm_access": {"roles": roles or []},
        }
        if self.client_id:
            payload["azp"] = self.client_id   # issued for the service, as its web or Swagger UI gets them
        if client_roles and self.client_id:
            payload["resource_access"] = {self.client_id: {"roles": client_roles}}
        payload.update(claims)
        return jwt.encode(payload, self._key, algorithm="RS256", headers={"kid": self.kid})

    def headers(self, username: str = "test-user", **options: Any) -> dict[str, str]:
        """The Authorization header of a request made by that user."""
        return {"Authorization": f"Bearer {self.token(username, **options)}"}


def client_for(app: FastAPI, **options: Any) -> httpx.AsyncClient:
    """An HTTP client that calls the application in memory. Use it with `async with`."""
    options.setdefault("base_url", "http://test")
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), **options)


def assert_problem(response: httpx.Response, status: int, code: str | None = None) -> dict[str, Any]:
    """The answer is an error in the format of the framework; returns its body."""
    assert response.status_code == status, f"expected {status}, got {response.status_code}: {response.text}"
    assert response.headers["content-type"].startswith(PROBLEM_JSON), response.headers["content-type"]
    body: dict[str, Any] = response.json()
    assert body["status"] == status
    if code is not None:
        assert body["code"] == code, f"expected code {code}, got {body['code']}"
    return body


def platform_with(*blocks: Block) -> Platform:
    """The platform of a test: these blocks and no other (pass it to create_app(platform=...))."""
    return Platform({block.name: block for block in blocks})


class FakeProcesses(Processes):
    """The block processes in memory: processes deployed with deploy(), each user task of an instance an open task until
    completed; started, completed and correlated are kept to assert on."""

    def __init__(self, key_prefix: str = "app-") -> None:
        self.prefix = key_prefix
        self.deployed: dict[str, list[str]] = {}
        self.decisions: dict[str, list[dict[str, Any]]] = {}
        self.started: list[ProcessInstance] = []
        self.completed: list[tuple[str, dict[str, Any]]] = []
        self.messages: list[tuple[str, str | None, dict[str, Any]]] = []
        self._variables: dict[str, dict[str, Any]] = {}
        self._tasks: list[Task] = []
        self._ids = itertools.count(1)

    def deploy(self, process: str, *, tasks: list[str] | tuple[str, ...] = ()) -> None:
        """A process of the application, whose instances wait in these user tasks (one after the other)."""
        self.deployed[self.key(process)] = list(tasks)

    def decision(self, name: str, rows: list[dict[str, Any]]) -> None:
        """A decision of the application and what its evaluation returns."""
        self.decisions[self.key(name)] = rows

    async def start(self, process: str, *, business_key: str | None = None,
                    variables: Mapping[str, Any] | None = None) -> ProcessInstance:
        key = self.key(process)
        if key not in self.deployed:
            raise NotFoundError(f"The process {key} is not deployed (platform/processes/ of the application)",
                                code="process_not_found")
        instance = ProcessInstance(id=f"instance-{next(self._ids)}", process=key, business_key=business_key)
        self.started.append(instance)
        self._variables[instance.id] = dict(variables or {})
        self._open_next(instance, 0)
        return instance

    def _open_next(self, instance: ProcessInstance, index: int) -> None:
        tasks = self.deployed[instance.process]
        if index < len(tasks):
            self._tasks.append(Task(id=f"task-{next(self._ids)}", name=tasks[index], task=tasks[index],
                                    process_instance=instance.id))
        else:
            instance.ended = True

    async def instances(self, process: str | None = None, *, business_key: str | None = None) -> list[ProcessInstance]:
        return [i for i in self.started if not i.ended and (process is None or i.process == self.key(process))
                and (business_key is None or i.business_key == business_key)]

    async def variables(self, instance_id: str) -> dict[str, Any]:
        if instance_id not in self._variables:
            raise NotFoundError(f"The process instance {instance_id} does not exist (or has ended)",
                                code="process_not_found")
        return dict(self._variables[instance_id])

    async def correlate(self, message: str, *, business_key: str | None = None,
                        variables: Mapping[str, Any] | None = None) -> None:
        self.messages.append((message, business_key, dict(variables or {})))

    async def tasks(self, *, process: str | None = None, business_key: str | None = None, assignee: str | None = None,
                    candidate_user: str | None = None, candidate_group: str | None = None) -> list[Task]:
        instances = {i.id: i for i in self.started}
        return [t for t in self._tasks
                if (process is None or instances[t.process_instance].process == self.key(process))
                and (business_key is None or instances[t.process_instance].business_key == business_key)
                and (assignee is None or t.assignee == assignee)
                # the inbox of a person: assigned to them, or to nobody yet (offered)
                and (candidate_user is None or t.assignee in (None, candidate_user))]

    async def claim(self, task_id: str, user: str) -> None:
        self._task(task_id).assignee = user

    async def complete(self, task_id: str, variables: Mapping[str, Any] | None = None) -> None:
        task = self._task(task_id)
        self._tasks.remove(task)
        self.completed.append((task_id, dict(variables or {})))
        instance = next(i for i in self.started if i.id == task.process_instance)
        self._variables[instance.id].update(variables or {})
        self._open_next(instance, self.deployed[instance.process].index(task.task) + 1)

    async def decide(self, decision: str, variables: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        key = self.key(decision)
        if key not in self.decisions:
            raise NotFoundError(f"The decision {key} is not deployed (platform/processes/ of the application)",
                                code="process_not_found")
        return [dict(row) for row in self.decisions[key]]

    def _task(self, task_id: str) -> Task:
        task = next((t for t in self._tasks if t.id == task_id), None)
        if task is None:
            raise NotFoundError(f"The task {task_id} does not exist (or is done)", code="process_not_found")
        return task

    async def check(self) -> None:
        return None

    async def close(self) -> None:
        return None


class FakeFlows(Flows):
    """The block flows in memory: the flows available (published) and what each answers when waited for; every trigger
    is kept to assert on."""

    def __init__(self, answers: Mapping[str, Any] | None = None) -> None:
        self.answers: dict[str, Any] = dict(answers or {})
        self.urls = {name: f"http://activepieces.test/api/v1/webhooks/{name}" for name in self.answers}
        self.triggered: list[tuple[str, Any, bool]] = []

    async def trigger(self, flow: str, data: Any = None, *, wait: bool = False,
                      headers: Mapping[str, str] | None = None) -> FlowAnswer:
        if flow not in self.answers:
            raise ServiceUnavailableError(f"The flow {flow} is not available", code="flow_not_available")
        self.triggered.append((flow, data, wait))
        return FlowAnswer(status=200, body=self.answers[flow] if wait else None)

    async def check(self) -> None:
        return None

    async def close(self) -> None:
        return None


class FakeBucket:
    """A bucket in memory, with the methods of refresquito_fastapi.platform.s3.Bucket."""

    def __init__(self, name: str, full_name: str) -> None:
        self.name, self.full_name = name, full_name
        self.objects: dict[str, tuple[bytes, str | None, dict[str, str]]] = {}

    async def put(self, key: str, data: Any, *, content_type: str | None = None,
                  metadata: Mapping[str, str] | None = None) -> Any:
        from .platform.s3 import ObjectInfo

        content = data if isinstance(data, bytes | bytearray) else data.read()
        self.objects[key] = (bytes(content), content_type, dict(metadata or {}))
        return ObjectInfo(key=key, size=len(content), content_type=content_type, metadata=dict(metadata or {}))

    async def head(self, key: str) -> Any:
        from .platform.s3 import ObjectInfo

        if key not in self.objects:
            raise NotFoundError(f"There is no object {key} in the bucket {self.name}", code="object_not_found")
        content, content_type, metadata = self.objects[key]
        return ObjectInfo(key=key, size=len(content), content_type=content_type, metadata=metadata)

    async def get(self, key: str) -> Any:
        from .platform.s3 import StoredObject

        return StoredObject(info=await self.head(key), content=self.objects[key][0])

    async def exists(self, key: str) -> bool:
        return key in self.objects

    async def delete(self, key: str) -> None:
        self.objects.pop(key, None)

    async def list(self, prefix: str = "", *, limit: int = 1000) -> list[Any]:
        return [await self.head(k) for k in sorted(self.objects) if k.startswith(prefix)][:limit]

    def download_url(self, key: str, *, expires: int = 300, filename: str | None = None) -> str:
        return f"https://s3.test/{self.full_name}/{key}?expires={expires}"

    def upload_url(self, key: str, *, expires: int = 300, content_type: str | None = None) -> str:
        return f"https://s3.test/{self.full_name}/{key}?upload&expires={expires}"


class FakeStorage(Block):
    """The block s3 in memory: FakeStorage(["documents"]) declares the bucket documents (app-documents)."""

    name = "s3"

    def __init__(self, buckets: list[str] | tuple[str, ...] = ("documents",), app: str = "app") -> None:
        self.buckets = {b: FakeBucket(b, f"{app}-{b}") for b in buckets}

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "FakeStorage":
        return cls()

    def bucket(self, name: str) -> FakeBucket:
        from .errors import AppError

        if name not in self.buckets:
            raise AppError(f"The application declares no bucket {name}", code="bucket_not_declared")
        return self.buckets[name]


class FakeSite:
    """An Alfresco site in memory, with the methods of refresquito_fastapi.platform.dms.Site."""

    def __init__(self, name: str, site_id: str) -> None:
        self.name, self.site_id = name, site_id
        self.documents: dict[str, tuple[Any, bytes]] = {}
        self._ids = itertools.count(1)

    @staticmethod
    def folder(entity: str, entity_id: Any) -> str:
        return f"{entity}/{entity_id}"

    async def library(self) -> str:
        return f"library-{self.site_id}"

    async def upload(self, name: str, content: bytes, *, folder: str = "", content_type: str | None = None,
                     title: str | None = None, description: str | None = None, overwrite: bool = True) -> Any:
        from .errors import ConflictError
        from .platform.dms import Document

        same = next((d for d, _ in self.documents.values() if d.folder == folder and d.name == name), None)
        if same is not None and not overwrite:
            raise ConflictError(f"{name} exists", code="document_exists")
        document = Document(id=same.id if same else f"doc-{next(self._ids)}", name=name, folder=folder,
                            mime_type=content_type, size=len(content), title=title, description=description)
        self.documents[document.id] = (document, content)
        return document

    async def list(self, folder: str = "") -> list[Any]:
        return sorted((d for d, _ in self.documents.values() if d.folder == folder), key=lambda d: d.name)

    async def get(self, document_id: str) -> Any:
        if document_id not in self.documents:
            raise NotFoundError(f"There is no document {document_id} in the site {self.name}", code="document_not_found")
        return self.documents[document_id][0]

    async def content(self, document_id: str) -> Any:
        from .platform.dms import Content

        return Content(document=await self.get(document_id), content=self.documents[document_id][1])

    async def delete(self, document_id: str) -> None:
        await self.get(document_id)
        del self.documents[document_id]


class FakeDocuments(Block):
    """The block dms in memory: FakeDocuments(["records"]) declares the site records (app-records)."""

    name = "dms"

    def __init__(self, sites: list[str] | tuple[str, ...] = ("records",), app: str = "app") -> None:
        self.sites = {s: FakeSite(s, f"{app}-{s}") for s in sites}

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "FakeDocuments":
        return cls()

    def site(self, name: str) -> FakeSite:
        from .errors import AppError

        if name not in self.sites:
            raise AppError(f"The application declares no site {name}", code="site_not_declared")
        return self.sites[name]
