"""Database: an async SQLAlchemy session per request. Needs the extra: refresquito-fastapi[db].

    class Pet(Base): ...

    @router.get("/pets")
    async def list_pets(session: SessionDep, params: PageParamsDep) -> Page[PetOut]:
        return await paginate(session, select(Pet).order_by(Pet.id), params)

The session commits when the request ends well and rolls back when it raises.
"""

from collections.abc import AsyncIterator
from typing import Annotated, Any

from fastapi import Depends, Request
from sqlalchemy import MetaData, Select, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from .pagination import Page, PageParams

# constraint names that do not depend on the database, so Alembic can drop what it created
NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)


class Database:
    def __init__(self, url: str, **engine_options: Any) -> None:
        self.engine = create_async_engine(url, pool_pre_ping=True, **engine_options)
        self.sessions = async_sessionmaker(self.engine, expire_on_commit=False)

    async def ping(self) -> None:
        """Readiness check: the database answers."""
        async with self.engine.connect() as connection:
            await connection.execute(text("SELECT 1"))

    async def create_all(self, base: type[DeclarativeBase] = Base) -> None:
        """Create the tables from the models. For tests; a deployed service uses Alembic."""
        async with self.engine.begin() as connection:
            await connection.run_sync(base.metadata.create_all)

    async def drop_all(self, base: type[DeclarativeBase] = Base) -> None:
        async with self.engine.begin() as connection:
            await connection.run_sync(base.metadata.drop_all)

    async def dispose(self) -> None:
        await self.engine.dispose()


async def get_session(request: Request) -> AsyncIterator[AsyncSession]:
    database: Database | None = getattr(request.app.state, "database", None)
    if database is None:
        raise RuntimeError("No database: set RQ_DATABASE_URL or pass database to create_app")
    async with database.sessions() as session:
        try:
            yield session
            await session.commit()
        except BaseException:
            await session.rollback()
            raise


SessionDep = Annotated[AsyncSession, Depends(get_session)]


async def paginate(session: AsyncSession, statement: Select[Any], params: PageParams) -> Page[Any]:
    """Run a SELECT of one entity as a page: its rows and the total without paging."""
    total = await session.scalar(select(func.count()).select_from(statement.order_by(None).subquery()))
    rows = await session.scalars(statement.limit(params.size).offset(params.offset))
    return Page(items=list(rows), total=total or 0, page=params.page, size=params.size)
