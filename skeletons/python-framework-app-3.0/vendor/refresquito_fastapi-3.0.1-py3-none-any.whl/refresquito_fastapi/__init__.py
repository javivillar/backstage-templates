"""refresquito-fastapi: what every FastAPI service of the Refresquito platform needs, once.

The database helpers are in refresquito_fastapi.db (extra `db`), the platform blocks the application
declares in refresquito_fastapi.platform, and the test helpers in refresquito_fastapi.testing.
"""

from .app import create_app
from .audit import audit
from .auth import CurrentUser, TokenVerifier, User, current_user, require_roles
from .errors import (
    AppError,
    BadGatewayError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    ServiceUnavailableError,
    UnauthorizedError,
    ValidationError,
)
from .pagination import Page, PageParams, PageParamsDep
from .settings import Settings

__version__ = "3.0.1"
__all__ = [
    "AppError",
    "BadGatewayError",
    "BadRequestError",
    "ConflictError",
    "CurrentUser",
    "ForbiddenError",
    "NotFoundError",
    "Page",
    "PageParams",
    "PageParamsDep",
    "ServiceUnavailableError",
    "Settings",
    "TokenVerifier",
    "UnauthorizedError",
    "User",
    "ValidationError",
    "audit",
    "create_app",
    "current_user",
    "require_roles",
]
