"""Pages of a list: the query parameters and the answer."""

from typing import Annotated

from fastapi import Depends, Query
from pydantic import BaseModel


class PageParams:
    def __init__(
        self,
        page: Annotated[int, Query(ge=1, description="Page number, from 1")] = 1,
        size: Annotated[int, Query(ge=1, le=100, description="Items per page")] = 20,
    ) -> None:
        self.page = page
        self.size = size

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.size


PageParamsDep = Annotated[PageParams, Depends()]


class Page[T](BaseModel):
    items: list[T]
    total: int
    page: int
    size: int
