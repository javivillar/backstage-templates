"""Block `s3`: the buckets the application declares, in the S3 of the platform (SeaweedFS). Extra `s3` (boto3).

    from refresquito_fastapi.platform.s3 import StorageDep

    @router.post("/pets/{pet_id}/photo", status_code=201)
    async def upload_photo(pet_id: int, file: UploadFile, storage: StorageDep):
        content = await file.read()
        info = await storage.bucket("documents").put(f"pets/{pet_id}/photo", content, content_type=file.content_type)
        return {"key": info.key, "size": info.size}

    @router.get("/pets/{pet_id}/photo")
    async def photo(pet_id: int, storage: StorageDep):
        return RedirectResponse(storage.bucket("documents").download_url(f"pets/{pet_id}/photo"))

A bucket is named as declared: `documents` is the bucket <app>[-<stage>]-documents (S3_BUCKET_DOCUMENTS). The
application uploads through its API (`put`) and hands out presigned URLs to download (`download_url`), signed for the
S3 a browser reaches (AWS_ENDPOINT_URL_S3_PUBLIC). `upload_url` gives a presigned URL to upload from a browser
straight to S3, which needs the bucket to allow the origin of the application (CORS). Writes are audited.
"""

import datetime as dt
from collections.abc import Mapping
from typing import IO, Annotated, Any, Self

import anyio
from fastapi import Depends
from pydantic import BaseModel

from ..audit import audit
from ..errors import AppError, BadGatewayError, NotFoundError, ServiceUnavailableError
from . import Block, block_dependency, contract, register
from ._calls import instrumented

try:
    import boto3
    from botocore.client import Config
    from botocore.exceptions import BotoCoreError, ClientError, EndpointConnectionError
except ModuleNotFoundError as exc:   # the extra is missing: said when the block is declared
    raise ModuleNotFoundError(f"No module named '{exc.name}'", name=exc.name) from exc

PATTERN = "S3_BUCKET_<NAME>"
CONFIG = Config(
    signature_version="s3v4",
    s3={"addressing_style": "path"},             # SeaweedFS: http://host/<bucket>/<key>
    # boto3 >= 1.36 adds checksums S3-compatible servers do not all know; only when an operation requires them
    request_checksum_calculation="when_required",
    response_checksum_validation="when_required",
    retries={"max_attempts": 2, "mode": "standard"},
    connect_timeout=5,
    read_timeout=60,
)


class ObjectInfo(BaseModel):
    key: str
    size: int | None = None
    content_type: str | None = None
    etag: str | None = None
    last_modified: dt.datetime | None = None
    metadata: dict[str, str] = {}


class StoredObject(BaseModel):
    info: ObjectInfo
    content: bytes


def bucket_name(key: str) -> str:
    """DOCUMENTS -> documents, BIG_FILES -> big-files."""
    return key.lower().replace("_", "-")


class Bucket:
    """One bucket of the application."""

    def __init__(self, storage: "Storage", name: str, full_name: str) -> None:
        self.storage, self.name, self.full_name = storage, name, full_name

    async def _run(self, operation: str, function: Any, /, **kwargs: Any) -> Any:
        async with instrumented("s3", operation):
            try:
                return await anyio.to_thread.run_sync(lambda: function(Bucket=self.full_name, **kwargs))
            except ClientError as exc:
                raise _error(exc, self, kwargs.get("Key")) from exc
            except EndpointConnectionError as exc:
                raise ServiceUnavailableError("s3: the service does not answer", code="s3_unavailable") from exc
            except BotoCoreError as exc:
                raise BadGatewayError(f"s3: {exc}", code="s3_error") from exc

    async def put(self, key: str, data: bytes | IO[bytes], *, content_type: str | None = None,
                  metadata: Mapping[str, str] | None = None) -> ObjectInfo:
        """Store an object (replacing the one with that key)."""
        extra: dict[str, Any] = {"Metadata": dict(metadata or {})}
        if content_type:
            extra["ContentType"] = content_type
        answer = await self._run("put", self.storage.client.put_object, Key=key, Body=data, **extra)
        size = len(data) if isinstance(data, bytes | bytearray) else None
        audit("s3.put", resource=f"s3://{self.full_name}/{key}", size=size, content_type=content_type)
        return ObjectInfo(key=key, size=size, content_type=content_type, etag=_etag(answer), metadata=dict(metadata or {}))

    async def get(self, key: str) -> StoredObject:
        """An object and its content (read whole: for large ones, hand out download_url instead)."""
        answer = await self._run("get", self.storage.client.get_object, Key=key)
        content = await anyio.to_thread.run_sync(answer["Body"].read)
        return StoredObject(info=_info(key, answer), content=content)

    async def head(self, key: str) -> ObjectInfo:
        return _info(key, await self._run("head", self.storage.client.head_object, Key=key))

    async def exists(self, key: str) -> bool:
        try:
            await self.head(key)
            return True
        except NotFoundError:
            return False

    async def delete(self, key: str) -> None:
        await self._run("delete", self.storage.client.delete_object, Key=key)
        audit("s3.delete", resource=f"s3://{self.full_name}/{key}")

    async def list(self, prefix: str = "", *, limit: int = 1000) -> list[ObjectInfo]:
        answer = await self._run("list", self.storage.client.list_objects_v2, Prefix=prefix, MaxKeys=limit)
        return [ObjectInfo(key=o["Key"], size=o.get("Size"), etag=_etag(o), last_modified=o.get("LastModified"))
                for o in answer.get("Contents", [])]

    def download_url(self, key: str, *, expires: int = 300, filename: str | None = None) -> str:
        """A presigned URL a browser can GET for `expires` seconds (the S3 a browser reaches). `filename` makes the
        browser save it with that name."""
        params: dict[str, Any] = {"Bucket": self.full_name, "Key": key}
        if filename:
            params["ResponseContentDisposition"] = f'attachment; filename="{filename}"'
        return self.storage.public.generate_presigned_url("get_object", Params=params, ExpiresIn=expires)

    def upload_url(self, key: str, *, expires: int = 300, content_type: str | None = None) -> str:
        """A presigned URL a browser can PUT the object to (the bucket must allow the origin of the application: CORS).
        With `content_type`, the upload must send that Content-Type."""
        params: dict[str, Any] = {"Bucket": self.full_name, "Key": key}
        if content_type:
            params["ContentType"] = content_type
        audit("s3.upload_url", resource=f"s3://{self.full_name}/{key}", expires=expires)
        return self.storage.public.generate_presigned_url("put_object", Params=params, ExpiresIn=expires)


@register
class Storage(Block):
    name = "s3"

    def __init__(self, endpoint: str, access_key: str, secret_key: str, region: str, buckets: Mapping[str, str],
                 public_endpoint: str | None = None) -> None:
        session = boto3.session.Session(aws_access_key_id=access_key, aws_secret_access_key=secret_key, region_name=region)
        self.client = session.client("s3", endpoint_url=endpoint, config=CONFIG)
        self.public = session.client("s3", endpoint_url=public_endpoint or endpoint, config=CONFIG)
        self.buckets = {bucket_name(k): Bucket(self, bucket_name(k), full) for k, full in buckets.items()}

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        v = contract.read(env, "s3")
        return cls(v["AWS_ENDPOINT_URL_S3"], v["AWS_ACCESS_KEY_ID"], v["AWS_SECRET_ACCESS_KEY"], v["AWS_DEFAULT_REGION"],
                   contract.items(env, PATTERN), v.get("AWS_ENDPOINT_URL_S3_PUBLIC"))

    def bucket(self, name: str) -> Bucket:
        """A bucket by the name it is declared with (documents)."""
        bucket = self.buckets.get(name)
        if bucket is None:
            raise AppError(f"The application declares no bucket {name} (platform.s3.buckets: "
                           f"{', '.join(sorted(self.buckets)) or 'none'})", code="bucket_not_declared")
        return bucket

    async def check(self) -> None:
        for bucket in self.buckets.values():
            await bucket._run("head_bucket", self.client.head_bucket)

    async def close(self) -> None:
        for client in (self.client, self.public):
            await anyio.to_thread.run_sync(client.close)


def _etag(answer: Mapping[str, Any]) -> str | None:
    etag = answer.get("ETag")
    return etag.strip('"') if etag else None


def _info(key: str, answer: Mapping[str, Any]) -> ObjectInfo:
    return ObjectInfo(key=key, size=answer.get("ContentLength"), content_type=answer.get("ContentType"), etag=_etag(answer),
                      last_modified=answer.get("LastModified"), metadata=answer.get("Metadata") or {})


def _error(exc: "ClientError", bucket: Bucket, key: str | None) -> AppError:
    code = str(exc.response.get("Error", {}).get("Code", ""))
    status = exc.response.get("ResponseMetadata", {}).get("HTTPStatusCode", 0)
    if code in ("NoSuchKey", "404", "NotFound") and key is not None:
        return NotFoundError(f"There is no object {key} in the bucket {bucket.name}", code="object_not_found")
    if code in ("NoSuchBucket", "404", "NotFound"):
        return ServiceUnavailableError(f"The bucket {bucket.full_name} does not exist yet (the platform creates it)",
                                       code="bucket_not_available")
    if status and status < 500:
        return BadGatewayError(f"S3 refused it ({code})", code="s3_rejected")
    return BadGatewayError(f"S3 failed ({code or status})", code="s3_error")


StorageDep = Annotated[Storage, Depends(block_dependency("s3"))]
