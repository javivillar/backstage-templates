"""Block `processes`: the processes and decisions the application brings in platform/processes/, in Camunda 7.

    from refresquito_fastapi.platform.processes import ProcessesDep

    @router.post("/pets/{pet_id}/review", status_code=202)
    async def ask_for_review(pet_id: int, processes: ProcessesDep, user: CurrentUser):
        instance = await processes.start("review", business_key=f"pet-{pet_id}", variables={"requestedBy": user.username})
        return {"process": instance.id}

Processes and decisions are named WITHOUT the application: "review" is the process `<app>-review` of
platform/processes/<app>-review.bpmn. In dev and pre the platform deploys it as `<app>-<stage>-review` (one engine for
every stage); the block adds the prefix of the stage it runs in (CAMUNDA_KEY_PREFIX), so the code is the same in every
stage. A full key that already starts with the prefix is taken as it is.

It talks to Camunda's REST API as the application's own identity (CAMUNDA_USERNAME, HTTP Basic), which the platform
allows on the processes of the application only. Starting, completing and correlating are audited with the user of
the request.
"""

import datetime as dt
import json
from collections.abc import Mapping
from typing import Annotated, Any, Self

import httpx
from fastapi import Depends
from pydantic import BaseModel

from ..audit import audit
from ..errors import AppError, BadGatewayError, NotFoundError
from . import Block, block_dependency, contract, register
from ._calls import BlockHttp

# how Camunda says that what was asked for is not there, when it answers 500
NOT_FOUND = ("cannot find task", "task is null", "no matching", "does not exist", "not found")


class ProcessInstance(BaseModel):
    id: str
    process: str              # the key in Camunda (with the prefix of the stage)
    business_key: str | None = None
    ended: bool = False


class Task(BaseModel):
    id: str
    name: str | None = None
    task: str | None = None   # the id of the user task in the BPMN (taskDefinitionKey)
    process_instance: str | None = None
    assignee: str | None = None
    created: str | None = None
    due: str | None = None


def typed(variables: Mapping[str, Any] | None) -> dict[str, dict[str, Any]]:
    """Python values as Camunda variables."""
    out: dict[str, dict[str, Any]] = {}
    for name, value in (variables or {}).items():
        if isinstance(value, bool):
            out[name] = {"value": value, "type": "Boolean"}
        elif isinstance(value, int):
            out[name] = {"value": value, "type": "Integer" if -(2**31) <= value < 2**31 else "Long"}
        elif isinstance(value, float):
            out[name] = {"value": value, "type": "Double"}
        elif isinstance(value, dt.datetime | dt.date):
            out[name] = {"value": value.isoformat(), "type": "String"}
        elif isinstance(value, Mapping | list | tuple):
            out[name] = {"value": json.dumps(value), "type": "Json"}
        elif value is None:
            out[name] = {"value": None, "type": "Null"}
        else:
            out[name] = {"value": str(value), "type": "String"}
    return out


def untyped(variables: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    """Camunda variables as Python values (Json parsed)."""
    out: dict[str, Any] = {}
    for name, variable in variables.items():
        value = variable.get("value")
        if variable.get("type") == "Json" and isinstance(value, str):
            value = json.loads(value)
        out[name] = value
    return out


@register
class Processes(Block):
    name = "processes"

    def __init__(self, url: str, username: str, password: str, key_prefix: str,
                 transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.prefix = key_prefix
        self.http = BlockHttp("processes", url, auth=httpx.BasicAuth(username, password), transport=transport)

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        v = contract.read(env, "processes")
        return cls(v["CAMUNDA_URL"], v["CAMUNDA_USERNAME"], v["CAMUNDA_PASSWORD"], v["CAMUNDA_KEY_PREFIX"])

    def key(self, name: str) -> str:
        """The key in Camunda of a process or decision of the application: review -> <app>[-<stage>]-review."""
        return name if name.startswith(self.prefix) else f"{self.prefix}{name}"

    def mine(self, key: str) -> bool:
        """A key of this deployment: with its prefix, and not one of another stage (in pro the prefix <app>- is also the
        start of <app>-dev-... and <app>-pre-...)."""
        return key.startswith(self.prefix) and not any(key.startswith(f"{self.prefix}{stage}-") for stage in ("dev", "pre"))

    async def _call(self, operation: str, method: str, url: str, *, missing: str | None = None, **kwargs: Any) -> Any:
        def errors(response: httpx.Response) -> AppError | None:
            if response.status_code < 400:
                return None
            message = _message(response)
            # Camunda says "does not exist" with a 404, or with a 500 and its message (a task, a message)
            if missing and (response.status_code == 404 or any(m in message.lower() for m in NOT_FOUND)):
                return NotFoundError(missing, code="process_not_found")
            if response.status_code < 500:
                return BadGatewayError(f"Camunda refused {operation} ({response.status_code}): {message}",
                                       code="processes_rejected")
            return None   # a failure of Camunda: 502 processes_error

        response = await self.http.request(operation, method, url, errors=errors, **kwargs)
        return response.json() if response.content else None

    # ---- processes
    async def start(self, process: str, *, business_key: str | None = None,
                    variables: Mapping[str, Any] | None = None) -> ProcessInstance:
        """Start the latest version of a process of the application."""
        key = self.key(process)
        body: dict[str, Any] = {"variables": typed(variables)}
        if business_key is not None:
            body["businessKey"] = business_key
        data = await self._call("start", "POST", f"/process-definition/key/{key}/start", json=body,
                                missing=f"The process {key} is not deployed (platform/processes/ of the application)")
        audit("processes.start", resource=f"process/{key}", process_instance=data["id"], business_key=business_key)
        return _instance(data, key)

    async def instances(self, process: str | None = None, *, business_key: str | None = None) -> list[ProcessInstance]:
        """The running instances of a process (or of every process of the application), optionally of one business key."""
        params: dict[str, str] = {}
        if process:
            params["processDefinitionKey"] = self.key(process)
        if business_key is not None:
            params["businessKey"] = business_key
        data = await self._call("instances", "GET", "/process-instance", params=params)
        return [_instance(item, key) for item in data if self.mine(key := item.get("definitionId", "").split(":")[0])]

    async def variables(self, instance_id: str) -> dict[str, Any]:
        data = await self._call("variables", "GET", f"/process-instance/{instance_id}/variables",
                                params={"deserializeValues": "false"},   # Json as text, not as Camunda's objects
                                missing=f"The process instance {instance_id} does not exist (or has ended)")
        return untyped(data)

    async def correlate(self, message: str, *, business_key: str | None = None,
                        variables: Mapping[str, Any] | None = None) -> None:
        """Deliver a message to the instance waiting for it (or start the process that begins with it)."""
        body: dict[str, Any] = {"messageName": message, "processVariables": typed(variables)}
        if business_key is not None:
            body["businessKey"] = business_key
        await self._call("correlate", "POST", "/message", json=body,
                         missing=f"No process of the application waits for the message {message}")
        audit("processes.correlate", resource=f"message/{message}", business_key=business_key)

    # ---- tasks
    async def tasks(self, *, process: str | None = None, business_key: str | None = None, assignee: str | None = None,
                    candidate_user: str | None = None, candidate_group: str | None = None) -> list[Task]:
        """Open user tasks of the processes of the application. `candidate_user` is the inbox of a person: the tasks
        assigned to them plus the ones offered to them or to their groups (Camunda answers those two separately: a
        candidate query leaves out a task assigned to the person that does not also name them as a candidate)."""
        params: dict[str, str] = {"sortBy": "created", "sortOrder": "asc"}
        if process:
            params["processDefinitionKey"] = self.key(process)
        if business_key is not None:
            params["processInstanceBusinessKey"] = business_key
        if assignee:
            params["assignee"] = assignee
        if candidate_group:
            params["candidateGroup"] = candidate_group
        if candidate_user:
            data = (await self._call("tasks", "GET", "/task", params={**params, "assignee": candidate_user})
                    + await self._call("tasks", "GET", "/task", params={**params, "candidateUser": candidate_user}))
        else:
            data = await self._call("tasks", "GET", "/task", params=params)
        tasks: dict[str, Task] = {}
        for item in data:
            if item["id"] in tasks or not self.mine(item.get("processDefinitionId", "").split(":")[0]):
                continue
            tasks[item["id"]] = Task(id=item["id"], name=item.get("name"), task=item.get("taskDefinitionKey"),
                                     process_instance=item.get("processInstanceId"), assignee=item.get("assignee"),
                                     created=item.get("created"), due=item.get("due"))
        return sorted(tasks.values(), key=lambda t: t.created or "")

    async def claim(self, task_id: str, user: str) -> None:
        await self._call("claim", "POST", f"/task/{task_id}/claim", json={"userId": user},
                         missing=f"The task {task_id} does not exist (or is done)")
        audit("processes.claim_task", resource=f"task/{task_id}", assignee=user)

    async def complete(self, task_id: str, variables: Mapping[str, Any] | None = None) -> None:
        await self._call("complete", "POST", f"/task/{task_id}/complete", json={"variables": typed(variables)},
                         missing=f"The task {task_id} does not exist (or is done)")
        audit("processes.complete_task", resource=f"task/{task_id}")

    # ---- decisions
    async def decide(self, decision: str, variables: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        """Evaluate a decision (DMN) of the application: one dict per matching rule."""
        key = self.key(decision)
        data = await self._call("decide", "POST", f"/decision-definition/key/{key}/evaluate",
                                json={"variables": typed(variables)},
                                missing=f"The decision {key} is not deployed (platform/processes/ of the application)")
        return [untyped(row) for row in data]

    async def check(self) -> None:
        await self._call("version", "GET", "/version")

    async def close(self) -> None:
        await self.http.close()


def _instance(data: Mapping[str, Any], key: str) -> ProcessInstance:
    return ProcessInstance(id=data["id"], process=key, business_key=data.get("businessKey"), ended=data.get("ended", False))


def _message(response: httpx.Response) -> str:
    try:
        return str(response.json().get("message") or response.text)[:300]
    except ValueError:
        return response.text[:300]


ProcessesDep = Annotated[Processes, Depends(block_dependency("processes"))]
