"""Block `flows`: the flows the application brings in platform/flows/, in Activepieces.

    from refresquito_fastapi.platform.flows import FlowsDep

    @router.post("/pets", status_code=201)
    async def create_pet(data: PetIn, flows: FlowsDep, ...):
        ...
        await flows.trigger("new-pet", {"name": pet.name})                      # fire and forget
        answer = await flows.trigger("new-pet", {"name": pet.name}, wait=True)  # the answer of its step Return Response

A flow is named as its file: platform/flows/new-pet.json is "new-pet". Its webhook reaches the API as
ACTIVEPIECES_FLOW_NEW_PET_URL once the platform has imported and published it (a ConfigMap the provisioner writes,
the API restarts to read it): until then, or for a flow that does not exist, `trigger` is a 503 `flow_not_available`.
Triggering is audited with the user of the request.
"""

from collections.abc import Mapping
from typing import Annotated, Any, Self
from urllib.parse import urlsplit

import httpx
from fastapi import Depends
from pydantic import BaseModel

from ..audit import audit
from ..errors import AppError, BadGatewayError, ServiceUnavailableError
from . import Block, block_dependency, contract, register
from ._calls import BlockHttp

PATTERN = "ACTIVEPIECES_FLOW_<NAME>_URL"
WAIT_TIMEOUT = 60.0   # seconds a synchronous flow may take


class FlowAnswer(BaseModel):
    status: int
    body: Any = None      # JSON when the flow answers JSON, else its text


def flow_name(key: str) -> str:
    """NEW_PET -> new-pet."""
    return key.lower().replace("_", "-")


@register
class Flows(Block):
    name = "flows"

    def __init__(self, urls: Mapping[str, str], transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.urls = {flow_name(key): url for key, url in urls.items()}
        # one client for every webhook (they are all on the same Activepieces): absolute URLs
        self.http = BlockHttp("flows", "", timeout=WAIT_TIMEOUT, transport=transport)

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        return cls(contract.items(env, PATTERN))

    @classmethod
    def empty(cls) -> Self:
        """The block before the provisioner has given the API any webhook: every flow is not available yet."""
        return cls({})

    def names(self) -> list[str]:
        return sorted(self.urls)

    async def trigger(self, flow: str, data: Mapping[str, Any] | list[Any] | None = None, *, wait: bool = False,
                      headers: Mapping[str, str] | None = None) -> FlowAnswer:
        """Start a flow with `data` as the body of its webhook. With wait=True, wait for it and return what its step
        Return Response answers; without, Activepieces only acknowledges it."""
        url = self.urls.get(flow)
        if url is None:
            raise ServiceUnavailableError(
                f"The flow {flow} is not available: no {contract.item_key(flow).join(PATTERN.split('<NAME>'))}. Either "
                "the application does not declare platform.flows, or the platform has not imported "
                f"platform/flows/{flow}.json yet (the API gets its webhook once it is published).",
                code="flow_not_available",
            )

        def errors(response: httpx.Response) -> AppError | None:
            if response.status_code in (404, 410):
                return ServiceUnavailableError(f"Activepieces does not run the flow {flow} (disabled or not published)",
                                               code="flow_not_available")
            return None

        response = await self.http.request("trigger_sync" if wait else "trigger", "POST", url + ("/sync" if wait else ""),
                                           json=data if data is not None else {}, headers=dict(headers or {}),
                                           errors=errors)
        audit("flows.trigger", resource=f"flow/{flow}", wait=wait, status=response.status_code)
        if not wait and response.status_code >= 400:
            raise BadGatewayError(f"Activepieces refused the flow {flow} ({response.status_code})", code="flows_rejected")
        try:
            body: Any = response.json() if response.content else None
        except ValueError:
            body = response.text
        return FlowAnswer(status=response.status_code, body=body)

    async def check(self) -> None:
        if not self.urls:
            return
        parts = urlsplit(next(iter(self.urls.values())))
        response = await self.http.request("flags", "GET", f"{parts.scheme}://{parts.netloc}/api/v1/flags")
        if response.status_code >= 400:
            raise RuntimeError(f"Activepieces answered {response.status_code}")

    async def close(self) -> None:
        await self.http.close()


FlowsDep = Annotated[Flows, Depends(block_dependency("flows"))]
