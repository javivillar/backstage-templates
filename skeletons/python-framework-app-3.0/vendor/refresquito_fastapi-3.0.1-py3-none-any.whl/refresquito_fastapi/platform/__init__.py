"""The building blocks of the platform an application declares, ready to use.

The application declares what it uses of the platform in `platform:` of bootstrap/app-of-apps/apps/<name>.yaml (the
Backstage template writes it). The chart python-app-oneke creates it and gives the API the environment of each block
(contract.py); the framework reads that environment and offers each block as a FastAPI dependency:

    from refresquito_fastapi.platform import ProcessesDep

    @router.post("/orders/{order_id}/submit")
    async def submit(order_id: int, processes: ProcessesDep, user: CurrentUser): ...

A block the application does not declare is not there: its dependency answers 500 and says so (a mistake of the
deployment, not of the caller). Each block is an extra of the package (`refresquito-fastapi[processes,s3]`) when it
needs a library of its own.

What every block does the same way:
  - each call counts in `platform_calls_total{block, operation, outcome}` and `platform_call_duration_seconds`;
  - what it writes in a service is audited (`audit()`), with the user of the request;
  - a service that does not answer is a 503 (`<block>_unavailable`), one that fails a 502 (`<block>_error`);
  - `/health/platform` says whether each block answers. It is NOT part of /health/ready: a service of the platform
    that is down must not take the application down with it.
"""

import asyncio
import os
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping
from typing import Any, ClassVar, Self

import structlog
from fastapi import Request

from ..errors import AppError
from . import contract
from .contract import PlatformConfigError

__all__ = ["Block", "Platform", "PlatformConfigError", "block_dependency", "register"]

log = structlog.get_logger(__name__)
HEALTH_TIMEOUT = 5.0   # seconds a block has to answer /health/platform


class Block(ABC):
    """One block of the platform, built from the environment the chart gives it."""

    name: ClassVar[str]

    @classmethod
    @abstractmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        """Build it from the variables of contract.CONTRACT[name] (only called when the block is declared)."""

    async def check(self) -> None:
        """Return when the service answers, raise when not (for /health/platform)."""
        return None

    async def close(self) -> None:
        """Release what it holds (HTTP clients)."""
        return None


REGISTRY: dict[str, type[Block]] = {}


def register(cls: type[Block]) -> type[Block]:
    """Make a block known to Platform.from_env."""
    REGISTRY[cls.name] = cls
    return cls


class Platform:
    """The blocks of this application, by name."""

    def __init__(self, blocks: Mapping[str, Block] | None = None) -> None:
        self.blocks: dict[str, Block] = dict(blocks or {})

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Platform":
        """The blocks the environment declares. A block with an incomplete environment stops the start-up
        (PlatformConfigError): better than failing at the first request that needs it."""
        env = os.environ if env is None else env
        blocks: dict[str, Block] = {}
        for name in contract.CONTRACT:
            if contract.declared(env, name):
                kind = _block_class(name)
                if kind is not None:
                    blocks[name] = kind.from_env(env)
        return cls(blocks)

    def __contains__(self, name: str) -> bool:
        return name in self.blocks

    def get(self, name: str) -> Block:
        block = self.blocks.get(name)
        if block is None and name in contract.CONTRACT:
            # a block whose variables come later (flows: once the provisioner has imported them) is there, empty
            kind = _block_class(name)
            empty = getattr(kind, "empty", None)
            if empty is not None:
                block = self.blocks[name] = empty()
        if block is None:
            raise AppError(
                f"This application does not declare the platform block `{name}` (platform.{name} of its file in "
                "refresquito-services), so it has none of its configuration.",
                code="platform_block_not_declared",
            )
        return block

    async def health(self) -> dict[str, str]:
        async def one(block: Block) -> str:
            try:
                await asyncio.wait_for(block.check(), HEALTH_TIMEOUT)
                return "ok"
            except Exception as exc:   # said, never raised: this is information
                return f"failed: {str(exc)[:200] or type(exc).__name__}"

        names = list(self.blocks)
        results = await asyncio.gather(*(one(self.blocks[n]) for n in names))
        return dict(zip(names, results, strict=True))

    async def close(self) -> None:
        for block in self.blocks.values():
            await block.close()


def block_dependency(name: str) -> Callable[[Request], Any]:
    """A FastAPI dependency that gives the block `name` of the application."""

    def dependency(request: Request) -> Any:
        platform: Platform | None = getattr(request.app.state, "platform", None)
        if platform is None:
            raise AppError("The application was not built with create_app()", code="platform_block_not_declared")
        return platform.get(name)

    dependency.__name__ = f"platform_{name}"
    return dependency


def _block_class(name: str) -> type[Block] | None:
    """The class of a declared block: its module registers it. A block that needs a library of its own needs its extra."""
    import importlib

    if name not in REGISTRY:
        try:
            importlib.import_module(f"{__name__}.{name}")
        except ModuleNotFoundError as exc:
            if exc.name == f"{__name__}.{name}":
                log.warning("platform_block_not_supported", block=name)   # a block this version does not know yet
                return None
            raise PlatformConfigError(
                f"block {name}: it needs {exc.name}, which is not installed: depend on refresquito-fastapi[{name}]"
            ) from exc
    return REGISTRY.get(name)
