"""Block `dms`: the Alfresco sites the application declares, through the public REST API of the repository.

    from refresquito_fastapi.platform.dms import DocumentsDep

    @router.post("/pets/{pet_id}/documents", status_code=201)
    async def attach(pet_id: int, file: UploadFile, documents: DocumentsDep):
        records = documents.site("records")
        return await records.upload(file.filename, await file.read(), folder=records.folder("pet", pet_id),
                                    content_type=file.content_type)

    @router.get("/pets/{pet_id}/documents")
    async def list_documents(pet_id: int, documents: DocumentsDep):
        records = documents.site("records")
        return await records.list(records.folder("pet", pet_id))

A site is named as declared: `records` is the site <app>[-<stage>]-records (ALFRESCO_SITE_RECORDS). The application works
in its document library as its own native person (ALFRESCO_USERNAME, a collaborator of its sites); the people of the
site see the same documents in Alfresco. The documents of one entity go in a folder of their own (`folder("pet", 7)` is
pet/7), created when the first one is uploaded. Uploads and deletions are audited.
"""

import datetime as dt
from collections.abc import Mapping
from typing import Annotated, Any, Self

import httpx
from fastapi import Depends
from pydantic import BaseModel

from ..audit import audit
from ..errors import AppError, BadGatewayError, ConflictError, NotFoundError
from . import Block, block_dependency, contract, register
from ._calls import BlockHttp

PATTERN = "ALFRESCO_SITE_<NAME>"
API = "/alfresco/api/-default-/public/alfresco/versions/1"


class Document(BaseModel):
    id: str
    name: str
    folder: str = ""                 # in the document library of the site: "" or "pet/7"
    mime_type: str | None = None
    size: int | None = None
    modified_at: dt.datetime | None = None
    modified_by: str | None = None
    title: str | None = None
    description: str | None = None


class Content(BaseModel):
    document: Document
    content: bytes


def site_name(key: str) -> str:
    """RECORDS -> records, LEGAL_DOCS -> legal-docs."""
    return key.lower().replace("_", "-")


class Site:
    """One site of the application: its document library."""

    def __init__(self, documents: "Documents", name: str, site_id: str) -> None:
        self.documents, self.name, self.site_id = documents, name, site_id
        self._library: str | None = None
        self._prefix = f"/Company Home/Sites/{site_id}/documentLibrary"

    @staticmethod
    def folder(entity: str, entity_id: Any) -> str:
        """The folder of the documents of one entity: pet/7."""
        return f"{entity}/{entity_id}"

    async def _call(self, operation: str, method: str, url: str, *, missing: str | None = None, **kwargs: Any) -> Any:
        def errors(response: httpx.Response) -> AppError | None:
            if response.status_code == 404 and missing:
                return NotFoundError(missing, code="document_not_found")
            if response.status_code == 409:
                return ConflictError(_message(response), code="document_exists")
            if 400 <= response.status_code < 500:
                return BadGatewayError(f"Alfresco refused {operation} ({response.status_code}): {_message(response)}",
                                       code="dms_rejected")
            return None

        response = await self.documents.http.request(operation, method, API + url, errors=errors, **kwargs)
        if not response.content:
            return None
        return response.json() if response.headers.get("content-type", "").startswith("application/json") else response

    async def library(self) -> str:
        """The id of the document library of the site."""
        if self._library is None:
            data = await self._call("library", "GET", f"/sites/{self.site_id}/containers/documentLibrary",
                                    missing=f"The site {self.site_id} does not exist yet (the platform creates it), or the "
                                            "application is not a member")
            self._library = data["entry"]["id"]
        return self._library

    def _document(self, entry: Mapping[str, Any]) -> Document:
        path = (entry.get("path") or {}).get("name", "")
        content = entry.get("content") or {}
        properties = entry.get("properties") or {}
        return Document(id=entry["id"], name=entry["name"], folder=path.removeprefix(self._prefix).strip("/"),
                        mime_type=content.get("mimeType"), size=content.get("sizeInBytes"),
                        modified_at=entry.get("modifiedAt"),
                        modified_by=(entry.get("modifiedByUser") or {}).get("id"), title=properties.get("cm:title"),
                        description=properties.get("cm:description"))

    async def upload(self, name: str, content: bytes, *, folder: str = "", content_type: str | None = None,
                     title: str | None = None, description: str | None = None, overwrite: bool = True) -> Document:
        """Store a document in a folder of the library (created if missing). With overwrite (the default) a document of
        the same name gets a new version; without, it is a 409 `document_exists`."""
        form: dict[str, str] = {"name": name, "nodeType": "cm:content", "overwrite": str(overwrite).lower(),
                                "autoRename": "false"}
        if folder:
            form["relativePath"] = folder
        if title:
            form["cm:title"] = title
        if description:
            form["cm:description"] = description
        file = (name, content, content_type or "application/octet-stream")
        data = await self._call("upload", "POST", f"/nodes/{await self.library()}/children",
                                params={"include": "path,properties"}, data=form, files={"filedata": file})
        document = self._document(data["entry"])
        audit("dms.upload", resource=f"alfresco://{self.site_id}/{document.folder}/{name}".replace("//", "/"),
              document=document.id, size=len(content))
        return document

    async def list(self, folder: str = "") -> list[Document]:
        """The documents of a folder (none when it does not exist yet)."""
        params = {"where": "(isFile=true)", "include": "path,properties", "orderBy": "name", "maxItems": "1000"}
        if folder:
            params["relativePath"] = folder
        try:
            data = await self._call("list", "GET", f"/nodes/{await self.library()}/children", params=params,
                                    missing=f"There is no folder {folder}")
        except NotFoundError:
            return []
        return [self._document(item["entry"]) for item in data["list"]["entries"]]

    async def get(self, document_id: str) -> Document:
        """A document of this site (one of another site, or of nowhere, is a 404)."""
        data = await self._call("get", "GET", f"/nodes/{document_id}", params={"include": "path,properties"},
                                missing=f"There is no document {document_id} in the site {self.name}")
        if not (data["entry"].get("path") or {}).get("name", "").startswith(self._prefix) or not data["entry"].get("isFile"):
            raise NotFoundError(f"There is no document {document_id} in the site {self.name}", code="document_not_found")
        return self._document(data["entry"])

    async def content(self, document_id: str) -> Content:
        document = await self.get(document_id)
        response = await self._call("content", "GET", f"/nodes/{document_id}/content",
                                    missing=f"There is no document {document_id} in the site {self.name}")
        return Content(document=document, content=response.content if response is not None else b"")

    async def delete(self, document_id: str) -> None:
        document = await self.get(document_id)
        await self._call("delete", "DELETE", f"/nodes/{document_id}",
                         missing=f"There is no document {document_id} in the site {self.name}")
        audit("dms.delete", resource=f"alfresco://{self.site_id}/{document.folder}/{document.name}".replace("//", "/"),
              document=document_id)


@register
class Documents(Block):
    name = "dms"

    def __init__(self, url: str, username: str, password: str, sites: Mapping[str, str],
                 transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.http = BlockHttp("dms", url, auth=httpx.BasicAuth(username, password), timeout=60, transport=transport)
        self.sites = {site_name(k): Site(self, site_name(k), site_id) for k, site_id in sites.items()}

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        v = contract.read(env, "dms")
        return cls(v["ALFRESCO_URL"], v["ALFRESCO_USERNAME"], v["ALFRESCO_PASSWORD"], contract.items(env, PATTERN))

    def site(self, name: str) -> Site:
        """A site by the name it is declared with (records)."""
        site = self.sites.get(name)
        if site is None:
            raise AppError(f"The application declares no site {name} (platform.dms.sites: "
                           f"{', '.join(sorted(self.sites)) or 'none'})", code="site_not_declared")
        return site

    async def check(self) -> None:
        for site in self.sites.values():
            await site.library()

    async def close(self) -> None:
        await self.http.close()


def _message(response: httpx.Response) -> str:
    try:
        return str(response.json().get("error", {}).get("briefSummary") or response.text)[:300]
    except ValueError:
        return response.text[:300]


DocumentsDep = Annotated[Documents, Depends(block_dependency("dms"))]
