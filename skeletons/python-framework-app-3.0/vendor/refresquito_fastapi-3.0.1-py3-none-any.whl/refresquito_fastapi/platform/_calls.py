"""Calls of the framework to the services of the platform: metrics, logs and one way to fail."""

import time
from collections.abc import AsyncIterator, Callable, Mapping
from contextlib import asynccontextmanager
from typing import Any

import httpx
import structlog
from prometheus_client import Counter, Histogram

from ..errors import AppError, BadGatewayError, ServiceUnavailableError

CALLS = Counter("platform_calls_total", "Calls to the services of the platform", ["block", "operation", "outcome"])
DURATION = Histogram("platform_call_duration_seconds", "Time of a call to a service of the platform", ["block", "operation"])
log = structlog.get_logger("refresquito_fastapi.platform")


@asynccontextmanager
async def instrumented(block: str, operation: str) -> AsyncIterator[None]:
    """Count and time one operation of a block. An AppError is what the service answered (the outcome is its code);
    anything else is a failure of the call."""
    start = time.perf_counter()
    outcome = "success"
    try:
        yield
    except AppError as exc:
        outcome = exc.code
        raise
    except Exception:
        outcome = "error"
        raise
    finally:
        CALLS.labels(block, operation, outcome).inc()
        DURATION.labels(block, operation).observe(time.perf_counter() - start)


class BlockHttp:
    """An HTTP client of one service of the platform. A service that does not answer is a 503 of the application
    (`<block>_unavailable`); one that answers 5xx, a 502 (`<block>_error`); a 4xx is returned to the block, which
    knows what it means. `errors` lets the block say first what an answer means (a service that answers 500 for
    "not found"): an AppError it returns is raised, and counted with its code."""

    def __init__(self, block: str, base_url: str, *, auth: Any = None, headers: Mapping[str, str] | None = None,
                 timeout: float = 15.0, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.block = block
        self.client = httpx.AsyncClient(base_url=base_url.rstrip("/"), auth=auth, headers=dict(headers or {}),
                                        timeout=timeout, transport=transport)

    async def request(self, operation: str, method: str, url: str, *,
                      errors: Callable[[httpx.Response], AppError | None] | None = None, **kwargs: Any) -> httpx.Response:
        async with instrumented(self.block, operation):
            try:
                response = await self.client.request(method, url, **kwargs)
            except httpx.TransportError as exc:
                log.warning("platform_call_failed", block=self.block, operation=operation, error=str(exc))
                raise ServiceUnavailableError(
                    f"{self.block}: the service does not answer", code=f"{self.block}_unavailable"
                ) from exc
            if errors is not None and (error := errors(response)) is not None:
                raise error
            if response.status_code >= 500:
                log.warning("platform_call_failed", block=self.block, operation=operation, status=response.status_code,
                            body=response.text[:300])
                raise BadGatewayError(
                    f"{self.block}: the service answered {response.status_code}", code=f"{self.block}_error"
                )
            return response

    async def close(self) -> None:
        await self.client.aclose()
