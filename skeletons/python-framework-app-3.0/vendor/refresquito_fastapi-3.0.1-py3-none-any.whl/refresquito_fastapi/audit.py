"""The audit trail: who did what, apart from the logs of the application.

Every line a service writes carries `log_type`: "application" for its logs (the access line
included) and "audit" for the audit trail. Both go to stdout as JSON; the platform's Fluent Bit
makes `log_type` a label of Loki, so each one is a stream of its own (its own queries, and its own
retention where the platform sets one). Audit lines are written whatever RQ_LOG_LEVEL says.

What is audited:

  - by itself, every write (POST, PUT, PATCH, DELETE) once it is answered, and every request
    refused for lack of a valid token or of a role (401, 403), whatever its method;
  - by hand, what the service decides is worth it, with `audit()`:

        audit("invoice.approve", resource=f"invoice/{invoice.id}", amount=str(invoice.total))

Each event also counts in `audit_events_total{action, outcome}` on /metrics, which the platform's
Prometheus scrapes: alerts and panels without reading the logs.
"""

from typing import Any, Literal

import structlog
from prometheus_client import Counter

Outcome = Literal["success", "failure", "denied"]

EVENTS = Counter("audit_events_total", "Audit events written", ["action", "outcome"])
# the action an automatic event gets from the method of the request
ACTIONS = {"POST": "create", "PUT": "update", "PATCH": "update", "DELETE": "delete"}
WRITES = frozenset(ACTIONS)

_log = structlog.get_logger("audit")


def audit(action: str, *, resource: str | None = None, outcome: Outcome = "success", **details: Any) -> None:
    """Write an audit event. The request ID and the user of the request being served are added by
    themselves; `details` go as they are (never put secrets or personal data you do not need)."""
    EVENTS.labels(action, outcome).inc()
    _log.info("audit", log_type="audit", action=action, resource=resource, outcome=outcome, **details)


def outcome_of(status: int) -> Outcome:
    if status in (401, 403):
        return "denied"
    return "success" if status < 400 else "failure"


def request_event(method: str, path: str, route: str, status: int, user: Any) -> None:
    """The automatic event of a request, if it is one to audit: a write, or a refused one."""
    if method not in WRITES and status not in (401, 403):
        return
    audit(
        ACTIONS.get(method, "read"),
        resource=path,
        outcome=outcome_of(status),
        method=method,
        route=route,
        status=status,
        user=getattr(user, "username", None),
        roles=sorted(getattr(user, "roles", ()) or ()) or None,
    )
