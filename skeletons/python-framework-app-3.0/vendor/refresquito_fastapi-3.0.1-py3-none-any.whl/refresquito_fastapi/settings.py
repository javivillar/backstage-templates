"""Configuration of a service, read from environment variables (prefix RQ_)."""

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """What the framework needs to know. A service extends it with its own fields.

    Every field is the environment variable RQ_<NAME>: RQ_OIDC_ISSUER, RQ_DATABASE_URL...
    """

    model_config = SettingsConfigDict(env_prefix="RQ_", env_file=".env", extra="ignore")

    app_name: str = "service"
    environment: str = "local"

    log_level: str = "INFO"
    log_format: str = Field("json", pattern="^(json|console)$")
    # the audit events of every write and of every refused request (audit.py); audit() is never off
    audit_requests: bool = True

    # Keycloak realm that signs the tokens, e.g. https://iam.<domain>/realms/RefresquitoTime
    oidc_issuer: str | None = None
    # where to read its signing keys; default: <issuer>/protocol/openid-connect/certs
    oidc_jwks_url: str | None = None
    # 3.0: a token is accepted only if it was issued for this service. With RQ_OIDC_CLIENT_ID, by the client that asked
    # for it (`azp`): that one, or one of RQ_OIDC_TRUSTED_CLIENTS (comma separated: the clients of the services that call
    # this one). `aud` does not count then: Keycloak puts in it every client the user has roles of, whoever asked.
    # Without a client, RQ_OIDC_AUDIENCE must be in `aud`. RQ_OIDC_VERIFY_AUDIENCE=false turns the check off.
    oidc_audience: str | None = None
    oidc_trusted_clients: str = ""
    oidc_verify_audience: bool = True
    # client whose roles (resource_access.<client>.roles) count besides the realm roles,
    # and the one Swagger UI logs in with
    oidc_client_id: str | None = None
    # CA bundle to trust when reading the keys (the cluster CA); default: the system store
    oidc_ca_file: str | None = None

    # e.g. postgresql+asyncpg://user:password@host:5432/database
    database_url: str | None = None

    cors_origins: list[str] = []
