"""Request metrics for Prometheus, published on /metrics."""

from fastapi import APIRouter, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

REQUESTS = Counter("http_requests_total", "Requests served", ["method", "path", "status"])
DURATION = Histogram("http_request_duration_seconds", "Time to serve a request", ["method", "path"])

router = APIRouter()


def observe(method: str, path: str, status: int, seconds: float) -> None:
    REQUESTS.labels(method, path, str(status)).inc()
    DURATION.labels(method, path).observe(seconds)


@router.get("/metrics", include_in_schema=False)
async def metrics() -> Response:
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
