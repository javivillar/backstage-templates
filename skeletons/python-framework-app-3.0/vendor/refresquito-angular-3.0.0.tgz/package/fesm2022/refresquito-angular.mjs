import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, Injectable, input, TemplateRef, ViewContainerRef, effect, Directive, ChangeDetectionStrategy, Component, makeEnvironmentProviders, ErrorHandler, provideAppInitializer, output } from '@angular/core';
import Keycloak from 'keycloak-js';
import { Router } from '@angular/router';
import { HttpContextToken, HttpErrorResponse, provideHttpClient, withInterceptors, HttpClient, HttpEventType } from '@angular/common/http';
import { from, switchMap, catchError, throwError, firstValueFrom } from 'rxjs';

const RQ_OPTIONS = new InjectionToken('RQ_OPTIONS', { factory: () => ({}) });
/**
 * The configuration of the running application, read once at start-up from `config.json`. The
 * same build runs on any cluster: only that file changes.
 */
class ConfigService {
    options = inject(RQ_OPTIONS);
    value = signal(null, ...(ngDevMode ? [{ debugName: "value" }] : []));
    /** The configuration. It throws if it is read before the application has started. */
    config = computed(() => {
        const config = this.value();
        if (!config) {
            throw new Error('The configuration is not loaded yet: is provideRefresquito() in the providers?');
        }
        return config;
    }, ...(ngDevMode ? [{ debugName: "config" }] : []));
    get apiUrl() {
        return this.config().apiUrl;
    }
    async load(fetcher = fetch) {
        const url = this.options.configUrl ?? 'config.json';
        const response = await fetcher(url, { cache: 'no-store' });
        if (!response.ok) {
            throw new Error(`Cannot read the configuration from ${url}: HTTP ${response.status}`);
        }
        return this.set((await response.json()));
    }
    set(config) {
        const missing = [
            !config?.apiUrl && config?.apiUrl !== '' ? 'apiUrl' : null,
            !config?.keycloak?.url ? 'keycloak.url' : null,
            !config?.keycloak?.realm ? 'keycloak.realm' : null,
            !config?.keycloak?.clientId ? 'keycloak.clientId' : null,
        ].filter(Boolean);
        if (missing.length) {
            throw new Error(`The configuration has no ${missing.join(', ')}`);
        }
        const clean = { ...config, apiUrl: config.apiUrl.replace(/\/+$/, '') };
        this.value.set(clean);
        return clean;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const ORDER = ['debug', 'info', 'warn', 'error'];
/** Console logs with a level and a context object, filtered by `logLevel` of the configuration. */
class LoggerService {
    configuration = inject(ConfigService);
    debug(message, context) {
        this.write('debug', message, context);
    }
    info(message, context) {
        this.write('info', message, context);
    }
    warn(message, context) {
        this.write('warn', message, context);
    }
    error(message, context) {
        this.write('error', message, context);
    }
    level() {
        try {
            return this.configuration.config().logLevel ?? 'info';
        }
        catch {
            return 'info'; // before the configuration is loaded
        }
    }
    write(level, message, context) {
        if (ORDER.indexOf(level) < ORDER.indexOf(this.level())) {
            return;
        }
        const args = [`[${level}] ${message}`];
        if (context !== undefined) {
            args.push(context);
        }
        console[level](...args);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Who is using the application. The implementation talks to Keycloak; tests provide a fake one
 * (`provideRefresquitoTesting`), so components never import keycloak-js.
 */
class AuthService {
    isLoggedIn = computed(() => this.user() !== null, ...(ngDevMode ? [{ debugName: "isLoggedIn" }] : []));
    /** True if the user has any of these roles. */
    hasRole(...roles) {
        const mine = this.user()?.roles ?? [];
        return roles.some((role) => mine.includes(role));
    }
}
/** How the Keycloak client is built. Replaced in tests. */
const RQ_KEYCLOAK_FACTORY = new InjectionToken('RQ_KEYCLOAK_FACTORY', {
    factory: () => (config) => new Keycloak(config),
});
class KeycloakAuthService extends AuthService {
    configuration = inject(ConfigService);
    options = inject(RQ_OPTIONS);
    factory = inject(RQ_KEYCLOAK_FACTORY);
    log = inject(LoggerService);
    keycloak;
    current = signal(null, ...(ngDevMode ? [{ debugName: "current" }] : []));
    user = this.current.asReadonly();
    async init() {
        const { url, realm, clientId } = this.configuration.config().keycloak;
        this.keycloak = this.factory({ url, realm, clientId });
        this.keycloak.onAuthLogout = () => this.current.set(null);
        this.keycloak.onAuthRefreshSuccess = () => this.read();
        await this.keycloak.init({
            onLoad: this.options.onLoad ?? 'check-sso',
            pkceMethod: 'S256',
            // the session iframe needs third-party cookies, which browsers block
            checkLoginIframe: false,
        });
        this.read();
    }
    async login(redirectUrl) {
        await this.client().login({ redirectUri: this.absolute(redirectUrl) });
    }
    async logout(redirectUrl) {
        await this.client().logout({ redirectUri: this.absolute(redirectUrl ?? '/') });
    }
    async token() {
        const keycloak = this.client();
        if (!keycloak.authenticated) {
            return null;
        }
        try {
            await keycloak.updateToken(30);
        }
        catch (error) {
            // the session ended in Keycloak: nobody is signed in any more
            this.log.warn('The token could not be refreshed', { error: String(error) });
            this.current.set(null);
            return null;
        }
        return keycloak.token ?? null;
    }
    client() {
        if (!this.keycloak) {
            throw new Error('AuthService is used before the application has started');
        }
        return this.keycloak;
    }
    absolute(url) {
        return new URL(url ?? window.location.href, window.location.href).toString();
    }
    read() {
        const keycloak = this.client();
        const claims = keycloak.tokenParsed;
        if (!keycloak.authenticated || !claims) {
            this.current.set(null);
            return;
        }
        const clientId = this.configuration.config().keycloak.clientId;
        const roles = new Set([
            ...(claims.realm_access?.roles ?? []),
            ...(claims.resource_access?.[clientId]?.roles ?? []),
        ]);
        this.current.set({
            username: claims['preferred_username'] ?? claims.sub ?? '',
            name: claims['name'],
            email: claims['email'],
            roles: [...roles].sort(),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService, decorators: [{
            type: Injectable
        }] });

/**
 * A route for signed-in users only, and optionally only for some roles:
 *
 *     { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } }
 *
 * Nobody signed in: the browser goes to Keycloak and comes back to the route. Signed in without
 * any of the roles: the route `data.forbiddenUrl`, or `/forbidden`.
 */
const authGuard = async (route, state) => {
    const auth = inject(AuthService);
    const router = inject(Router);
    if (!auth.isLoggedIn()) {
        await auth.login(state.url);
        return false;
    }
    const roles = route.data?.['roles'] ?? [];
    if (roles.length && !auth.hasRole(...roles)) {
        return router.parseUrl(route.data?.['forbiddenUrl'] ?? '/forbidden');
    }
    return true;
};

/**
 * Renders its content only for users with one of the roles:
 *
 *     <button *rqHasRole="'petstore-admin'">Delete</button>
 *     <a *rqHasRole="['petstore-admin', 'petstore-viewer']" routerLink="/pets">Pets</a>
 *
 * It only hides: what must not happen is refused by the API.
 */
class RqHasRole {
    rqHasRole = input.required(...(ngDevMode ? [{ debugName: "rqHasRole" }] : []));
    auth = inject(AuthService);
    template = inject((TemplateRef));
    container = inject(ViewContainerRef);
    shown = false;
    constructor() {
        effect(() => {
            const roles = this.rqHasRole();
            const allowed = this.auth.hasRole(...(Array.isArray(roles) ? roles : [roles]));
            if (allowed && !this.shown) {
                this.container.createEmbeddedView(this.template);
            }
            else if (!allowed && this.shown) {
                this.container.clear();
            }
            this.shown = allowed;
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqHasRole, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.33", type: RqHasRole, isStandalone: true, selector: "[rqHasRole]", inputs: { rqHasRole: { classPropertyName: "rqHasRole", publicName: "rqHasRole", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqHasRole, decorators: [{
            type: Directive,
            args: [{ selector: '[rqHasRole]' }]
        }], ctorParameters: () => [], propDecorators: { rqHasRole: [{ type: i0.Input, args: [{ isSignal: true, alias: "rqHasRole", required: true }] }] } });

/** Messages for the user. Show them with `<rq-notifications />` or read `messages` yourself. */
class NotificationService {
    next = 1;
    list = signal([], ...(ngDevMode ? [{ debugName: "list" }] : []));
    messages = this.list.asReadonly();
    info(message) {
        return this.add('info', message);
    }
    success(message) {
        return this.add('success', message);
    }
    error(message, reference) {
        return this.add('error', message, reference);
    }
    dismiss(id) {
        this.list.update((all) => all.filter((n) => n.id !== id));
    }
    clear() {
        this.list.set([]);
    }
    add(kind, message, reference) {
        const id = this.next++;
        this.list.update((all) => [...all, { id, kind, message, reference }]);
        return id;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/** The pending notifications, each with a button to dismiss it. Style the `rq-notification` classes. */
class RqNotifications {
    notifications = inject(NotificationService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqNotifications, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqNotifications, isStandalone: true, selector: "rq-notifications", ngImport: i0, template: `
    @for (n of notifications.messages(); track n.id) {
      <div class="rq-notification rq-notification-{{ n.kind }}" [attr.role]="n.kind === 'error' ? 'alert' : 'status'">
        <span class="rq-notification-message">{{ n.message }}</span>
        @if (n.reference) {
          <small class="rq-notification-reference">Ref. {{ n.reference }}</small>
        }
        <button type="button" class="rq-notification-dismiss" aria-label="Dismiss" (click)="notifications.dismiss(n.id)">×</button>
      </div>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqNotifications, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-notifications',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @for (n of notifications.messages(); track n.id) {
      <div class="rq-notification rq-notification-{{ n.kind }}" [attr.role]="n.kind === 'error' ? 'alert' : 'status'">
        <span class="rq-notification-message">{{ n.message }}</span>
        @if (n.reference) {
          <small class="rq-notification-reference">Ref. {{ n.reference }}</small>
        }
        <button type="button" class="rq-notification-dismiss" aria-label="Dismiss" (click)="notifications.dismiss(n.id)">×</button>
      </div>
    }
  `,
                }]
        }] });

/** What a failed call throws: the problem document, or the closest thing when the answer was not one. */
class RqHttpError extends Error {
    status;
    code;
    problem;
    cause_;
    constructor(status, code, message, problem, cause_) {
        super(message);
        this.status = status;
        this.code = code;
        this.problem = problem;
        this.cause_ = cause_;
        this.name = 'RqHttpError';
    }
    get requestId() {
        return this.problem?.request_id ?? this.cause_.headers?.get('X-Request-ID') ?? undefined;
    }
    /** The message of each invalid field, by field name. */
    get fieldErrors() {
        return Object.fromEntries((this.problem?.errors ?? []).map((e) => [e.field, e.message]));
    }
}
function toRqHttpError(response) {
    const body = response.error;
    const problem = body && typeof body === 'object' && typeof body.status === 'number' ? body : null;
    if (problem) {
        return new RqHttpError(response.status, problem.code ?? 'error', problem.detail ?? problem.title ?? 'Error', problem, response);
    }
    if (response.status === 0) {
        return new RqHttpError(0, 'network_error', 'The server cannot be reached', null, response);
    }
    return new RqHttpError(response.status, 'error', response.statusText || `HTTP ${response.status}`, null, response);
}
/** Set it on a request whose errors the caller shows by itself: `context: new HttpContext().set(RQ_SILENT, true)`. */
const RQ_SILENT = new HttpContextToken(() => false);
/** Adds the token of the signed-in user to the calls to the API of the application, and to no other. */
const authInterceptor = (request, next) => {
    const api = inject(ConfigService).apiUrl;
    const auth = inject(AuthService);
    const toApi = api === '' ? !/^https?:\/\//.test(request.url) : request.url === api || request.url.startsWith(`${api}/`);
    if (!toApi || !auth.isLoggedIn()) {
        return next(request);
    }
    return from(auth.token()).pipe(switchMap((token) => next(token ? request.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : request)));
};
/** Turns a failed call into an `RqHttpError` and tells the user, unless the request is `RQ_SILENT`. */
const errorInterceptor = (request, next) => {
    const notifications = inject(NotificationService);
    const log = inject(LoggerService);
    return next(request).pipe(catchError((response) => {
        if (!(response instanceof HttpErrorResponse)) {
            return throwError(() => response);
        }
        const error = toRqHttpError(response);
        log.warn(`${request.method} ${request.url} failed`, { status: error.status, code: error.code, requestId: error.requestId });
        // validation errors belong next to their fields: the form shows them
        if (!request.context.get(RQ_SILENT) && error.status !== 422) {
            notifications.error(error.message, error.requestId);
        }
        return throwError(() => error);
    }));
};
/** Anything nobody caught: logged, and the user told that something failed. */
class RqErrorHandler {
    log = inject(LoggerService);
    notifications = inject(NotificationService);
    handleError(error) {
        if (error instanceof RqHttpError) {
            return; // the interceptor already logged it and told the user
        }
        this.log.error('Unexpected error', { error });
        this.notifications.error('Something went wrong');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler, decorators: [{
            type: Injectable
        }] });

/**
 * Everything of the framework, in `app.config.ts`:
 *
 *     providers: [provideRouter(routes), provideRefresquito()]
 *
 * Before the application starts it reads `config.json` and asks Keycloak who is signed in.
 * HttpClient comes configured: calls to the API carry the token, and errors are
 * `RqHttpError` and are shown to the user.
 */
function provideRefresquito(options = {}) {
    return makeEnvironmentProviders([
        { provide: RQ_OPTIONS, useValue: options },
        { provide: AuthService, useClass: KeycloakAuthService },
        { provide: ErrorHandler, useClass: RqErrorHandler },
        provideHttpClient(withInterceptors([authInterceptor, errorInterceptor])),
        provideAppInitializer(async () => {
            const config = inject(ConfigService);
            const auth = inject(AuthService);
            await config.load();
            await auth.init();
        }),
    ]);
}

/** The calls of the components, to use them without the components too. */
class PlatformApiService {
    http = inject(HttpClient);
    config = inject(ConfigService);
    url(path) {
        return /^https?:\/\//.test(path) ? path : `${this.config.apiUrl}${path}`;
    }
    documents(path) {
        return firstValueFrom(this.http.get(this.url(path)));
    }
    /** Upload a file (multipart, field `file` by default), with its progress. */
    upload(path, file, field = 'file') {
        const form = new FormData();
        form.append(field, file, file.name);
        return this.http.post(this.url(path), form, { reportProgress: true, observe: 'events' });
    }
    /** Download: the file the API answers is saved; a {"url"} it answers (a presigned URL of S3) is opened. */
    async download(path, filename) {
        const response = await firstValueFrom(this.http.get(this.url(path), { observe: 'response', responseType: 'blob' }));
        const blob = response.body ?? new Blob();
        if ((response.headers.get('content-type') ?? '').startsWith('application/json')) {
            const answer = JSON.parse(await blob.text());
            if (answer.url) {
                this.open(answer.url);
                return;
            }
        }
        this.save(blob, filename ?? filenameOf(response) ?? 'download');
    }
    tasks(path) {
        return firstValueFrom(this.http.get(this.url(path)));
    }
    complete(path, taskId, variables = {}) {
        return firstValueFrom(this.http.post(this.url(`${path}/${encodeURIComponent(taskId)}/complete`), variables));
    }
    /** Go to a URL (a navigation: no CORS needed). */
    open(url) {
        const link = document.createElement('a');
        link.href = url;
        link.rel = 'noopener';
        link.click();
    }
    /** Save a blob as a file of the user. */
    save(blob, filename) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PlatformApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PlatformApiService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PlatformApiService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function filenameOf(response) {
    const disposition = response.headers.get('content-disposition') ?? '';
    return /filename\*?="?(?:UTF-8'')?([^";]+)"?/i.exec(disposition)?.[1];
}
/** 1536 -> "1.5 KB". */
function formatSize(bytes) {
    if (bytes == null) {
        return '';
    }
    const units = ['B', 'KB', 'MB', 'GB'];
    let value = bytes;
    let unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
        value /= 1024;
        unit++;
    }
    return `${unit === 0 ? value : value.toFixed(1)} ${units[unit]}`;
}
/**
 * A button to upload files to the API of the application, with their progress:
 *
 *     <rq-file-upload path="/api/pets/7/documents" accept="application/pdf" (uploaded)="list.reload()" />
 */
class RqFileUpload {
    path = input.required(...(ngDevMode ? [{ debugName: "path" }] : []));
    field = input('file', ...(ngDevMode ? [{ debugName: "field" }] : []));
    accept = input('', ...(ngDevMode ? [{ debugName: "accept" }] : []));
    multiple = input(false, ...(ngDevMode ? [{ debugName: "multiple" }] : []));
    label = input('Upload', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** What the API answered, for each file uploaded. */
    uploaded = output();
    progress = signal(null, ...(ngDevMode ? [{ debugName: "progress" }] : []));
    api = inject(PlatformApiService);
    async choose(event) {
        const element = event.target;
        const files = [...(element.files ?? [])];
        element.value = '';
        for (const file of files) {
            await this.send(file);
        }
    }
    /** Upload one file (what choosing it in the button does). */
    async send(file) {
        this.progress.set(0);
        try {
            const body = await new Promise((resolve, reject) => this.api.upload(this.path(), file, this.field()).subscribe({
                next: (event) => {
                    if (event.type === HttpEventType.UploadProgress && event.total) {
                        this.progress.set(Math.round((100 * event.loaded) / event.total));
                    }
                    else if (event.type === HttpEventType.Response) {
                        resolve(event.body);
                    }
                },
                error: reject,
            }));
            this.uploaded.emit(body);
        }
        finally {
            this.progress.set(null);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqFileUpload, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqFileUpload, isStandalone: true, selector: "rq-file-upload", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: true, transformFunction: null }, field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null }, accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { uploaded: "uploaded" }, ngImport: i0, template: `
    <label class="rq-file-upload" [class.rq-file-upload-busy]="progress() !== null">
      <input type="file" class="rq-file-upload-input" [accept]="accept()" [multiple]="multiple()"
             [disabled]="progress() !== null" (change)="choose($event)" />
      <span class="rq-file-upload-label">{{ label() }}</span>
    </label>
    @if (progress() !== null) {
      <progress class="rq-file-upload-progress" max="100" [value]="progress()"></progress>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqFileUpload, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-file-upload',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <label class="rq-file-upload" [class.rq-file-upload-busy]="progress() !== null">
      <input type="file" class="rq-file-upload-input" [accept]="accept()" [multiple]="multiple()"
             [disabled]="progress() !== null" (change)="choose($event)" />
      <span class="rq-file-upload-label">{{ label() }}</span>
    </label>
    @if (progress() !== null) {
      <progress class="rq-file-upload-progress" max="100" [value]="progress()"></progress>
    }
  `,
                }]
        }], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: true }] }], field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: false }] }], accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], uploaded: [{ type: i0.Output, args: ["uploaded"] }] } });
/**
 * The documents of a place of the API, each one a link that downloads it:
 *
 *     <rq-document-list #list path="/api/pets/7/documents" />
 */
class RqDocumentList {
    path = input.required(...(ngDevMode ? [{ debugName: "path" }] : []));
    empty = input('No documents', ...(ngDevMode ? [{ debugName: "empty" }] : []));
    /** Change it to read the list again (or call reload()). */
    version = input(0, ...(ngDevMode ? [{ debugName: "version" }] : []));
    documents = signal([], ...(ngDevMode ? [{ debugName: "documents" }] : []));
    size = formatSize;
    api = inject(PlatformApiService);
    constructor() {
        effect(() => {
            this.version();
            void this.load(this.path());
        });
    }
    async reload() {
        await this.load(this.path());
    }
    idOf(d) {
        return d.id ?? d.key ?? d.name ?? '';
    }
    nameOf(d) {
        return d.name ?? (d.key ?? '').split('/').pop() ?? '';
    }
    download(d) {
        return this.api.download(`${this.path()}/${encodeURIComponent(this.idOf(d))}`, this.nameOf(d));
    }
    async load(path) {
        this.documents.set(await this.api.documents(path));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqDocumentList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqDocumentList, isStandalone: true, selector: "rq-document-list", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: true, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @if (documents().length === 0) {
      <p class="rq-document-list-empty">{{ empty() }}</p>
    } @else {
      <ul class="rq-document-list">
        @for (d of documents(); track idOf(d)) {
          <li class="rq-document">
            <a class="rq-document-name" href="" (click)="$event.preventDefault(); download(d)">{{ nameOf(d) }}</a>
            <small class="rq-document-size">{{ size(d.size) }}</small>
          </li>
        }
      </ul>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqDocumentList, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-document-list',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (documents().length === 0) {
      <p class="rq-document-list-empty">{{ empty() }}</p>
    } @else {
      <ul class="rq-document-list">
        @for (d of documents(); track idOf(d)) {
          <li class="rq-document">
            <a class="rq-document-name" href="" (click)="$event.preventDefault(); download(d)">{{ nameOf(d) }}</a>
            <small class="rq-document-size">{{ size(d.size) }}</small>
          </li>
        }
      </ul>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: true }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }] } });
/**
 * The open tasks of the signed-in user in the processes of the application, each one with a button to complete it:
 *
 *     <rq-task-inbox path="/api/tasks" (completed)="refresh()" />
 */
class RqTaskInbox {
    path = input('/api/tasks', ...(ngDevMode ? [{ debugName: "path" }] : []));
    empty = input('Nothing to do', ...(ngDevMode ? [{ debugName: "empty" }] : []));
    completeLabel = input('Done', ...(ngDevMode ? [{ debugName: "completeLabel" }] : []));
    version = input(0, ...(ngDevMode ? [{ debugName: "version" }] : []));
    /** The task just completed. */
    completed = output();
    tasks = signal([], ...(ngDevMode ? [{ debugName: "tasks" }] : []));
    busy = signal(null, ...(ngDevMode ? [{ debugName: "busy" }] : []));
    count = computed(() => this.tasks().length, ...(ngDevMode ? [{ debugName: "count" }] : []));
    api = inject(PlatformApiService);
    constructor() {
        effect(() => {
            this.version();
            void this.load(this.path());
        });
    }
    async reload() {
        await this.load(this.path());
    }
    async complete(task, variables = {}) {
        this.busy.set(task.id);
        try {
            await this.api.complete(this.path(), task.id, variables);
            this.completed.emit(task);
            await this.reload();
        }
        finally {
            this.busy.set(null);
        }
    }
    async load(path) {
        this.tasks.set(await this.api.tasks(path));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqTaskInbox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqTaskInbox, isStandalone: true, selector: "rq-task-inbox", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, completeLabel: { classPropertyName: "completeLabel", publicName: "completeLabel", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { completed: "completed" }, ngImport: i0, template: `
    @if (tasks().length === 0) {
      <p class="rq-task-inbox-empty">{{ empty() }}</p>
    } @else {
      <ul class="rq-task-inbox">
        @for (t of tasks(); track t.id) {
          <li class="rq-task">
            <span class="rq-task-name">{{ t.name || t.task }}</span>
            @if (t.due) {
              <small class="rq-task-due">{{ t.due }}</small>
            }
            <button type="button" class="rq-task-complete" [disabled]="busy() === t.id" (click)="complete(t)">
              {{ completeLabel() }}
            </button>
          </li>
        }
      </ul>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqTaskInbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-task-inbox',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (tasks().length === 0) {
      <p class="rq-task-inbox-empty">{{ empty() }}</p>
    } @else {
      <ul class="rq-task-inbox">
        @for (t of tasks(); track t.id) {
          <li class="rq-task">
            <span class="rq-task-name">{{ t.name || t.task }}</span>
            @if (t.due) {
              <small class="rq-task-due">{{ t.due }}</small>
            }
            <button type="button" class="rq-task-complete" [disabled]="busy() === t.id" (click)="complete(t)">
              {{ completeLabel() }}
            </button>
          </li>
        }
      </ul>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: false }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], completeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "completeLabel", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }], completed: [{ type: i0.Output, args: ["completed"] }] } });

/*
 * Public API of refresquito-angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthService, ConfigService, KeycloakAuthService, LoggerService, NotificationService, PlatformApiService, RQ_KEYCLOAK_FACTORY, RQ_OPTIONS, RQ_SILENT, RqDocumentList, RqErrorHandler, RqFileUpload, RqHasRole, RqHttpError, RqNotifications, RqTaskInbox, authGuard, authInterceptor, errorInterceptor, formatSize, provideRefresquito, toRqHttpError };
//# sourceMappingURL=refresquito-angular.mjs.map
