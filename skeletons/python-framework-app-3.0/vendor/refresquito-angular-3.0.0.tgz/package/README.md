# refresquito-angular

Angular library of the Refresquito platform. It gives every application the same answers to the
same questions, so an application only writes its own screens:

| What | How |
|---|---|
| **Start-up** | `provideRefresquito()` in `app.config.ts` |
| **Runtime configuration** | `config.json` read at start-up (`ConfigService`): one build runs on any cluster |
| **Keycloak** | `AuthService` (user, roles, login, logout), `authGuard` for routes, `*rqHasRole` for templates |
| **HTTP** | The token is added to the calls to the API; a failed call throws an `RqHttpError` built from the `problem+json` of the API |
| **Messages for the user** | `NotificationService` and `<rq-notifications />`; HTTP errors are shown by themselves |
| **Logs** | `LoggerService`, with the level of `config.json` |
| **Platform blocks** (3.0) | `<rq-file-upload>`, `<rq-document-list>`, `<rq-task-inbox>` and `PlatformApiService`: files in its buckets or Alfresco sites, and the tasks of its processes, through its API |
| **Tests** | `refresquito-angular/testing`: `provideRefresquitoTesting()` and a fake `AuthService`, no Keycloak |

It pairs with [`refresquito-fastapi`](https://github.com/javivillar/refresquito-fastapi) on the API
side; the example application built with both is [`petstore`](https://github.com/javivillar/petstore).

## Install

```bash
npm install refresquito-angular keycloak-js
```

Angular 20 or later.

## An application

`public/config.json`, the only file that changes between clusters:

```json
{
  "apiUrl": "https://petstore.platform.example.io",
  "keycloak": { "url": "https://iam.platform.example.io", "realm": "RefresquitoTime", "clientId": "petstore" }
}
```

`apiUrl` can be `""` when the API is served on the same origin as the application.

```ts
// app.config.ts
export const appConfig: ApplicationConfig = {
  providers: [provideRouter(routes), provideRefresquito()],
};

// app.routes.ts
export const routes: Routes = [
  { path: 'pets', component: PetList, canActivate: [authGuard] },
  { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } },
  { path: 'forbidden', component: Forbidden },
];
```

```html
<rq-notifications />
@if (auth.user(); as user) {
  <span>{{ user.name }}</span> <button (click)="auth.logout()">Sign out</button>
} @else {
  <button (click)="auth.login()">Sign in</button>
}
<button *rqHasRole="'petstore-admin'" (click)="remove(pet)">Delete</button>
```

```ts
// a service: HttpClient as usual, the token and the error handling come with it
list() { return this.http.get<Page<Pet>>(`${this.config.apiUrl}/api/pets`); }

// a form: validation errors come field by field
save().subscribe({ error: (e: RqHttpError) => this.fieldErrors.set(e.fieldErrors) });
```

`provideRefresquito({ onLoad: 'login-required' })` asks for a login before showing anything.
`*rqHasRole` and `authGuard` only hide: what must not happen has to be refused by the API.

## Errors

A failed call throws an `RqHttpError`: `status`, `code` (the stable part, e.g. `pet_name_taken`),
`message`, `requestId` and `fieldErrors`. The user is told with a notification that carries the
request ID, except for validation errors (422), which belong next to their fields, and for
requests marked `context: new HttpContext().set(RQ_SILENT, true)`.

## Platform blocks

With refresquito-fastapi 3.0 the API of the application uses the blocks it declares (s3, dms, processes). Three
components show them, calling only that API with the token of the user, on paths that follow one contract:

| Call | Answer |
|---|---|
| `GET <path>` | the documents of a place: `[{id or key, name, size, mime_type or content_type, modified_at}]` |
| `POST <path>` | multipart, the file in `file`: upload one |
| `GET <path>/<id>` | the file itself, or `{"url": "<presigned URL>"}` to go to (S3) |
| `GET <tasks>` | the open tasks of the user: `[{id, name, due, ...}]` |
| `POST <tasks>/<id>/complete` | complete one (its variables as the JSON body) |

```html
<rq-file-upload path="/api/pets/7/documents" accept="application/pdf" (uploaded)="version.set(version() + 1)" />
<rq-document-list path="/api/pets/7/documents" [version]="version()" />
<rq-task-inbox path="/api/tasks" (completed)="refresh()" />
```

A download the API answers as a file is saved; one it answers with `{"url"}` (a presigned URL of S3) is opened as a
navigation, so S3 needs no CORS. Upload goes through the API too. They are unstyled: style their `rq-*` classes.
`PlatformApiService` makes the same calls without the components. The application template generates these API
paths for the blocks it marks.

## Tests of an application

```ts
TestBed.configureTestingModule({
  providers: [provideRefresquitoTesting({ user: { username: 'ana', roles: ['petstore-admin'] } })],
});
const auth = TestBed.inject(FakeAuthService);
auth.signIn(null);                      // nobody signed in
const backend = TestBed.inject(HttpTestingController);   // HttpClient is the testing one
```

## Not here yet

Each piece enters when an application needs it: a layout shell, translations, and a generator of
the API client from OpenAPI (the petstore generates its types with `openapi-typescript`).
