import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, Injectable, input, TemplateRef, ViewContainerRef, effect, Directive, ChangeDetectionStrategy, Component, makeEnvironmentProviders, ErrorHandler, provideAppInitializer, output, viewChild, afterNextRender, ViewEncapsulation } from '@angular/core';
import Keycloak from 'keycloak-js';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { HttpContextToken, HttpErrorResponse, provideHttpClient, withInterceptors, HttpClient, HttpEventType } from '@angular/common/http';
import { from, switchMap, catchError, throwError, firstValueFrom } from 'rxjs';
import { DatePipe, DOCUMENT } from '@angular/common';

const RQ_OPTIONS = new InjectionToken('RQ_OPTIONS', { factory: () => ({}) });
/**
 * The configuration of the running application, read once at start-up from `config.json`. The
 * same build runs on any cluster: only that file changes.
 */
class ConfigService {
    options = inject(RQ_OPTIONS);
    value = signal(null, ...(ngDevMode ? [{ debugName: "value" }] : []));
    /** The configuration. It throws if it is read before the application has started. */
    config = computed(() => {
        const config = this.value();
        if (!config) {
            throw new Error('The configuration is not loaded yet: is provideRefresquito() in the providers?');
        }
        return config;
    }, ...(ngDevMode ? [{ debugName: "config" }] : []));
    get apiUrl() {
        return this.config().apiUrl;
    }
    async load(fetcher = fetch) {
        const url = this.options.configUrl ?? 'config.json';
        const response = await fetcher(url, { cache: 'no-store' });
        if (!response.ok) {
            throw new Error(`Cannot read the configuration from ${url}: HTTP ${response.status}`);
        }
        return this.set((await response.json()));
    }
    set(config) {
        const missing = [
            !config?.apiUrl && config?.apiUrl !== '' ? 'apiUrl' : null,
            !config?.keycloak?.url ? 'keycloak.url' : null,
            !config?.keycloak?.realm ? 'keycloak.realm' : null,
            !config?.keycloak?.clientId ? 'keycloak.clientId' : null,
        ].filter(Boolean);
        if (missing.length) {
            throw new Error(`The configuration has no ${missing.join(', ')}`);
        }
        const clean = { ...config, apiUrl: config.apiUrl.replace(/\/+$/, '') };
        this.value.set(clean);
        return clean;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const ORDER = ['debug', 'info', 'warn', 'error'];
/** Console logs with a level and a context object, filtered by `logLevel` of the configuration. */
class LoggerService {
    configuration = inject(ConfigService);
    debug(message, context) {
        this.write('debug', message, context);
    }
    info(message, context) {
        this.write('info', message, context);
    }
    warn(message, context) {
        this.write('warn', message, context);
    }
    error(message, context) {
        this.write('error', message, context);
    }
    level() {
        try {
            return this.configuration.config().logLevel ?? 'info';
        }
        catch {
            return 'info'; // before the configuration is loaded
        }
    }
    write(level, message, context) {
        if (ORDER.indexOf(level) < ORDER.indexOf(this.level())) {
            return;
        }
        const args = [`[${level}] ${message}`];
        if (context !== undefined) {
            args.push(context);
        }
        console[level](...args);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Who is using the application. The implementation talks to Keycloak; tests provide a fake one
 * (`provideRefresquitoTesting`), so components never import keycloak-js.
 */
class AuthService {
    isLoggedIn = computed(() => this.user() !== null, ...(ngDevMode ? [{ debugName: "isLoggedIn" }] : []));
    /** True if the user has any of these roles. */
    hasRole(...roles) {
        const mine = this.user()?.roles ?? [];
        return roles.some((role) => mine.includes(role));
    }
}
/** How the Keycloak client is built. Replaced in tests. */
const RQ_KEYCLOAK_FACTORY = new InjectionToken('RQ_KEYCLOAK_FACTORY', {
    factory: () => (config) => new Keycloak(config),
});
class KeycloakAuthService extends AuthService {
    configuration = inject(ConfigService);
    options = inject(RQ_OPTIONS);
    factory = inject(RQ_KEYCLOAK_FACTORY);
    log = inject(LoggerService);
    keycloak;
    current = signal(null, ...(ngDevMode ? [{ debugName: "current" }] : []));
    user = this.current.asReadonly();
    async init() {
        const { url, realm, clientId } = this.configuration.config().keycloak;
        this.keycloak = this.factory({ url, realm, clientId });
        this.keycloak.onAuthLogout = () => this.current.set(null);
        this.keycloak.onAuthRefreshSuccess = () => this.read();
        await this.keycloak.init({
            onLoad: this.options.onLoad ?? 'check-sso',
            pkceMethod: 'S256',
            // the session iframe needs third-party cookies, which browsers block
            checkLoginIframe: false,
        });
        this.read();
    }
    async login(redirectUrl) {
        await this.client().login({ redirectUri: this.absolute(redirectUrl) });
    }
    async logout(redirectUrl) {
        await this.client().logout({ redirectUri: this.absolute(redirectUrl ?? '/') });
    }
    async token() {
        const keycloak = this.client();
        if (!keycloak.authenticated) {
            return null;
        }
        try {
            await keycloak.updateToken(30);
        }
        catch (error) {
            // the session ended in Keycloak: nobody is signed in any more
            this.log.warn('The token could not be refreshed', { error: String(error) });
            this.current.set(null);
            return null;
        }
        return keycloak.token ?? null;
    }
    client() {
        if (!this.keycloak) {
            throw new Error('AuthService is used before the application has started');
        }
        return this.keycloak;
    }
    absolute(url) {
        return new URL(url ?? window.location.href, window.location.href).toString();
    }
    read() {
        const keycloak = this.client();
        const claims = keycloak.tokenParsed;
        if (!keycloak.authenticated || !claims) {
            this.current.set(null);
            return;
        }
        const clientId = this.configuration.config().keycloak.clientId;
        const roles = new Set([
            ...(claims.realm_access?.roles ?? []),
            ...(claims.resource_access?.[clientId]?.roles ?? []),
        ]);
        this.current.set({
            username: claims['preferred_username'] ?? claims.sub ?? '',
            name: claims['name'],
            email: claims['email'],
            roles: [...roles].sort(),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService, decorators: [{
            type: Injectable
        }] });

/**
 * A route for signed-in users only, and optionally only for some roles:
 *
 *     { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } }
 *
 * Nobody signed in: the browser goes to Keycloak and comes back to the route. Signed in without
 * any of the roles: the route `data.forbiddenUrl`, or `/forbidden`.
 */
const authGuard = async (route, state) => {
    const auth = inject(AuthService);
    const router = inject(Router);
    if (!auth.isLoggedIn()) {
        await auth.login(state.url);
        return false;
    }
    const roles = route.data?.['roles'] ?? [];
    if (roles.length && !auth.hasRole(...roles)) {
        return router.parseUrl(route.data?.['forbiddenUrl'] ?? '/forbidden');
    }
    return true;
};

/**
 * Renders its content only for users with one of the roles:
 *
 *     <button *rqHasRole="'petstore-admin'">Delete</button>
 *     <a *rqHasRole="['petstore-admin', 'petstore-viewer']" routerLink="/pets">Pets</a>
 *
 * It only hides: what must not happen is refused by the API.
 */
class RqHasRole {
    rqHasRole = input.required(...(ngDevMode ? [{ debugName: "rqHasRole" }] : []));
    auth = inject(AuthService);
    template = inject((TemplateRef));
    container = inject(ViewContainerRef);
    shown = false;
    constructor() {
        effect(() => {
            const roles = this.rqHasRole();
            const allowed = this.auth.hasRole(...(Array.isArray(roles) ? roles : [roles]));
            if (allowed && !this.shown) {
                this.container.createEmbeddedView(this.template);
            }
            else if (!allowed && this.shown) {
                this.container.clear();
            }
            this.shown = allowed;
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqHasRole, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.33", type: RqHasRole, isStandalone: true, selector: "[rqHasRole]", inputs: { rqHasRole: { classPropertyName: "rqHasRole", publicName: "rqHasRole", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqHasRole, decorators: [{
            type: Directive,
            args: [{ selector: '[rqHasRole]' }]
        }], ctorParameters: () => [], propDecorators: { rqHasRole: [{ type: i0.Input, args: [{ isSignal: true, alias: "rqHasRole", required: true }] }] } });

/** Messages for the user. Show them with `<rq-notifications />` or read `messages` yourself. */
class NotificationService {
    next = 1;
    list = signal([], ...(ngDevMode ? [{ debugName: "list" }] : []));
    messages = this.list.asReadonly();
    info(message) {
        return this.add('info', message);
    }
    success(message) {
        return this.add('success', message);
    }
    error(message, reference) {
        return this.add('error', message, reference);
    }
    dismiss(id) {
        this.list.update((all) => all.filter((n) => n.id !== id));
    }
    clear() {
        this.list.set([]);
    }
    add(kind, message, reference) {
        const id = this.next++;
        this.list.update((all) => [...all, { id, kind, message, reference }]);
        return id;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * The pending notifications, each with a button to dismiss it: Bootstrap alerts (styles/refresquito.scss); the
 * `rq-notification` classes are still there to restyle them.
 */
class RqNotifications {
    notifications = inject(NotificationService);
    alertClass = {
        info: 'alert-primary', success: 'alert-success', error: 'alert-danger',
    };
    iconClass = {
        info: 'bi-info-circle', success: 'bi-check-circle', error: 'bi-exclamation-triangle',
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqNotifications, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqNotifications, isStandalone: true, selector: "rq-notifications", ngImport: i0, template: `
    @if (notifications.messages().length > 0) {
      <div class="rq-notifications">
        @for (n of notifications.messages(); track n.id) {
          <div [class]="'alert rq-notification rq-notification-' + n.kind + ' ' + alertClass[n.kind]"
               [attr.role]="n.kind === 'error' ? 'alert' : 'status'">
            <i [class]="'bi ' + iconClass[n.kind]" aria-hidden="true"></i>
            <span class="rq-notification-message">{{ n.message }}</span>
            @if (n.reference) {
              <small class="rq-notification-reference">Ref. {{ n.reference }}</small>
            }
            <button type="button" class="btn-close rq-notification-dismiss" aria-label="Dismiss" (click)="notifications.dismiss(n.id)"></button>
          </div>
        }
      </div>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqNotifications, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-notifications',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (notifications.messages().length > 0) {
      <div class="rq-notifications">
        @for (n of notifications.messages(); track n.id) {
          <div [class]="'alert rq-notification rq-notification-' + n.kind + ' ' + alertClass[n.kind]"
               [attr.role]="n.kind === 'error' ? 'alert' : 'status'">
            <i [class]="'bi ' + iconClass[n.kind]" aria-hidden="true"></i>
            <span class="rq-notification-message">{{ n.message }}</span>
            @if (n.reference) {
              <small class="rq-notification-reference">Ref. {{ n.reference }}</small>
            }
            <button type="button" class="btn-close rq-notification-dismiss" aria-label="Dismiss" (click)="notifications.dismiss(n.id)"></button>
          </div>
        }
      </div>
    }
  `,
                }]
        }] });

/** What a failed call throws: the problem document, or the closest thing when the answer was not one. */
class RqHttpError extends Error {
    status;
    code;
    problem;
    cause_;
    constructor(status, code, message, problem, cause_) {
        super(message);
        this.status = status;
        this.code = code;
        this.problem = problem;
        this.cause_ = cause_;
        this.name = 'RqHttpError';
    }
    get requestId() {
        return this.problem?.request_id ?? this.cause_.headers?.get('X-Request-ID') ?? undefined;
    }
    /** The message of each invalid field, by field name. */
    get fieldErrors() {
        return Object.fromEntries((this.problem?.errors ?? []).map((e) => [e.field, e.message]));
    }
}
function toRqHttpError(response) {
    const body = response.error;
    const problem = body && typeof body === 'object' && typeof body.status === 'number' ? body : null;
    if (problem) {
        return new RqHttpError(response.status, problem.code ?? 'error', problem.detail ?? problem.title ?? 'Error', problem, response);
    }
    if (response.status === 0) {
        return new RqHttpError(0, 'network_error', 'The server cannot be reached', null, response);
    }
    return new RqHttpError(response.status, 'error', response.statusText || `HTTP ${response.status}`, null, response);
}
/** Set it on a request whose errors the caller shows by itself: `context: new HttpContext().set(RQ_SILENT, true)`. */
const RQ_SILENT = new HttpContextToken(() => false);
/** Adds the token of the signed-in user to the calls to the API of the application, and to no other. */
const authInterceptor = (request, next) => {
    const api = inject(ConfigService).apiUrl;
    const auth = inject(AuthService);
    const toApi = api === '' ? !/^https?:\/\//.test(request.url) : request.url === api || request.url.startsWith(`${api}/`);
    if (!toApi || !auth.isLoggedIn()) {
        return next(request);
    }
    return from(auth.token()).pipe(switchMap((token) => next(token ? request.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : request)));
};
/** Turns a failed call into an `RqHttpError` and tells the user, unless the request is `RQ_SILENT`. */
const errorInterceptor = (request, next) => {
    const notifications = inject(NotificationService);
    const log = inject(LoggerService);
    return next(request).pipe(catchError((response) => {
        if (!(response instanceof HttpErrorResponse)) {
            return throwError(() => response);
        }
        const error = toRqHttpError(response);
        log.warn(`${request.method} ${request.url} failed`, { status: error.status, code: error.code, requestId: error.requestId });
        // validation errors belong next to their fields: the form shows them
        if (!request.context.get(RQ_SILENT) && error.status !== 422) {
            notifications.error(error.message, error.requestId);
        }
        return throwError(() => error);
    }));
};
/** Anything nobody caught: logged, and the user told that something failed. */
class RqErrorHandler {
    log = inject(LoggerService);
    notifications = inject(NotificationService);
    handleError(error) {
        if (error instanceof RqHttpError) {
            return; // the interceptor already logged it and told the user
        }
        this.log.error('Unexpected error', { error });
        this.notifications.error('Something went wrong');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler, decorators: [{
            type: Injectable
        }] });

/**
 * Everything of the framework, in `app.config.ts`:
 *
 *     providers: [provideRouter(routes), provideRefresquito()]
 *
 * Before the application starts it reads `config.json` and asks Keycloak who is signed in.
 * HttpClient comes configured: calls to the API carry the token, and errors are
 * `RqHttpError` and are shown to the user.
 */
function provideRefresquito(options = {}) {
    return makeEnvironmentProviders([
        { provide: RQ_OPTIONS, useValue: options },
        { provide: AuthService, useClass: KeycloakAuthService },
        { provide: ErrorHandler, useClass: RqErrorHandler },
        provideHttpClient(withInterceptors([authInterceptor, errorInterceptor])),
        provideAppInitializer(async () => {
            const config = inject(ConfigService);
            const auth = inject(AuthService);
            await config.load();
            await auth.init();
        }),
    ]);
}

/** The calls of the components, to use them without the components too. */
class PlatformApiService {
    http = inject(HttpClient);
    config = inject(ConfigService);
    url(path) {
        return /^https?:\/\//.test(path) ? path : `${this.config.apiUrl}${path}`;
    }
    documents(path) {
        return firstValueFrom(this.http.get(this.url(path)));
    }
    /** Upload a file (multipart, field `file` by default), with its progress. */
    upload(path, file, field = 'file') {
        const form = new FormData();
        form.append(field, file, file.name);
        return this.http.post(this.url(path), form, { reportProgress: true, observe: 'events' });
    }
    /** Download: the file the API answers is saved; a {"url"} it answers (a presigned URL of S3) is opened. */
    async download(path, filename) {
        const response = await firstValueFrom(this.http.get(this.url(path), { observe: 'response', responseType: 'blob' }));
        const blob = response.body ?? new Blob();
        if ((response.headers.get('content-type') ?? '').startsWith('application/json')) {
            const answer = JSON.parse(await blob.text());
            if (answer.url) {
                this.open(answer.url);
                return;
            }
        }
        this.save(blob, filename ?? filenameOf(response) ?? 'download');
    }
    tasks(path) {
        return firstValueFrom(this.http.get(this.url(path)));
    }
    complete(path, taskId, variables = {}) {
        return firstValueFrom(this.http.post(this.url(`${path}/${encodeURIComponent(taskId)}/complete`), variables));
    }
    /** Go to a URL (a navigation: no CORS needed). */
    open(url) {
        const link = document.createElement('a');
        link.href = url;
        link.rel = 'noopener';
        link.click();
    }
    /** Save a blob as a file of the user. */
    save(blob, filename) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PlatformApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PlatformApiService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PlatformApiService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function filenameOf(response) {
    const disposition = response.headers.get('content-disposition') ?? '';
    return /filename\*?="?(?:UTF-8'')?([^";]+)"?/i.exec(disposition)?.[1];
}
/** 1536 -> "1.5 KB". */
function formatSize(bytes) {
    if (bytes == null) {
        return '';
    }
    const units = ['B', 'KB', 'MB', 'GB'];
    let value = bytes;
    let unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
        value /= 1024;
        unit++;
    }
    return `${unit === 0 ? value : value.toFixed(1)} ${units[unit]}`;
}
/**
 * A button to upload files to the API of the application, with their progress:
 *
 *     <rq-file-upload path="/api/pets/7/documents" accept="application/pdf" (uploaded)="list.reload()" />
 */
class RqFileUpload {
    path = input.required(...(ngDevMode ? [{ debugName: "path" }] : []));
    field = input('file', ...(ngDevMode ? [{ debugName: "field" }] : []));
    accept = input('', ...(ngDevMode ? [{ debugName: "accept" }] : []));
    multiple = input(false, ...(ngDevMode ? [{ debugName: "multiple" }] : []));
    label = input('Upload', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** What the API answered, for each file uploaded. */
    uploaded = output();
    progress = signal(null, ...(ngDevMode ? [{ debugName: "progress" }] : []));
    api = inject(PlatformApiService);
    async choose(event) {
        const element = event.target;
        const files = [...(element.files ?? [])];
        element.value = '';
        for (const file of files) {
            await this.send(file);
        }
    }
    /** Upload one file (what choosing it in the button does). */
    async send(file) {
        this.progress.set(0);
        try {
            const body = await new Promise((resolve, reject) => this.api.upload(this.path(), file, this.field()).subscribe({
                next: (event) => {
                    if (event.type === HttpEventType.UploadProgress && event.total) {
                        this.progress.set(Math.round((100 * event.loaded) / event.total));
                    }
                    else if (event.type === HttpEventType.Response) {
                        resolve(event.body);
                    }
                },
                error: reject,
            }));
            this.uploaded.emit(body);
        }
        finally {
            this.progress.set(null);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqFileUpload, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqFileUpload, isStandalone: true, selector: "rq-file-upload", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: true, transformFunction: null }, field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null }, accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { uploaded: "uploaded" }, ngImport: i0, template: `
    <label class="rq-file-upload" [class.rq-file-upload-busy]="progress() !== null">
      <input type="file" class="rq-file-upload-input" [accept]="accept()" [multiple]="multiple()"
             [disabled]="progress() !== null" (change)="choose($event)" />
      <i class="bi bi-cloud-arrow-up" aria-hidden="true"></i>
      <span class="rq-file-upload-label">{{ label() }}</span>
    </label>
    @if (progress() !== null) {
      <div class="progress rq-file-upload-progress" role="progressbar" [attr.aria-valuenow]="progress()" aria-valuemin="0" aria-valuemax="100" [attr.aria-label]="label()">
        <div class="progress-bar" [style.width.%]="progress()"></div>
      </div>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqFileUpload, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-file-upload',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <label class="rq-file-upload" [class.rq-file-upload-busy]="progress() !== null">
      <input type="file" class="rq-file-upload-input" [accept]="accept()" [multiple]="multiple()"
             [disabled]="progress() !== null" (change)="choose($event)" />
      <i class="bi bi-cloud-arrow-up" aria-hidden="true"></i>
      <span class="rq-file-upload-label">{{ label() }}</span>
    </label>
    @if (progress() !== null) {
      <div class="progress rq-file-upload-progress" role="progressbar" [attr.aria-valuenow]="progress()" aria-valuemin="0" aria-valuemax="100" [attr.aria-label]="label()">
        <div class="progress-bar" [style.width.%]="progress()"></div>
      </div>
    }
  `,
                }]
        }], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: true }] }], field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: false }] }], accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], uploaded: [{ type: i0.Output, args: ["uploaded"] }] } });
/**
 * The documents of a place of the API, each one a link that downloads it:
 *
 *     <rq-document-list #list path="/api/pets/7/documents" />
 */
class RqDocumentList {
    path = input.required(...(ngDevMode ? [{ debugName: "path" }] : []));
    empty = input('No documents', ...(ngDevMode ? [{ debugName: "empty" }] : []));
    /** Change it to read the list again (or call reload()). */
    version = input(0, ...(ngDevMode ? [{ debugName: "version" }] : []));
    documents = signal([], ...(ngDevMode ? [{ debugName: "documents" }] : []));
    size = formatSize;
    api = inject(PlatformApiService);
    constructor() {
        effect(() => {
            this.version();
            void this.load(this.path());
        });
    }
    async reload() {
        await this.load(this.path());
    }
    idOf(d) {
        return d.id ?? d.key ?? d.name ?? '';
    }
    /** The kind of file, for its icon: pdf, image, sheet or file. */
    kindOf(d) {
        const type = (d.mime_type ?? d.content_type ?? '').toLowerCase();
        const name = this.nameOf(d).toLowerCase();
        if (type === 'application/pdf' || name.endsWith('.pdf'))
            return 'pdf';
        if (type.startsWith('image/') || /\.(png|jpe?g|gif|webp|svg)$/.test(name))
            return 'image';
        if (type.includes('spreadsheet') || type.includes('csv') || /\.(xlsx?|ods|csv)$/.test(name))
            return 'sheet';
        return 'file';
    }
    iconOf(d) {
        return { pdf: 'bi-file-earmark-pdf', image: 'bi-file-earmark-image', sheet: 'bi-file-earmark-spreadsheet' }[this.kindOf(d)]
            ?? 'bi-file-earmark';
    }
    nameOf(d) {
        return d.name ?? (d.key ?? '').split('/').pop() ?? '';
    }
    download(d) {
        return this.api.download(`${this.path()}/${encodeURIComponent(this.idOf(d))}`, this.nameOf(d));
    }
    async load(path) {
        this.documents.set(await this.api.documents(path));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqDocumentList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqDocumentList, isStandalone: true, selector: "rq-document-list", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: true, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @if (documents().length === 0) {
      <p class="rq-document-list-empty">{{ empty() }}</p>
    } @else {
      <ul class="list-group list-group-flush rq-document-list">
        @for (d of documents(); track idOf(d)) {
          <li class="list-group-item list-group-item-action rq-document">
            <span [class]="'rq-document-icon rq-document-icon-' + kindOf(d)" aria-hidden="true"><i [class]="'bi ' + iconOf(d)"></i></span>
            <span class="flex-grow-1 text-truncate">
              <a class="rq-document-name" href="" (click)="$event.preventDefault(); download(d)">{{ nameOf(d) }}</a>
              <small class="rq-document-size d-block">{{ size(d.size) }}</small>
            </span>
            <button type="button" class="btn btn-outline-secondary btn-sm" [attr.aria-label]="'Download ' + nameOf(d)" (click)="download(d)">
              <i class="bi bi-download" aria-hidden="true"></i>
            </button>
          </li>
        }
      </ul>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqDocumentList, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-document-list',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (documents().length === 0) {
      <p class="rq-document-list-empty">{{ empty() }}</p>
    } @else {
      <ul class="list-group list-group-flush rq-document-list">
        @for (d of documents(); track idOf(d)) {
          <li class="list-group-item list-group-item-action rq-document">
            <span [class]="'rq-document-icon rq-document-icon-' + kindOf(d)" aria-hidden="true"><i [class]="'bi ' + iconOf(d)"></i></span>
            <span class="flex-grow-1 text-truncate">
              <a class="rq-document-name" href="" (click)="$event.preventDefault(); download(d)">{{ nameOf(d) }}</a>
              <small class="rq-document-size d-block">{{ size(d.size) }}</small>
            </span>
            <button type="button" class="btn btn-outline-secondary btn-sm" [attr.aria-label]="'Download ' + nameOf(d)" (click)="download(d)">
              <i class="bi bi-download" aria-hidden="true"></i>
            </button>
          </li>
        }
      </ul>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: true }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }] } });
/**
 * The open tasks of the signed-in user in the processes of the application, each one with a button to complete it:
 *
 *     <rq-task-inbox path="/api/tasks" (completed)="refresh()" />
 */
class RqTaskInbox {
    path = input('/api/tasks', ...(ngDevMode ? [{ debugName: "path" }] : []));
    empty = input('Nothing to do', ...(ngDevMode ? [{ debugName: "empty" }] : []));
    completeLabel = input('Done', ...(ngDevMode ? [{ debugName: "completeLabel" }] : []));
    version = input(0, ...(ngDevMode ? [{ debugName: "version" }] : []));
    /** The task just completed. */
    completed = output();
    tasks = signal([], ...(ngDevMode ? [{ debugName: "tasks" }] : []));
    busy = signal(null, ...(ngDevMode ? [{ debugName: "busy" }] : []));
    count = computed(() => this.tasks().length, ...(ngDevMode ? [{ debugName: "count" }] : []));
    api = inject(PlatformApiService);
    constructor() {
        effect(() => {
            this.version();
            void this.load(this.path());
        });
    }
    async reload() {
        await this.load(this.path());
    }
    async complete(task, variables = {}) {
        this.busy.set(task.id);
        try {
            await this.api.complete(this.path(), task.id, variables);
            this.completed.emit(task);
            await this.reload();
        }
        finally {
            this.busy.set(null);
        }
    }
    async load(path) {
        this.tasks.set(await this.api.tasks(path));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqTaskInbox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqTaskInbox, isStandalone: true, selector: "rq-task-inbox", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, completeLabel: { classPropertyName: "completeLabel", publicName: "completeLabel", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { completed: "completed" }, ngImport: i0, template: `
    @if (tasks().length === 0) {
      <p class="rq-task-inbox-empty">{{ empty() }}</p>
    } @else {
      <ul class="list-group list-group-flush rq-task-inbox">
        @for (t of tasks(); track t.id) {
          <li class="list-group-item rq-task">
            <span class="rq-task-dot" aria-hidden="true"></span>
            <span class="flex-grow-1">
              <span class="rq-task-name d-block">{{ t.name || t.task }}</span>
              @if (t.due) {
                <small class="rq-task-due">{{ t.due }}</small>
              }
            </span>
            <button type="button" class="btn btn-primary btn-sm rq-task-complete" [disabled]="busy() === t.id" (click)="complete(t)">
              @if (busy() === t.id) {
                <span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span>
              }
              {{ completeLabel() }}
            </button>
          </li>
        }
      </ul>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqTaskInbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-task-inbox',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (tasks().length === 0) {
      <p class="rq-task-inbox-empty">{{ empty() }}</p>
    } @else {
      <ul class="list-group list-group-flush rq-task-inbox">
        @for (t of tasks(); track t.id) {
          <li class="list-group-item rq-task">
            <span class="rq-task-dot" aria-hidden="true"></span>
            <span class="flex-grow-1">
              <span class="rq-task-name d-block">{{ t.name || t.task }}</span>
              @if (t.due) {
                <small class="rq-task-due">{{ t.due }}</small>
              }
            </span>
            <button type="button" class="btn btn-primary btn-sm rq-task-complete" [disabled]="busy() === t.id" (click)="complete(t)">
              @if (busy() === t.id) {
                <span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span>
              }
              {{ completeLabel() }}
            </button>
          </li>
        }
      </ul>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: false }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], completeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "completeLabel", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }], completed: [{ type: i0.Output, args: ["completed"] }] } });

const RQ_SUPERSET_EMBED = new InjectionToken('RQ_SUPERSET_EMBED', {
    providedIn: 'root',
    // loaded when a dashboard is first shown: applications that embed none never download it. The package is CommonJS
    // under its `module` field: depending on the bundler the function is on the module or on its default export.
    factory: () => async (options) => {
        const sdk = (await import('@superset-ui/embedded-sdk'));
        const embed = sdk.embedDashboard ?? sdk.default?.embedDashboard;
        if (!embed) {
            throw new Error('@superset-ui/embedded-sdk has no embedDashboard');
        }
        return embed(options);
    },
});
/**
 * A dashboard of the application (Superset), embedded in its web. The API of the application gives the guest token
 * (`GET <path>/<name>/guest-token`, refresquito-fastapi 3.1), again each time it expires:
 *
 *     <rq-dashboard name="main" />
 *     <rq-dashboard name="sales" path="/api/dashboards" height="800px" [hideTitle]="false" />
 *
 * Superset only lets the hosts of the platform frame it, and only gives a token for a dashboard of the application.
 */
class RqDashboard {
    name = input.required(...(ngDevMode ? [{ debugName: "name" }] : []));
    path = input('/api/dashboards', ...(ngDevMode ? [{ debugName: "path" }] : []));
    height = input('600px', ...(ngDevMode ? [{ debugName: "height" }] : []));
    hideTitle = input(true, ...(ngDevMode ? [{ debugName: "hideTitle" }] : []));
    error = signal(null, ...(ngDevMode ? [{ debugName: "error" }] : []));
    mount = viewChild.required('mount');
    http = inject(HttpClient);
    config = inject(ConfigService);
    embed = inject(RQ_SUPERSET_EMBED);
    log = inject(LoggerService);
    constructor() {
        afterNextRender(() => void this.show());
    }
    /** The guest token of the dashboard, from the API of the application. */
    guestToken() {
        const path = this.path();
        const base = /^https?:\/\//.test(path) ? path : `${this.config.apiUrl}${path}`;
        return firstValueFrom(this.http.get(`${base}/${encodeURIComponent(this.name())}/guest-token`));
    }
    async show() {
        this.error.set(null);
        try {
            const first = await this.guestToken();
            let pending = first.token;
            await this.embed({
                id: first.uuid,
                supersetDomain: first.superset_url,
                mountPoint: this.mount().nativeElement,
                // the first token is the one just asked; Superset asks again when it expires
                fetchGuestToken: async () => {
                    const token = pending ?? (await this.guestToken()).token;
                    pending = null;
                    return token;
                },
                dashboardUiConfig: { hideTitle: this.hideTitle(), filters: { expanded: false } },
            });
        }
        catch (error) {
            // an HTTP error was already told to the user by the framework; anything else is logged here
            this.log.error(`Dashboard ${this.name()} cannot be shown`, { error: String(error) });
            this.error.set('The dashboard cannot be shown');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqDashboard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqDashboard, isStandalone: true, selector: "rq-dashboard", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, hideTitle: { classPropertyName: "hideTitle", publicName: "hideTitle", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "rq-dashboard-host" }, viewQueries: [{ propertyName: "mount", first: true, predicate: ["mount"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div #mount class="rq-dashboard" [style.height]="height()"></div>
    @if (error()) {
      <p class="rq-dashboard-error" role="alert">{{ error() }}</p>
    }
  `, isInline: true, styles: [".rq-dashboard-host{display:block}.rq-dashboard>iframe{display:block;width:100%;height:100%;border:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqDashboard, decorators: [{
            type: Component,
            args: [{ selector: 'rq-dashboard', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div #mount class="rq-dashboard" [style.height]="height()"></div>
    @if (error()) {
      <p class="rq-dashboard-error" role="alert">{{ error() }}</p>
    }
  `, encapsulation: ViewEncapsulation.None, host: { class: 'rq-dashboard-host' }, styles: [".rq-dashboard-host{display:block}.rq-dashboard>iframe{display:block;width:100%;height:100%;border:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], hideTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTitle", required: false }] }], mount: [{ type: i0.ViewChild, args: ['mount', { isSignal: true }] }] } });

/**
 * The latest runs of the flows of the application (Activepieces), as the flows told the API how they ended:
 *
 *     <rq-flow-runs />
 *     <rq-flow-runs flow="new-pet" [size]="5" />
 *
 * A run still `started` long after it began is a flow that ended without telling.
 */
class RqFlowRuns {
    /** The colour of a status (Bootstrap's subtle badges): succeeded green, failed red, started blue. */
    badgeOf(status) {
        return status === 'succeeded' ? 'bg-success-subtle text-success-emphasis'
            : status === 'failed' ? 'bg-danger-subtle text-danger-emphasis' : 'bg-primary-subtle text-primary-emphasis';
    }
    path = input('/api/flow-runs', ...(ngDevMode ? [{ debugName: "path" }] : []));
    flow = input(null, ...(ngDevMode ? [{ debugName: "flow" }] : []));
    size = input(20, ...(ngDevMode ? [{ debugName: "size" }] : []));
    empty = input('No runs yet', ...(ngDevMode ? [{ debugName: "empty" }] : []));
    version = input(0, ...(ngDevMode ? [{ debugName: "version" }] : []));
    runs = signal([], ...(ngDevMode ? [{ debugName: "runs" }] : []));
    http = inject(HttpClient);
    config = inject(ConfigService);
    constructor() {
        effect(() => {
            this.version();
            void this.reload();
        });
    }
    async reload() {
        const params = { page: 1, size: this.size() };
        const flow = this.flow();
        if (flow) {
            params['flow'] = flow;
        }
        const page = await firstValueFrom(this.http.get(`${this.config.apiUrl}${this.path()}`, { params }));
        this.runs.set(page.items);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqFlowRuns, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqFlowRuns, isStandalone: true, selector: "rq-flow-runs", inputs: { path: { classPropertyName: "path", publicName: "path", isSignal: true, isRequired: false, transformFunction: null }, flow: { classPropertyName: "flow", publicName: "flow", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @if (runs().length === 0) {
      <p class="rq-flow-runs-empty">{{ empty() }}</p>
    } @else {
      <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 rq-flow-runs">
        <thead>
          <tr><th>Flow</th><th>Status</th><th>Started</th><th>Ended</th><th>Detail</th></tr>
        </thead>
        <tbody>
          @for (r of runs(); track r.id) {
            <tr class="rq-flow-run rq-flow-run-{{ r.status }}">
              <td>{{ r.flow }}@if (r.event) { <small class="rq-flow-run-event">({{ r.event }})</small> }</td>
              <td class="rq-flow-run-status"><span [class]="'badge ' + badgeOf(r.status)">{{ r.status }}</span></td>
              <td>{{ r.started_at | date: 'short' }}</td>
              <td>{{ r.finished_at ? (r.finished_at | date: 'short') : '' }}</td>
              <td class="rq-flow-run-detail">{{ r.detail }}</td>
            </tr>
          }
        </tbody>
      </table>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "pipe", type: DatePipe, name: "date" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqFlowRuns, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-flow-runs',
                    imports: [DatePipe],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @if (runs().length === 0) {
      <p class="rq-flow-runs-empty">{{ empty() }}</p>
    } @else {
      <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 rq-flow-runs">
        <thead>
          <tr><th>Flow</th><th>Status</th><th>Started</th><th>Ended</th><th>Detail</th></tr>
        </thead>
        <tbody>
          @for (r of runs(); track r.id) {
            <tr class="rq-flow-run rq-flow-run-{{ r.status }}">
              <td>{{ r.flow }}@if (r.event) { <small class="rq-flow-run-event">({{ r.event }})</small> }</td>
              <td class="rq-flow-run-status"><span [class]="'badge ' + badgeOf(r.status)">{{ r.status }}</span></td>
              <td>{{ r.started_at | date: 'short' }}</td>
              <td>{{ r.finished_at ? (r.finished_at | date: 'short') : '' }}</td>
              <td class="rq-flow-run-detail">{{ r.detail }}</td>
            </tr>
          }
        </tbody>
      </table>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { path: [{ type: i0.Input, args: [{ isSignal: true, alias: "path", required: false }] }], flow: [{ type: i0.Input, args: [{ isSignal: true, alias: "flow", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }] } });

const THEME_KEY = 'rq-theme';
/**
 * The layout every application of Refresquito shares (the stylesheet `refresquito-angular/styles/refresquito.scss`):
 * a header with the name of the application, its stage, the user and the way out; a menu; the notifications; and the
 * page, projected inside:
 *
 *     <rq-shell title="Petstore" stage="dev" [nav]="nav" footer="Petstore 1.4.0">
 *       <router-outlet />
 *     </rq-shell>
 *
 * Light and dark mode (Bootstrap's `data-bs-theme`), remembered in the browser. On a phone the menu opens with a button.
 */
class RqShell {
    auth = inject(AuthService);
    document = inject(DOCUMENT);
    config = inject(ConfigService);
    /** The name of the application. */
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Its stage (`dev`, `pre`), shown next to the name; none in pro. */
    stage = input(null, ...(ngDevMode ? [{ debugName: "stage" }] : []));
    /** A Bootstrap Icon for the name. */
    icon = input('grid-3x3-gap-fill', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    nav = input([], ...(ngDevMode ? [{ debugName: "nav" }] : []));
    /** A line at the bottom of the menu: the version, a contact... */
    footer = input(null, ...(ngDevMode ? [{ debugName: "footer" }] : []));
    menuLabel = input('Sections', ...(ngDevMode ? [{ debugName: "menuLabel" }] : []));
    loginLabel = input('Sign in', ...(ngDevMode ? [{ debugName: "loginLabel" }] : []));
    logoutLabel = input('Sign out', ...(ngDevMode ? [{ debugName: "logoutLabel" }] : []));
    menuOpen = signal(false, ...(ngDevMode ? [{ debugName: "menuOpen" }] : []));
    user = this.auth.user;
    theme = signal(this.storedTheme(), ...(ngDevMode ? [{ debugName: "theme" }] : []));
    /** The menu, grouped by section, with only what the user may see. */
    sections = computed(() => {
        this.user();
        const groups = [];
        for (const item of this.nav()) {
            if (item.roles?.length && !this.auth.hasRole(...item.roles)) {
                continue;
            }
            const name = item.section ?? '';
            let group = groups.find((g) => g.name === name);
            if (!group) {
                group = { name, items: [] };
                if (name) {
                    groups.push(group);
                }
                else {
                    groups.unshift(group);
                }
            }
            group.items.push(item);
        }
        return groups;
    }, ...(ngDevMode ? [{ debugName: "sections" }] : []));
    initials = computed(() => {
        const u = this.user();
        const words = (u?.name || u?.username || '').split(/[\s._-]+/).filter(Boolean);
        return words.slice(0, 2).map((w) => w[0].toUpperCase()).join('');
    }, ...(ngDevMode ? [{ debugName: "initials" }] : []));
    /**
     * A role of the user in this application, as a hint of who it is: one named after the application (`<app>-<role>`,
     * the application being the client of config.json without its stage), else none.
     */
    role = computed(() => {
        const roles = this.user()?.roles ?? [];
        const app = this.application();
        return (app && roles.find((r) => r.startsWith(`${app}-`))) || '';
    }, ...(ngDevMode ? [{ debugName: "role" }] : []));
    application() {
        try {
            return this.config.config().keycloak.clientId.replace(/-(dev|pre)$/, '');
        }
        catch {
            return '';
        }
    }
    constructor() {
        effect(() => this.document.documentElement.setAttribute('data-bs-theme', this.theme()));
    }
    toggleTheme() {
        const next = this.theme() === 'dark' ? 'light' : 'dark';
        this.theme.set(next);
        try {
            this.document.defaultView?.localStorage.setItem(THEME_KEY, next);
        }
        catch {
            // a browser without storage (private mode): the mode lasts until the page is reloaded
        }
    }
    storedTheme() {
        try {
            const stored = this.document.defaultView?.localStorage.getItem(THEME_KEY);
            if (stored === 'dark' || stored === 'light') {
                return stored;
            }
            return this.document.defaultView?.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        catch {
            return 'light';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqShell, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqShell, isStandalone: true, selector: "rq-shell", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, stage: { classPropertyName: "stage", publicName: "stage", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, nav: { classPropertyName: "nav", publicName: "nav", isSignal: true, isRequired: false, transformFunction: null }, footer: { classPropertyName: "footer", publicName: "footer", isSignal: true, isRequired: false, transformFunction: null }, menuLabel: { classPropertyName: "menuLabel", publicName: "menuLabel", isSignal: true, isRequired: false, transformFunction: null }, loginLabel: { classPropertyName: "loginLabel", publicName: "loginLabel", isSignal: true, isRequired: false, transformFunction: null }, logoutLabel: { classPropertyName: "logoutLabel", publicName: "logoutLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="rq-shell">
      <header class="rq-shell-header">
        <button type="button" class="rq-shell-icon-button rq-shell-menu-button" [attr.aria-expanded]="menuOpen()"
                aria-controls="rq-shell-menu" aria-label="Menu" (click)="menuOpen.set(!menuOpen())">
          <i class="bi bi-list" aria-hidden="true"></i>
        </button>
        <a class="rq-shell-brand" routerLink="/">
          <i class="bi bi-{{ icon() }}" aria-hidden="true"></i>
          {{ title() }}
          @if (stage()) {
            <span class="rq-shell-stage">{{ stage() }}</span>
          }
        </a>
        <div class="rq-shell-actions">
          <button type="button" class="rq-shell-icon-button" (click)="toggleTheme()"
                  [attr.aria-label]="theme() === 'dark' ? 'Light mode' : 'Dark mode'">
            <i class="bi" [class.bi-moon-stars]="theme() === 'light'" [class.bi-sun]="theme() === 'dark'" aria-hidden="true"></i>
          </button>
          @if (user(); as u) {
            <span class="rq-shell-avatar" aria-hidden="true">{{ initials() }}</span>
            <span class="rq-shell-user">
              <span class="rq-shell-user-name d-block">{{ u.name || u.username }}</span>
              @if (role()) {
                <span class="rq-shell-user-role d-block">{{ role() }}</span>
              }
            </span>
            <button type="button" class="btn btn-rq-header" (click)="auth.logout()">{{ logoutLabel() }}</button>
          } @else {
            <button type="button" class="btn btn-rq-header" (click)="auth.login()">{{ loginLabel() }}</button>
          }
        </div>
      </header>
      <div class="rq-shell-body">
        @if (sections().length > 0) {
          <nav id="rq-shell-menu" class="rq-shell-sidebar" [class.rq-shell-sidebar-open]="menuOpen()" [attr.aria-label]="menuLabel()">
            @for (s of sections(); track s.name) {
              @if (s.name) {
                <div class="rq-shell-section">{{ s.name }}</div>
              }
              @for (item of s.items; track item.link) {
                <a class="rq-shell-link" [routerLink]="item.link" routerLinkActive="active" (click)="menuOpen.set(false)">
                  @if (item.icon) {
                    <i class="bi bi-{{ item.icon }}" aria-hidden="true"></i>
                  }
                  {{ item.label }}
                  @if (item.badge) {
                    <span class="rq-shell-badge">{{ item.badge }}</span>
                  }
                </a>
              }
            }
            @if (footer()) {
              <div class="rq-shell-footer">{{ footer() }}</div>
            }
          </nav>
        }
        <main class="rq-shell-main">
          <rq-notifications />
          <ng-content />
        </main>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: RqNotifications, selector: "rq-notifications" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqShell, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-shell',
                    imports: [RouterLink, RouterLinkActive, RqNotifications],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <div class="rq-shell">
      <header class="rq-shell-header">
        <button type="button" class="rq-shell-icon-button rq-shell-menu-button" [attr.aria-expanded]="menuOpen()"
                aria-controls="rq-shell-menu" aria-label="Menu" (click)="menuOpen.set(!menuOpen())">
          <i class="bi bi-list" aria-hidden="true"></i>
        </button>
        <a class="rq-shell-brand" routerLink="/">
          <i class="bi bi-{{ icon() }}" aria-hidden="true"></i>
          {{ title() }}
          @if (stage()) {
            <span class="rq-shell-stage">{{ stage() }}</span>
          }
        </a>
        <div class="rq-shell-actions">
          <button type="button" class="rq-shell-icon-button" (click)="toggleTheme()"
                  [attr.aria-label]="theme() === 'dark' ? 'Light mode' : 'Dark mode'">
            <i class="bi" [class.bi-moon-stars]="theme() === 'light'" [class.bi-sun]="theme() === 'dark'" aria-hidden="true"></i>
          </button>
          @if (user(); as u) {
            <span class="rq-shell-avatar" aria-hidden="true">{{ initials() }}</span>
            <span class="rq-shell-user">
              <span class="rq-shell-user-name d-block">{{ u.name || u.username }}</span>
              @if (role()) {
                <span class="rq-shell-user-role d-block">{{ role() }}</span>
              }
            </span>
            <button type="button" class="btn btn-rq-header" (click)="auth.logout()">{{ logoutLabel() }}</button>
          } @else {
            <button type="button" class="btn btn-rq-header" (click)="auth.login()">{{ loginLabel() }}</button>
          }
        </div>
      </header>
      <div class="rq-shell-body">
        @if (sections().length > 0) {
          <nav id="rq-shell-menu" class="rq-shell-sidebar" [class.rq-shell-sidebar-open]="menuOpen()" [attr.aria-label]="menuLabel()">
            @for (s of sections(); track s.name) {
              @if (s.name) {
                <div class="rq-shell-section">{{ s.name }}</div>
              }
              @for (item of s.items; track item.link) {
                <a class="rq-shell-link" [routerLink]="item.link" routerLinkActive="active" (click)="menuOpen.set(false)">
                  @if (item.icon) {
                    <i class="bi bi-{{ item.icon }}" aria-hidden="true"></i>
                  }
                  {{ item.label }}
                  @if (item.badge) {
                    <span class="rq-shell-badge">{{ item.badge }}</span>
                  }
                </a>
              }
            }
            @if (footer()) {
              <div class="rq-shell-footer">{{ footer() }}</div>
            }
          </nav>
        }
        <main class="rq-shell-main">
          <rq-notifications />
          <ng-content />
        </main>
      </div>
    </div>
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], stage: [{ type: i0.Input, args: [{ isSignal: true, alias: "stage", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], nav: [{ type: i0.Input, args: [{ isSignal: true, alias: "nav", required: false }] }], footer: [{ type: i0.Input, args: [{ isSignal: true, alias: "footer", required: false }] }], menuLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuLabel", required: false }] }], loginLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "loginLabel", required: false }] }], logoutLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "logoutLabel", required: false }] }] } });

/*
 * Public API of refresquito-angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthService, ConfigService, KeycloakAuthService, LoggerService, NotificationService, PlatformApiService, RQ_KEYCLOAK_FACTORY, RQ_OPTIONS, RQ_SILENT, RQ_SUPERSET_EMBED, RqDashboard, RqDocumentList, RqErrorHandler, RqFileUpload, RqFlowRuns, RqHasRole, RqHttpError, RqNotifications, RqShell, RqTaskInbox, authGuard, authInterceptor, errorInterceptor, formatSize, provideRefresquito, toRqHttpError };
//# sourceMappingURL=refresquito-angular.mjs.map
