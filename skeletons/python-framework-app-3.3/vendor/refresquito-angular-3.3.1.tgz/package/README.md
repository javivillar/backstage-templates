# refresquito-angular

Angular library of the Refresquito platform. It gives every application the same answers to the
same questions, so an application only writes its own screens:

| What | How |
|---|---|
| **Start-up** | `provideRefresquito()` in `app.config.ts` |
| **Runtime configuration** | `config.json` read at start-up (`ConfigService`): one build runs on any cluster |
| **Keycloak** | `AuthService` (user, roles, login, logout), `authGuard` for routes, `*rqHasRole` for templates |
| **HTTP** | The token is added to the calls to the API; a failed call throws an `RqHttpError` built from the `problem+json` of the API |
| **Messages for the user** | `NotificationService` and `<rq-notifications />`; HTTP errors are shown by themselves |
| **Logs** | `LoggerService`, with the level of `config.json` |
| **Platform blocks** (3.0) | `<rq-file-upload>`, `<rq-document-list>`, `<rq-task-inbox>` and `PlatformApiService`: files in its buckets or Alfresco sites, and the tasks of its processes, through its API |
| **Dashboards** (3.1) | `<rq-dashboard name="main">`: a Superset dashboard of the application, embedded |
| **Flow runs** (3.1) | `<rq-flow-runs>`: the latest runs of its flows (Activepieces), as they told the API how they ended |
| **Tests** | `refresquito-angular/testing`: `provideRefresquitoTesting()` and a fake `AuthService`, no Keycloak |

It pairs with [`refresquito-fastapi`](https://github.com/javivillar/refresquito-fastapi) on the API
side; the example application built with both is [`petstore`](https://github.com/javivillar/petstore).

## Install

```bash
npm install refresquito-angular keycloak-js
```

Angular 20 or later.

## An application

`public/config.json`, the only file that changes between clusters:

```json
{
  "apiUrl": "https://petstore.platform.example.io",
  "keycloak": { "url": "https://iam.platform.example.io", "realm": "RefresquitoTime", "clientId": "petstore" }
}
```

`apiUrl` can be `""` when the API is served on the same origin as the application.

```ts
// app.config.ts
export const appConfig: ApplicationConfig = {
  providers: [provideRouter(routes), provideRefresquito()],
};

// app.routes.ts
export const routes: Routes = [
  { path: 'pets', component: PetList, canActivate: [authGuard] },
  { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } },
  { path: 'forbidden', component: Forbidden },
];
```

```html
<rq-notifications />
@if (auth.user(); as user) {
  <span>{{ user.name }}</span> <button (click)="auth.logout()">Sign out</button>
} @else {
  <button (click)="auth.login()">Sign in</button>
}
<button *rqHasRole="'petstore-admin'" (click)="remove(pet)">Delete</button>
```

```ts
// a service: HttpClient as usual, the token and the error handling come with it
list() { return this.http.get<Page<Pet>>(`${this.config.apiUrl}/api/pets`); }

// a form: validation errors come field by field
save().subscribe({ error: (e: RqHttpError) => this.fieldErrors.set(e.fieldErrors) });
```

`provideRefresquito({ onLoad: 'login-required' })` asks for a login before showing anything.
`*rqHasRole` and `authGuard` only hide: what must not happen has to be refused by the API.

## Look (3.3)

One design for every application of Refresquito: Bootstrap 5 with the colours of the platform, the Inter font and
Bootstrap Icons, served by the application (no CDN), light and dark mode. In `angular.json` of the application:

```json
"styles": ["node_modules/refresquito-angular/styles/refresquito.scss"],
"stylePreprocessorOptions": { "sass": { "silenceDeprecations": ["import", "global-builtin", "color-functions", "mixed-decls"] } }
```

(the deprecations are Bootstrap 5.3's own use of Sass `@import`). Another colour: a `styles.scss` of the application with
`$rq-brand: #5b3cc4;` before `@import 'refresquito-angular/styles/refresquito';`.

The layout, around the pages:

```ts
protected readonly nav: RqNavItem[] = [
  { label: 'Pets', link: '/pets', icon: 'heart' },
  { label: 'My tasks', link: '/tasks', icon: 'check2-square', badge: this.inbox.count() },
  { label: 'Dashboard', link: '/dashboard', icon: 'bar-chart', section: 'Analysis', roles: ['petstore-admin'] },
];
```

```html
<rq-shell title="Petstore" [stage]="stage" icon="heart-fill" [nav]="nav" footer="Petstore 1.4.0">
  <router-outlet />
</rq-shell>
```

| | |
|---|---|
| Header | the name and icon of the application (to `/`), its stage (none in pro), light/dark, the user (initials, name, first role of the application), sign in / out |
| Menu | `RqNavItem`: `label`, `link`, `icon` (a Bootstrap Icon without `bi-`), `badge`, `section`, `roles` (shown only to them); the active route marked; on a phone, behind the button of the header |
| Main | `<rq-notifications />`, then the page |

Pages use Bootstrap as it is (`card`, `table`, `btn btn-primary`, `badge`, `form-control`...) and three classes of the
theme: `rq-page-header` (title, breadcrumb and `rq-page-actions`), `rq-stat` (a figure with `rq-stat-label` and
`rq-stat-value`). The components of the platform blocks below come styled; their `rq-*` classes are kept.

## Errors

A failed call throws an `RqHttpError`: `status`, `code` (the stable part, e.g. `pet_name_taken`),
`message`, `requestId` and `fieldErrors`. The user is told with a notification that carries the
request ID, except for validation errors (422), which belong next to their fields, and for
requests marked `context: new HttpContext().set(RQ_SILENT, true)`.

## Platform blocks

With refresquito-fastapi 3.0 the API of the application uses the blocks it declares (s3, dms, processes). Three
components show them, calling only that API with the token of the user, on paths that follow one contract:

| Call | Answer |
|---|---|
| `GET <path>` | the documents of a place: `[{id or key, name, size, mime_type or content_type, modified_at}]` |
| `POST <path>` | multipart, the file in `file`: upload one |
| `GET <path>/<id>` | the file itself, or `{"url": "<presigned URL>"}` to go to (S3) |
| `GET <tasks>` | the open tasks of the user: `[{id, name, due, ...}]` |
| `POST <tasks>/<id>/complete` | complete one (its variables as the JSON body) |

```html
<rq-file-upload path="/api/pets/7/documents" accept="application/pdf" (uploaded)="version.set(version() + 1)" />
<rq-document-list path="/api/pets/7/documents" [version]="version()" />
<rq-task-inbox path="/api/tasks" (completed)="refresh()" />
```

A download the API answers as a file is saved; one it answers with `{"url"}` (a presigned URL of S3) is opened as a
navigation, so S3 needs no CORS. Upload goes through the API too. They are unstyled: style their `rq-*` classes.
`PlatformApiService` makes the same calls without the components. The application template generates these API
paths for the blocks it marks.

## Dashboards (3.1)

```html
<rq-dashboard name="main" />
<rq-dashboard name="sales" path="/api/dashboards" height="800px" [hideTitle]="false" />
```

A dashboard of the application (block `dashboards`: Superset), embedded with Superset's embedded SDK (loaded only when a
dashboard is shown). The API of the application gives the guest token, `GET <path>/<name>/guest-token` answering
`{token, uuid, superset_url}` (`dashboards.guest_token(name, user)` of refresquito-fastapi 3.1), and again each time it
expires. Superset only lets the hosts of the platform frame it. In tests, replace the SDK:
`{ provide: RQ_SUPERSET_EMBED, useValue: async (options) => ... }`.

## Flow runs (3.1)

```html
<rq-flow-runs />
<rq-flow-runs flow="new-pet" [size]="5" />
```

The latest runs of the flows of the application (`GET <path>`, default `/api/flow-runs` of refresquito-fastapi 3.1 with
`create_app(flow_runs=...)`): flow, event, status (`started`, `succeeded`, `failed`), when, detail. Style the classes
`rq-flow-run-<status>`.

## Tests of an application

```ts
TestBed.configureTestingModule({
  providers: [provideRefresquitoTesting({ user: { username: 'ana', roles: ['petstore-admin'] } })],
});
const auth = TestBed.inject(FakeAuthService);
auth.signIn(null);                      // nobody signed in
const backend = TestBed.inject(HttpTestingController);   // HttpClient is the testing one
```

## Not here yet

Each piece enters when an application needs it: a layout shell, translations, and a generator of
the API client from OpenAPI (the petstore generates its types with `openapi-typescript`).
