import * as i0 from '@angular/core';
import { EnvironmentProviders } from '@angular/core';
import { AuthService, RqUser, RqConfig } from 'refresquito-angular';

declare const TEST_CONFIG: RqConfig;
/** An AuthService without Keycloak: the test decides who is signed in. */
declare class FakeAuthService extends AuthService {
    private readonly current;
    readonly user: i0.Signal<RqUser | null>;
    /** Where `login()` was asked to come back to, most recent last. */
    readonly logins: (string | undefined)[];
    logouts: number;
    /** What `token()` answers while somebody is signed in. */
    accessToken: string;
    /** Sign somebody in (or nobody, with null). */
    signIn(user: Partial<RqUser> | null): void;
    init(): Promise<void>;
    login(redirectUrl?: string): Promise<void>;
    logout(): Promise<void>;
    token(): Promise<string | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FakeAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FakeAuthService>;
}
interface RqTestingOptions {
    /** Who is signed in when the test starts. Default: nobody. */
    user?: Partial<RqUser> | null;
    /** Merged over `TEST_CONFIG`. */
    config?: Partial<RqConfig>;
}
/**
 * The framework for a test: the configuration is `TEST_CONFIG`, nobody talks to Keycloak and
 * HttpClient is the testing one, with the real interceptors.
 *
 *     TestBed.configureTestingModule({ providers: [provideRefresquitoTesting({ user: { roles: ['petstore-admin'] } })] });
 *     const auth = TestBed.inject(AuthService) as FakeAuthService;
 */
declare function provideRefresquitoTesting(options?: RqTestingOptions): EnvironmentProviders;

export { FakeAuthService, TEST_CONFIG, provideRefresquitoTesting };
export type { RqTestingOptions };
