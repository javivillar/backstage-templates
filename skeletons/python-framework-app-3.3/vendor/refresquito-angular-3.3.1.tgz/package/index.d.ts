import * as _angular_core from '@angular/core';
import { Signal, InjectionToken, ErrorHandler, EnvironmentProviders } from '@angular/core';
import Keycloak, { KeycloakConfig } from 'keycloak-js';
import { CanActivateFn } from '@angular/router';
import { HttpContextToken, HttpErrorResponse, HttpInterceptorFn, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as refresquito_angular from 'refresquito-angular';

/** The signed-in user, as the token of Keycloak describes it. */
interface RqUser {
    username: string;
    name?: string;
    email?: string;
    /** Realm roles plus the roles of the client of the application. */
    roles: string[];
}
/**
 * Who is using the application. The implementation talks to Keycloak; tests provide a fake one
 * (`provideRefresquitoTesting`), so components never import keycloak-js.
 */
declare abstract class AuthService {
    abstract readonly user: Signal<RqUser | null>;
    readonly isLoggedIn: Signal<boolean>;
    /** True if the user has any of these roles. */
    hasRole(...roles: string[]): boolean;
    abstract init(): Promise<void>;
    /** Send the browser to the login page of Keycloak, and back to `redirectUrl` (default: here). */
    abstract login(redirectUrl?: string): Promise<void>;
    abstract logout(redirectUrl?: string): Promise<void>;
    /** A token that is still valid (refreshed if it was about to expire), or null if nobody is signed in. */
    abstract token(): Promise<string | null>;
}
/** How the Keycloak client is built. Replaced in tests. */
declare const RQ_KEYCLOAK_FACTORY: InjectionToken<(config: KeycloakConfig) => Keycloak>;
declare class KeycloakAuthService extends AuthService {
    private readonly configuration;
    private readonly options;
    private readonly factory;
    private readonly log;
    private keycloak?;
    private readonly current;
    readonly user: Signal<RqUser | null>;
    init(): Promise<void>;
    login(redirectUrl?: string): Promise<void>;
    logout(redirectUrl?: string): Promise<void>;
    token(): Promise<string | null>;
    private client;
    private absolute;
    private read;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KeycloakAuthService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<KeycloakAuthService>;
}

/**
 * A route for signed-in users only, and optionally only for some roles:
 *
 *     { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } }
 *
 * Nobody signed in: the browser goes to Keycloak and comes back to the route. Signed in without
 * any of the roles: the route `data.forbiddenUrl`, or `/forbidden`.
 */
declare const authGuard: CanActivateFn;

/** What `config.json` holds: everything that changes from one cluster to another. */
interface RqConfig {
    /** Base URL of the API of the application, without the final slash. */
    apiUrl: string;
    keycloak: {
        /** `https://iam.<domain>` */
        url: string;
        realm: string;
        clientId: string;
    };
    /** `debug`, `info` (default), `warn` or `error`. */
    logLevel?: 'debug' | 'info' | 'warn' | 'error';
    /** Anything else the application wants to read at runtime. */
    [key: string]: unknown;
}
interface RqOptions {
    /** Where the configuration is served. Default: `config.json`, next to `index.html`. */
    configUrl?: string;
    /**
     * `check-sso` (default): the application opens for everybody and each route decides with
     * `authGuard`. `login-required`: nothing is shown before signing in.
     */
    onLoad?: 'check-sso' | 'login-required';
}
declare const RQ_OPTIONS: InjectionToken<RqOptions>;
/**
 * The configuration of the running application, read once at start-up from `config.json`. The
 * same build runs on any cluster: only that file changes.
 */
declare class ConfigService {
    private readonly options;
    private readonly value;
    /** The configuration. It throws if it is read before the application has started. */
    readonly config: _angular_core.Signal<RqConfig>;
    get apiUrl(): string;
    load(fetcher?: typeof fetch): Promise<RqConfig>;
    set(config: RqConfig): RqConfig;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfigService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ConfigService>;
}

/**
 * Renders its content only for users with one of the roles:
 *
 *     <button *rqHasRole="'petstore-admin'">Delete</button>
 *     <a *rqHasRole="['petstore-admin', 'petstore-viewer']" routerLink="/pets">Pets</a>
 *
 * It only hides: what must not happen is refused by the API.
 */
declare class RqHasRole {
    readonly rqHasRole: _angular_core.InputSignal<string | string[]>;
    private readonly auth;
    private readonly template;
    private readonly container;
    private shown;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqHasRole, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RqHasRole, "[rqHasRole]", never, { "rqHasRole": { "alias": "rqHasRole"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** An error answer of an API of the platform (RFC 9457, as refresquito-fastapi writes it). */
interface ProblemDetails {
    type?: string;
    title?: string;
    status: number;
    /** The stable part: what the application can act on. */
    code?: string;
    detail?: string;
    instance?: string;
    request_id?: string;
    /** Validation errors, field by field. */
    errors?: {
        field: string;
        message: string;
    }[];
    [key: string]: unknown;
}
/** What a failed call throws: the problem document, or the closest thing when the answer was not one. */
declare class RqHttpError extends Error {
    readonly status: number;
    readonly code: string;
    readonly problem: ProblemDetails | null;
    readonly cause_: HttpErrorResponse;
    constructor(status: number, code: string, message: string, problem: ProblemDetails | null, cause_: HttpErrorResponse);
    get requestId(): string | undefined;
    /** The message of each invalid field, by field name. */
    get fieldErrors(): Record<string, string>;
}
declare function toRqHttpError(response: HttpErrorResponse): RqHttpError;
/** Set it on a request whose errors the caller shows by itself: `context: new HttpContext().set(RQ_SILENT, true)`. */
declare const RQ_SILENT: HttpContextToken<boolean>;
/** Adds the token of the signed-in user to the calls to the API of the application, and to no other. */
declare const authInterceptor: HttpInterceptorFn;
/** Turns a failed call into an `RqHttpError` and tells the user, unless the request is `RQ_SILENT`. */
declare const errorInterceptor: HttpInterceptorFn;
/** Anything nobody caught: logged, and the user told that something failed. */
declare class RqErrorHandler implements ErrorHandler {
    private readonly log;
    private readonly notifications;
    handleError(error: unknown): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqErrorHandler, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<RqErrorHandler>;
}

type LogLevel = 'debug' | 'info' | 'warn' | 'error';
/** Console logs with a level and a context object, filtered by `logLevel` of the configuration. */
declare class LoggerService {
    private readonly configuration;
    debug(message: string, context?: object): void;
    info(message: string, context?: object): void;
    warn(message: string, context?: object): void;
    error(message: string, context?: object): void;
    private level;
    private write;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<LoggerService>;
}

interface RqNotification {
    id: number;
    kind: 'info' | 'success' | 'error';
    message: string;
    /** What to quote when asking for help: the `request_id` of the failed call. */
    reference?: string;
}
/** Messages for the user. Show them with `<rq-notifications />` or read `messages` yourself. */
declare class NotificationService {
    private next;
    private readonly list;
    readonly messages: _angular_core.Signal<RqNotification[]>;
    info(message: string): number;
    success(message: string): number;
    error(message: string, reference?: string): number;
    dismiss(id: number): void;
    clear(): void;
    private add;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<NotificationService>;
}
/**
 * The pending notifications, each with a button to dismiss it: Bootstrap alerts (styles/refresquito.scss); the
 * `rq-notification` classes are still there to restyle them.
 */
declare class RqNotifications {
    protected readonly notifications: NotificationService;
    protected readonly alertClass: Record<RqNotification['kind'], string>;
    protected readonly iconClass: Record<RqNotification['kind'], string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqNotifications, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqNotifications, "rq-notifications", never, {}, {}, never, never, true, never>;
}

/**
 * Everything of the framework, in `app.config.ts`:
 *
 *     providers: [provideRouter(routes), provideRefresquito()]
 *
 * Before the application starts it reads `config.json` and asks Keycloak who is signed in.
 * HttpClient comes configured: calls to the API carry the token, and errors are
 * `RqHttpError` and are shown to the user.
 */
declare function provideRefresquito(options?: RqOptions): EnvironmentProviders;

/**
 * Components for the platform blocks the application uses through its API (refresquito-fastapi 3.0): files in its
 * buckets (s3) or its Alfresco sites (dms), and the tasks of its processes (Camunda). They only call the API of the
 * application, with the token of the user (the API decides what each one may do), on paths that follow one contract:
 *
 *     GET  <path>                  the documents of a place: [{id | key, name, size, mime_type | content_type, modified_at}]
 *     POST <path>                  multipart, the file in `file`: upload one
 *     GET  <path>/<id>             download one: the file itself, or {"url": "<presigned URL>"} to go to
 *     GET  <tasks>                 the open tasks of the user: [{id, name, created, due, process_instance}]
 *     POST <tasks>/<id>/complete   complete one (JSON body: its variables)
 *
 * Styled by `refresquito-angular/styles/refresquito.scss` (Bootstrap 5); their `rq-*` classes are still there to
 * restyle them.
 */
/** A document as the API answers it: an Alfresco document (dms) or an S3 object (s3) of refresquito-fastapi. */
interface RqDocument {
    id?: string;
    key?: string;
    name?: string;
    size?: number | null;
    mime_type?: string | null;
    content_type?: string | null;
    modified_at?: string | null;
    last_modified?: string | null;
}
/** An open user task of a process (refresquito-fastapi `Task`). */
interface RqTask {
    id: string;
    name?: string | null;
    task?: string | null;
    process_instance?: string | null;
    assignee?: string | null;
    created?: string | null;
    due?: string | null;
}
/** The calls of the components, to use them without the components too. */
declare class PlatformApiService {
    private readonly http;
    private readonly config;
    url(path: string): string;
    documents(path: string): Promise<RqDocument[]>;
    /** Upload a file (multipart, field `file` by default), with its progress. */
    upload(path: string, file: File, field?: string): Observable<HttpEvent<unknown>>;
    /** Download: the file the API answers is saved; a {"url"} it answers (a presigned URL of S3) is opened. */
    download(path: string, filename?: string): Promise<void>;
    tasks(path: string): Promise<RqTask[]>;
    complete(path: string, taskId: string, variables?: Record<string, unknown>): Promise<unknown>;
    /** Go to a URL (a navigation: no CORS needed). */
    open(url: string): void;
    /** Save a blob as a file of the user. */
    save(blob: Blob, filename: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PlatformApiService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PlatformApiService>;
}
/** 1536 -> "1.5 KB". */
declare function formatSize(bytes: number | null | undefined): string;
/**
 * A button to upload files to the API of the application, with their progress:
 *
 *     <rq-file-upload path="/api/pets/7/documents" accept="application/pdf" (uploaded)="list.reload()" />
 */
declare class RqFileUpload {
    readonly path: _angular_core.InputSignal<string>;
    readonly field: _angular_core.InputSignal<string>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly multiple: _angular_core.InputSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    /** What the API answered, for each file uploaded. */
    readonly uploaded: _angular_core.OutputEmitterRef<unknown>;
    protected readonly progress: _angular_core.WritableSignal<number | null>;
    private readonly api;
    protected choose(event: Event): Promise<void>;
    /** Upload one file (what choosing it in the button does). */
    send(file: File): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqFileUpload, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqFileUpload, "rq-file-upload", never, { "path": { "alias": "path"; "required": true; "isSignal": true; }; "field": { "alias": "field"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "uploaded": "uploaded"; }, never, never, true, never>;
}
/**
 * The documents of a place of the API, each one a link that downloads it:
 *
 *     <rq-document-list #list path="/api/pets/7/documents" />
 */
declare class RqDocumentList {
    readonly path: _angular_core.InputSignal<string>;
    readonly empty: _angular_core.InputSignal<string>;
    /** Change it to read the list again (or call reload()). */
    readonly version: _angular_core.InputSignal<number>;
    protected readonly documents: _angular_core.WritableSignal<RqDocument[]>;
    protected readonly size: typeof formatSize;
    private readonly api;
    constructor();
    reload(): Promise<void>;
    protected idOf(d: RqDocument): string;
    /** The kind of file, for its icon: pdf, image, sheet or file. */
    protected kindOf(d: RqDocument): string;
    protected iconOf(d: RqDocument): string;
    protected nameOf(d: RqDocument): string;
    protected download(d: RqDocument): Promise<void>;
    private load;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqDocumentList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqDocumentList, "rq-document-list", never, { "path": { "alias": "path"; "required": true; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; "version": { "alias": "version"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * The open tasks of the signed-in user in the processes of the application, each one with a button to complete it:
 *
 *     <rq-task-inbox path="/api/tasks" (completed)="refresh()" />
 */
declare class RqTaskInbox {
    readonly path: _angular_core.InputSignal<string>;
    readonly empty: _angular_core.InputSignal<string>;
    readonly completeLabel: _angular_core.InputSignal<string>;
    readonly version: _angular_core.InputSignal<number>;
    /** The task just completed. */
    readonly completed: _angular_core.OutputEmitterRef<RqTask>;
    protected readonly tasks: _angular_core.WritableSignal<RqTask[]>;
    protected readonly busy: _angular_core.WritableSignal<string | null>;
    readonly count: _angular_core.Signal<number>;
    private readonly api;
    constructor();
    reload(): Promise<void>;
    complete(task: RqTask, variables?: Record<string, unknown>): Promise<void>;
    private load;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqTaskInbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqTaskInbox, "rq-task-inbox", never, { "path": { "alias": "path"; "required": false; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; "completeLabel": { "alias": "completeLabel"; "required": false; "isSignal": true; }; "version": { "alias": "version"; "required": false; "isSignal": true; }; }, { "completed": "completed"; }, never, never, true, never>;
}

/** What the API of the application answers for a guest token (refresquito-fastapi 3.1, `dashboards.guest_token`). */
interface RqGuestToken {
    token: string;
    /** The embedded dashboard it opens. */
    uuid: string;
    /** Where the browser reaches Superset. */
    superset_url: string;
}
/** How a dashboard is embedded: Superset's embedded SDK (replace it in tests with `{ provide: RQ_SUPERSET_EMBED, ... }`). */
type RqEmbed = (options: {
    id: string;
    supersetDomain: string;
    mountPoint: HTMLElement;
    fetchGuestToken: () => Promise<string>;
    dashboardUiConfig?: Record<string, unknown>;
}) => Promise<unknown>;
declare const RQ_SUPERSET_EMBED: InjectionToken<RqEmbed>;
/**
 * A dashboard of the application (Superset), embedded in its web. The API of the application gives the guest token
 * (`GET <path>/<name>/guest-token`, refresquito-fastapi 3.1), again each time it expires:
 *
 *     <rq-dashboard name="main" />
 *     <rq-dashboard name="sales" path="/api/dashboards" height="800px" [hideTitle]="false" />
 *
 * Superset only lets the hosts of the platform frame it, and only gives a token for a dashboard of the application.
 */
declare class RqDashboard {
    readonly name: _angular_core.InputSignal<string>;
    readonly path: _angular_core.InputSignal<string>;
    readonly height: _angular_core.InputSignal<string>;
    readonly hideTitle: _angular_core.InputSignal<boolean>;
    protected readonly error: _angular_core.WritableSignal<string | null>;
    private readonly mount;
    private readonly http;
    private readonly config;
    private readonly embed;
    private readonly log;
    constructor();
    /** The guest token of the dashboard, from the API of the application. */
    guestToken(): Promise<RqGuestToken>;
    show(): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqDashboard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqDashboard, "rq-dashboard", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "path": { "alias": "path"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "hideTitle": { "alias": "hideTitle"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** A run of a flow of the application (refresquito-fastapi 3.1, `GET /api/flow-runs`). */
interface RqFlowRun {
    id: string;
    flow: string;
    event: string | null;
    status: 'started' | 'succeeded' | 'failed' | string;
    detail: string | null;
    started_by: string | null;
    started_at: string;
    finished_at: string | null;
}
/**
 * The latest runs of the flows of the application (Activepieces), as the flows told the API how they ended:
 *
 *     <rq-flow-runs />
 *     <rq-flow-runs flow="new-pet" [size]="5" />
 *
 * A run still `started` long after it began is a flow that ended without telling.
 */
declare class RqFlowRuns {
    /** The colour of a status (Bootstrap's subtle badges): succeeded green, failed red, started blue. */
    protected badgeOf(status: string): string;
    readonly path: _angular_core.InputSignal<string>;
    readonly flow: _angular_core.InputSignal<string | null>;
    readonly size: _angular_core.InputSignal<number>;
    readonly empty: _angular_core.InputSignal<string>;
    readonly version: _angular_core.InputSignal<number>;
    protected readonly runs: _angular_core.WritableSignal<RqFlowRun[]>;
    private readonly http;
    private readonly config;
    constructor();
    reload(): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqFlowRuns, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqFlowRuns, "rq-flow-runs", never, { "path": { "alias": "path"; "required": false; "isSignal": true; }; "flow": { "alias": "flow"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; "version": { "alias": "version"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** An entry of the menu of `<rq-shell>`. */
interface RqNavItem {
    label: string;
    /** Route of the application, e.g. `/pets`. */
    link: string;
    /** A Bootstrap Icon, without its prefix: `heart`, `people`, `check2-square`... (icons.getbootstrap.com). */
    icon?: string;
    /** A small count next to the label (pending tasks...); none when null, undefined or 0. */
    badge?: number | string | null;
    /** The heading it goes under; entries without one go first. */
    section?: string;
    /** Shown only to the users with any of these roles. */
    roles?: string[];
}
type RqTheme = 'light' | 'dark';
/**
 * The layout every application of Refresquito shares (the stylesheet `refresquito-angular/styles/refresquito.scss`):
 * a header with the name of the application, its stage, the user and the way out; a menu; the notifications; and the
 * page, projected inside:
 *
 *     <rq-shell title="Petstore" stage="dev" [nav]="nav" footer="Petstore 1.4.0">
 *       <router-outlet />
 *     </rq-shell>
 *
 * Light and dark mode (Bootstrap's `data-bs-theme`), remembered in the browser. On a phone the menu opens with a button.
 */
declare class RqShell {
    protected readonly auth: AuthService;
    private readonly document;
    private readonly config;
    /** The name of the application. */
    readonly title: _angular_core.InputSignal<string>;
    /** Its stage (`dev`, `pre`), shown next to the name; none in pro. */
    readonly stage: _angular_core.InputSignal<string | null>;
    /** A Bootstrap Icon for the name. */
    readonly icon: _angular_core.InputSignal<string>;
    readonly nav: _angular_core.InputSignal<RqNavItem[]>;
    /** A line at the bottom of the menu: the version, a contact... */
    readonly footer: _angular_core.InputSignal<string | null>;
    readonly menuLabel: _angular_core.InputSignal<string>;
    readonly loginLabel: _angular_core.InputSignal<string>;
    readonly logoutLabel: _angular_core.InputSignal<string>;
    protected readonly menuOpen: _angular_core.WritableSignal<boolean>;
    protected readonly user: _angular_core.Signal<refresquito_angular.RqUser | null>;
    protected readonly theme: _angular_core.WritableSignal<RqTheme>;
    /** The menu, grouped by section, with only what the user may see. */
    protected readonly sections: _angular_core.Signal<{
        name: string;
        items: RqNavItem[];
    }[]>;
    protected readonly initials: _angular_core.Signal<string>;
    /**
     * A role of the user in this application, as a hint of who it is: one named after the application (`<app>-<role>`,
     * the application being the client of config.json without its stage), else none.
     */
    protected readonly role: _angular_core.Signal<string>;
    private application;
    constructor();
    toggleTheme(): void;
    private storedTheme;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RqShell, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RqShell, "rq-shell", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "stage": { "alias": "stage"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "nav": { "alias": "nav"; "required": false; "isSignal": true; }; "footer": { "alias": "footer"; "required": false; "isSignal": true; }; "menuLabel": { "alias": "menuLabel"; "required": false; "isSignal": true; }; "loginLabel": { "alias": "loginLabel"; "required": false; "isSignal": true; }; "logoutLabel": { "alias": "logoutLabel"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { AuthService, ConfigService, KeycloakAuthService, LoggerService, NotificationService, PlatformApiService, RQ_KEYCLOAK_FACTORY, RQ_OPTIONS, RQ_SILENT, RQ_SUPERSET_EMBED, RqDashboard, RqDocumentList, RqErrorHandler, RqFileUpload, RqFlowRuns, RqHasRole, RqHttpError, RqNotifications, RqShell, RqTaskInbox, authGuard, authInterceptor, errorInterceptor, formatSize, provideRefresquito, toRqHttpError };
export type { LogLevel, ProblemDetails, RqConfig, RqDocument, RqEmbed, RqFlowRun, RqGuestToken, RqNavItem, RqNotification, RqOptions, RqTask, RqTheme, RqUser };
