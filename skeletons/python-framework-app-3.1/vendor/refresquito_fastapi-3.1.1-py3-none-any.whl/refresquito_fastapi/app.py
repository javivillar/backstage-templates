"""create_app: a FastAPI application with everything of the framework already wired."""

from collections.abc import AsyncIterator, Callable, Sequence
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from typing import TYPE_CHECKING, Any, cast

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import metrics
from .auth import TokenVerifier
from .errors import install_error_handlers
from .health import Check, health_router
from .logging import RequestContextMiddleware, configure_logging
from .platform import Platform
from .settings import Settings

if TYPE_CHECKING:
    from .platform.flows import Flows

Lifespan = Callable[[FastAPI], AbstractAsyncContextManager[None]]


def create_app(
    settings: Settings | None = None,
    *,
    title: str | None = None,
    version: str = "0.0.0",
    routers: Sequence[APIRouter] = (),
    readiness_checks: dict[str, Check] | None = None,
    lifespan: Lifespan | None = None,
    token_verifier: TokenVerifier | None = None,
    database: Any = None,
    platform: Platform | None = None,
    flow_runs: Sequence[str] | None = None,
    **fastapi_options: Any,
) -> FastAPI:
    """Build the application of a service.

    It gets: JSON logs with a request ID, the audit trail apart from them, the error format,
    request metrics on /metrics, probes on /health, the token verifier of the Keycloak realm (if
    RQ_OIDC_ISSUER is set) and the database (if RQ_DATABASE_URL is set), each with its readiness
    check, and the platform blocks the application declares (refresquito_fastapi.platform), read
    from the environment the chart gives it, with /health/platform. `token_verifier`, `database` and
    `platform` replace the ones built from the settings: that is how tests plug theirs in. With
    `flow_runs` (the roles that may read them; needs the database and the block flows), the runs of the
    flows it triggers are kept (refresquito_fastapi.platform.flow_runs).
    """
    settings = settings or Settings()
    configure_logging(settings.log_level, settings.log_format, settings.app_name)

    checks: dict[str, Check] = dict(readiness_checks or {})
    if token_verifier is None and settings.oidc_issuer:
        token_verifier = TokenVerifier(
            settings.oidc_issuer,
            jwks_url=settings.oidc_jwks_url,
            audience=settings.oidc_audience,
            client_id=settings.oidc_client_id,
            ca_file=settings.oidc_ca_file,
            verify_audience=settings.oidc_verify_audience,
            trusted_clients=frozenset(c.strip() for c in settings.oidc_trusted_clients.split(",") if c.strip()),
        )
        checks.setdefault("oidc", token_verifier.ready)
    if database is None and settings.database_url:
        from .db import Database  # only with the [db] extra installed

        database = Database(settings.database_url)
    if database is not None:
        checks.setdefault("database", database.ping)
    if platform is None:
        platform = Platform.from_env()

    @asynccontextmanager
    async def run(app: FastAPI) -> AsyncIterator[None]:
        try:
            if lifespan is not None:
                async with lifespan(app):
                    yield
            else:
                yield
        finally:
            await platform.close()
            if database is not None:
                await database.dispose()

    app = FastAPI(title=title or settings.app_name, version=version, lifespan=run, **fastapi_options)
    app.state.settings = settings
    app.state.token_verifier = token_verifier
    app.state.database = database
    app.state.platform = platform

    install_error_handlers(app)
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,
            allow_methods=["*"],
            allow_headers=["*"],
            expose_headers=["X-Request-ID"],
        )
    # added last, so it is the outermost: it also sees what the other middleware answers
    app.add_middleware(RequestContextMiddleware, app_name=settings.app_name, audit_requests=settings.audit_requests)

    app.include_router(health_router(checks, platform))
    app.include_router(metrics.router)
    for router in routers:
        app.include_router(router)
    if flow_runs is not None:
        from .platform.flow_runs import FlowRunRecorder, flow_runs_router  # only with the extra db

        app.include_router(flow_runs_router(flow_runs))
        # without a database (the OpenAPI document of the app is built so) the routes are there and nothing is recorded
        if database is not None:
            recorder = FlowRunRecorder(database)
            if "flows" in platform:
                cast("Flows", platform.get("flows")).recorder = recorder
            app.state.flow_run_recorder = recorder
    return app
