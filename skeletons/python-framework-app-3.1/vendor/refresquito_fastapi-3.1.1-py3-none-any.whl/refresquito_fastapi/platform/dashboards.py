"""Block `dashboards`: the Superset dashboards the application brings in platform/dashboards/, from its code.

    from refresquito_fastapi.platform.dashboards import DashboardsDep

    @router.get("/dashboards")
    async def dashboards(dashboards: DashboardsDep, user: CurrentUser):
        return dashboards.list()                                # name, title, url in Superset

    @router.get("/dashboards/{name}/guest-token")
    async def guest_token(name: str, dashboards: DashboardsDep, user: CurrentUser):
        return await dashboards.guest_token(name, user)         # for <rq-dashboard> (refresquito-angular 3.1)

    @router.get("/stats/by-status")
    async def by_status(dashboards: DashboardsDep, user: CurrentUser):
        return await dashboards.data("pet", columns=["status"], metrics=["count"])

A dashboard is named by its slug without the application (`main` for the one named as the application); a dataset by
its table. The platform gives the API, as the Superset user app-<app> (owner of its dashboards, reader of its own
database only), what it needs: SUPERSET_DASHBOARDS (written once the dashboards are imported; until then nothing is
available: a 503 `dashboards_not_available`).

A guest token opens one embedded dashboard for a few minutes, as the user of the request; `rls` adds row level
security clauses (SQL) for that user. Superset only gives one for a dashboard the application owns. Each token is
audited.
"""

from __future__ import annotations

import builtins
import json
from collections.abc import Mapping, Sequence
from typing import Annotated, Any, Self

import httpx
from fastapi import Depends
from pydantic import BaseModel

from ..audit import audit
from ..auth import User
from ..errors import BadGatewayError, NotFoundError, ServiceUnavailableError
from . import Block, block_dependency, contract, register
from ._calls import BlockHttp


class Dashboard(BaseModel):
    name: str
    title: str
    id: int
    uuid: str            # of its embedded configuration: what <rq-dashboard> opens
    url: str             # the dashboard in Superset itself (people of the superset-* groups)


class GuestToken(BaseModel):
    token: str
    uuid: str            # the embedded dashboard it opens
    superset_url: str    # where the browser reaches Superset
    expires_in: int = 300


@register
class Dashboards(Block):
    name = "dashboards"

    def __init__(self, url: str, public_url: str, username: str, password: str, catalog: Mapping[str, Any] | None = None,
                 transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.public_url = public_url.rstrip("/")
        self.username, self.password = username, password
        self.catalog = dict(catalog or {})
        self.http = BlockHttp("dashboards", url, transport=transport)
        self._auth: dict[str, str] = {}   # the bearer token, the CSRF token and the session cookie of Superset

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        v = contract.read(env, "dashboards")
        try:
            catalog = json.loads(v.get("SUPERSET_DASHBOARDS") or "{}")
        except ValueError as exc:
            raise contract.PlatformConfigError(f"block dashboards: SUPERSET_DASHBOARDS is not JSON ({exc})") from exc
        return cls(v["SUPERSET_URL"], v["SUPERSET_PUBLIC_URL"], v["SUPERSET_USERNAME"], v["SUPERSET_PASSWORD"], catalog)

    # ---- what the platform says it has
    def list(self) -> list[Dashboard]:
        return [self._dashboard(name, d) for name, d in sorted((self.catalog.get("dashboards") or {}).items())]

    def get(self, name: str) -> Dashboard:
        dashboards = self.catalog.get("dashboards") or {}
        if not dashboards:
            raise ServiceUnavailableError("The dashboards of the application are not in Superset yet (the platform imports "
                                          "platform/dashboards/ and then gives the API SUPERSET_DASHBOARDS)",
                                          code="dashboards_not_available")
        if name not in dashboards:
            raise NotFoundError(f"The application has no dashboard {name} ({', '.join(sorted(dashboards))})",
                                code="dashboard_not_found")
        return self._dashboard(name, dashboards[name])

    def _dashboard(self, name: str, d: Mapping[str, Any]) -> Dashboard:
        return Dashboard(name=name, title=d.get("title") or name, id=d["id"], uuid=d["uuid"],
                         url=f"{self.public_url}/superset/dashboard/{d.get('slug') or d['id']}/")

    def dataset(self, table: str) -> int:
        datasets = self.catalog.get("datasets") or {}
        if table not in datasets:
            if not datasets:
                raise ServiceUnavailableError("The datasets of the application are not in Superset yet",
                                              code="dashboards_not_available")
            raise NotFoundError(f"Superset has no dataset {table} of the application ({', '.join(sorted(datasets))})",
                                code="dataset_not_found")
        return int(datasets[table])

    # ---- Superset, as app-<app>
    async def _login(self) -> None:
        response = await self.http.request("login", "POST", "/api/v1/security/login",
                                           json={"username": self.username, "password": self.password, "provider": "db"})
        if response.status_code != 200:
            raise BadGatewayError(f"Superset refused the account {self.username} ({response.status_code})",
                                  code="dashboards_rejected")
        auth = {"Authorization": f"Bearer {response.json()['access_token']}"}
        response = await self.http.request("csrf", "GET", "/api/v1/security/csrf_token/", headers=auth)
        if response.status_code != 200:
            raise BadGatewayError(f"Superset gave no CSRF token ({response.status_code})", code="dashboards_rejected")
        # the session cookie by hand: Superset marks it Secure, and inside the cluster it is reached over HTTP
        cookie = next((c.split(";", 1)[0] for c in response.headers.get_list("set-cookie") if c.startswith("session=")), "")
        self._auth = {**auth, "X-CSRFToken": response.json()["result"], "Referer": str(self.http.client.base_url),
                      **({"Cookie": cookie} if cookie else {})}

    async def _post(self, operation: str, path: str, body: Mapping[str, Any]) -> httpx.Response:
        if not self._auth:
            await self._login()
        response = await self.http.request(operation, "POST", path, json=body, headers=self._auth)
        if (response.status_code in (401, 422) and '"msg"' in response.text) or \
                (response.status_code == 400 and "csrf" in response.text.lower()):
            # its token (401 expired, 422 not valid: flask-jwt) or its session expired: log in again, once
            await self._login()
            response = await self.http.request(operation, "POST", path, json=body, headers=self._auth)
        return response

    async def guest_token(self, name: str, user: User, *, rls: Sequence[str] = ()) -> GuestToken:
        """A token that opens the embedded dashboard `name` for a few minutes, as `user`; `rls` are SQL clauses that
        filter its rows for that user."""
        dashboard = self.get(name)
        body = {"user": {"username": user.username, "first_name": user.name or user.username, "last_name": ""},
                "resources": [{"type": "dashboard", "id": dashboard.uuid}], "rls": [{"clause": c} for c in rls]}
        response = await self._post("guest_token", "/api/v1/security/guest_token/", body)
        if response.status_code != 200:
            raise BadGatewayError(f"Superset gave no guest token for {name} ({response.status_code}: {response.text[:200]})",
                                  code="dashboards_rejected")
        audit("dashboards.guest_token", resource=f"dashboard/{name}", rls=list(rls) or None)
        return GuestToken(token=response.json()["token"], uuid=dashboard.uuid, superset_url=self.public_url)

    async def data(self, table: str, *, metrics: Sequence[str | Mapping[str, Any]], columns: Sequence[str] = (),
                   filters: Sequence[Mapping[str, Any]] = (), order_by: Sequence[tuple[str, bool]] = (),
                   row_limit: int = 1000) -> builtins.list[dict[str, Any]]:
        """Rows of a query over a dataset of the application, as Superset computes them: `metrics` (saved metrics such as
        "count", or adhoc ones), grouped by `columns`, `filters` as Superset takes them ({"col", "op", "val"})."""
        body = {"datasource": {"id": self.dataset(table), "type": "table"}, "result_format": "json", "result_type": "full",
                "queries": [{"columns": list(columns), "metrics": list(metrics), "filters": list(filters),
                             "orderby": [list(o) for o in order_by], "row_limit": row_limit}]}
        response = await self._post("data", "/api/v1/chart/data", body)
        if response.status_code in (403, 404):
            raise NotFoundError(f"Superset has no dataset {table} for the application", code="dataset_not_found")
        if response.status_code != 200:
            raise BadGatewayError(f"Superset refused the query on {table} ({response.status_code}: {response.text[:200]})",
                                  code="dashboards_rejected")
        return response.json()["result"][0]["data"]

    async def check(self) -> None:
        await self._login()

    async def close(self) -> None:
        await self.http.close()


DashboardsDep = Annotated[Dashboards, Depends(block_dependency("dashboards"))]
