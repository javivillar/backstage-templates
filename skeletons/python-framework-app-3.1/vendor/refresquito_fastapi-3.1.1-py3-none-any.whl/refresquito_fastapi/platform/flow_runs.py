"""The runs of the flows of the application (block flows, 3.1), kept in its own database. Needs the extra `db`.

    app = create_app(settings, routers=[...], flow_runs=("petstore-viewer", "petstore-admin"))

With `flow_runs`, every flow the API triggers (`flows.trigger`, `flows.publish`) is a run: an id (sent to the flow in
the header X-Flow-Run), recorded `started` in the table `flow_run` (add it with a migration: `FlowRun` is a model of
`refresquito_fastapi.db.Base`). The flow tells how it ended as its last step:

    POST {{trigger['output']['headers']['x-platform-api']}}/flow-runs/{{trigger['output']['headers']['x-flow-run']}}
    X-Flow-Key: {{api_key['output']}}            (a Code step that returns the secret_text of {{connections['app-api-key']}})
    {"status": "succeeded", "detail": "..."}

A flow that fails before that step stays `started`: the runs say it did not end. `GET /api/flow-runs` lists them (the
roles given may read them); `<rq-flow-runs>` of refresquito-angular 3.1 shows them.
"""

from __future__ import annotations

import datetime as dt
from collections.abc import Sequence
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import DateTime, String, Text, func, select
from sqlalchemy.orm import Mapped, mapped_column

from ..auth import CurrentUser, require_roles
from ..db import Base, Database, SessionDep, paginate
from ..errors import NotFoundError
from ..pagination import Page, PageParamsDep
from .flows import FlowCaller

Status = Literal["started", "succeeded", "failed"]


class FlowRun(Base):
    __tablename__ = "flow_run"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    flow: Mapped[str] = mapped_column(String(80), index=True)
    event: Mapped[str | None] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(20), index=True)
    detail: Mapped[str | None] = mapped_column(Text)
    started_by: Mapped[str | None] = mapped_column(String(80))
    started_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True))


class FlowRunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    flow: str
    event: str | None
    status: str
    detail: str | None
    started_by: str | None
    started_at: dt.datetime
    finished_at: dt.datetime | None


class FlowRunReport(BaseModel):
    status: Literal["succeeded", "failed"]
    detail: str | None = Field(default=None, max_length=4000)


class FlowRunRecorder:
    """What Flows calls when it triggers a flow: the run, `started`, in the database of the application (a session of
    its own: a failed request does not lose it)."""

    def __init__(self, database: Database) -> None:
        self.database = database

    async def started(self, run_id: str, flow: str, event: str | None, user: str | None) -> None:
        async with self.database.sessions() as session:
            session.add(FlowRun(id=run_id, flow=flow, event=event, status="started", started_by=user))
            await session.commit()

    async def failed(self, run_id: str, detail: str) -> None:
        async with self.database.sessions() as session:
            run = await session.get(FlowRun, run_id)
            if run is not None:
                run.status, run.detail, run.finished_at = "failed", detail[:4000], dt.datetime.now(dt.UTC)
                await session.commit()


def flow_runs_router(readers: Sequence[str]) -> APIRouter:
    router = APIRouter(prefix="/api/flow-runs", tags=["flow runs"])
    reader = Depends(require_roles(*readers)) if readers else Depends(_signed_in)

    @router.get("", dependencies=[reader])
    async def list_flow_runs(session: SessionDep, params: PageParamsDep,
                             flow: Annotated[str | None, Query(description="Only the runs of this flow")] = None,
                             status: Annotated[Status | None, Query(description="Only the runs in this status")] = None,
                             ) -> Page[FlowRunOut]:
        statement = select(FlowRun).order_by(FlowRun.started_at.desc(), FlowRun.id)
        if flow:
            statement = statement.where(FlowRun.flow == flow)
        if status:
            statement = statement.where(FlowRun.status == status)
        return await paginate(session, statement, params)

    @router.post("/{run_id}")
    async def report_flow_run(run_id: str, body: FlowRunReport, caller: FlowCaller, session: SessionDep) -> FlowRunOut:
        """How a run ended, told by the flow itself (its last step)."""
        run = await session.get(FlowRun, run_id)
        if run is None:
            raise NotFoundError(f"There is no run {run_id} (the API starts the runs it records)", code="flow_run_not_found")
        run.status, run.detail, run.finished_at = body.status, body.detail, dt.datetime.now(dt.UTC)
        await session.flush()
        return FlowRunOut.model_validate(run)

    return router


async def _signed_in(user: CurrentUser) -> None:
    return None
