"""The contract between the platform and the framework: the environment the chart python-app-oneke gives the API of an
application for each platform block it declares (`platform:` of bootstrap/app-of-apps/apps/<name>.yaml), and nothing
else. The framework reads only these names; the chart renders exactly these.

The same contract is `charts/python-app-oneke/contract.json` of refresquito-services, checked there against what the
chart renders; `tests/platform-contract.json` here is a copy of it, checked against CONTRACT. A change of the contract
is a change of both repositories.

    python -m refresquito_fastapi.platform.contract        # the contract as JSON
"""

import json
import re
import sys
from collections.abc import Mapping
from dataclasses import dataclass, field

VERSION = 3


@dataclass(frozen=True)
class BlockEnv:
    """What one block gets: variables always there (`required`), variables that may be missing (`optional`), and one
    variable per item of the declaration (`pattern`, <NAME> being the item in capitals with `-` as `_`)."""

    required: tuple[str, ...] = ()
    optional: tuple[str, ...] = ()
    patterns: tuple[str, ...] = ()
    source: str = "env"            # env: in the Deployment; configmap: in a ConfigMap the provisioner writes
    notes: dict[str, str] = field(default_factory=dict)
    configmap: tuple[str, ...] = ()   # optional variables written by the provisioner to a ConfigMap the API reads


CONTRACT: dict[str, BlockEnv] = {
    "processes": BlockEnv(
        required=("CAMUNDA_URL", "CAMUNDA_USERNAME", "CAMUNDA_PASSWORD", "CAMUNDA_KEY_PREFIX"),
        notes={
            "CAMUNDA_URL": "the REST API of the engine, ending in /engine-rest",
            "CAMUNDA_KEY_PREFIX": "<app>- in pro, <app>-<stage>- in dev and pre: the ids of its processes and decisions",
        },
    ),
    "flows": BlockEnv(
        required=("ACTIVEPIECES_FLOW_KEY", "ACTIVEPIECES_CALLBACK_URL"),
        optional=("ACTIVEPIECES_EVENTS",),
        patterns=("ACTIVEPIECES_FLOW_<NAME>_URL",),
        configmap=("ACTIVEPIECES_FLOW_<NAME>_URL", "ACTIVEPIECES_EVENTS"),
        notes={
            "ACTIVEPIECES_FLOW_<NAME>_URL": "the webhook of the flow platform/flows/<name>.json, once it is imported",
            "ACTIVEPIECES_FLOW_KEY": "the key its flows send to call the API (X-Flow-Key), also the connection app-api-key "
                                     "of its project",
            "ACTIVEPIECES_CALLBACK_URL": "where its flows reach the API (given to each flow it triggers: header "
                                         "X-Platform-Api)",
            "ACTIVEPIECES_EVENTS": "JSON {event: [flow names]}: the flows each event of the application starts",
        },
    ),
    "s3": BlockEnv(
        required=("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_ENDPOINT_URL_S3", "AWS_DEFAULT_REGION", "S3_BUCKETS"),
        optional=("AWS_ENDPOINT_URL_S3_PUBLIC",),
        patterns=("S3_BUCKET_<NAME>",),
        notes={
            "S3_BUCKETS": "the full names of its buckets, comma separated",
            "S3_BUCKET_<NAME>": "the full name of the bucket <name> (<app>[-<stage>]-<name>)",
            "AWS_ENDPOINT_URL_S3_PUBLIC": "where a browser reaches S3 (presigned URLs); without it, the one of the cluster",
        },
    ),
    "dashboards": BlockEnv(
        required=("SUPERSET_URL", "SUPERSET_PUBLIC_URL", "SUPERSET_USERNAME", "SUPERSET_PASSWORD"),
        optional=("SUPERSET_DASHBOARDS",),
        configmap=("SUPERSET_DASHBOARDS",),
        notes={
            "SUPERSET_URL": "Superset inside the cluster, as the user app-<app>",
            "SUPERSET_PUBLIC_URL": "where a browser reaches Superset (embedded dashboards)",
            "SUPERSET_DASHBOARDS": "JSON: {dashboards: {<name>: {id, uuid (embedded), title, slug}}, datasets: "
                                   "{<table>: id}}, written by the provisioner once imported",
        },
    ),
    "dms": BlockEnv(
        required=("ALFRESCO_URL", "ALFRESCO_USERNAME", "ALFRESCO_PASSWORD", "ALFRESCO_SITES"),
        patterns=("ALFRESCO_SITE_<NAME>",),
        notes={
            "ALFRESCO_SITES": "the ids of its sites, comma separated",
            "ALFRESCO_SITE_<NAME>": "the id of the site <name> (<app>[-<stage>]-<name>)",
        },
    ),
}


class PlatformConfigError(RuntimeError):
    """The environment of a block is incomplete: a mistake of the deployment, said at start-up."""


def item_key(name: str) -> str:
    """How an item of the declaration appears in a variable: documents -> DOCUMENTS, new-pet -> NEW_PET."""
    return name.upper().replace("-", "_")


def _pattern(pattern: str) -> re.Pattern[str]:
    return re.compile("^" + re.escape(pattern).replace(re.escape("<NAME>"), "([A-Z0-9_]+)") + "$")


def items(env: Mapping[str, str], pattern: str) -> dict[str, str]:
    """The variables of a pattern: {"DOCUMENTS": "<value of S3_BUCKET_DOCUMENTS>"}."""
    regex = _pattern(pattern)
    return {m.group(1): value for name, value in env.items() if (m := regex.match(name)) and value}


def declared(env: Mapping[str, str], block: str) -> bool:
    """Whether the application declares the block: any of its variables is there."""
    spec = CONTRACT[block]
    return any(env.get(name) for name in spec.required) or any(items(env, p) for p in spec.patterns)


def read(env: Mapping[str, str], block: str) -> dict[str, str]:
    """The variables of a declared block; PlatformConfigError if a required one is missing."""
    spec = CONTRACT[block]
    missing = [name for name in spec.required if not env.get(name)]
    if missing:
        raise PlatformConfigError(
            f"block {block}: {', '.join(missing)} not set. The chart python-app-oneke sets them when the application "
            f"declares `platform.{block}`; outside the cluster set them by hand (.env)."
        )
    return {name: env[name] for name in (*spec.required, *spec.optional) if env.get(name)}


def as_json() -> dict[str, object]:
    return {
        "version": VERSION,
        "blocks": {
            name: {"required": list(spec.required), "optional": list(spec.optional), "patterns": list(spec.patterns),
                   "source": spec.source, "notes": spec.notes,
                   **({"configmap": list(spec.configmap)} if spec.configmap else {})}
            for name, spec in CONTRACT.items()
        },
    }


if __name__ == "__main__":
    json.dump(as_json(), sys.stdout, indent=2)
    sys.stdout.write("\n")
