"""Block `flows`: the flows the application brings in platform/flows/, in Activepieces.

    from refresquito_fastapi.platform.flows import FlowsDep

    @router.post("/pets", status_code=201)
    async def create_pet(data: PetIn, flows: FlowsDep, ...):
        ...
        await flows.trigger("new-pet", {"name": pet.name})                      # fire and forget
        answer = await flows.trigger("new-pet", {"name": pet.name}, wait=True)  # the answer of its step Return Response

A flow is named as its file: platform/flows/new-pet.json is "new-pet". Its webhook reaches the API as
ACTIVEPIECES_FLOW_NEW_PET_URL once the platform has imported and published it (a ConfigMap the provisioner writes,
the API restarts to read it): until then, or for a flow that does not exist, `trigger` is a 503 `flow_not_available`.
Triggering is audited with the user of the request.

3.1:
  - events: a flow file that says `"platform": {"events": ["pet.created"]}` is started by
    `await flows.publish("pet.created", {...})`, with every other flow that takes that event, without waiting for them
    (a flow that fails is logged; the request goes on);
  - flows that call the API: each flow it triggers gets the address of the API (header X-Platform-Api), and sends the
    key of the application back (header X-Flow-Key: {{api_key['output']}}, a Code step that returns the secret_text of the
    connection app-api-key); a route that a flow may call depends on `FlowCaller`.
"""

import hmac
import json
import uuid
from collections.abc import Mapping
from typing import Annotated, Any, Self
from urllib.parse import urlsplit

import httpx
import structlog
from fastapi import Depends, Request
from pydantic import BaseModel

from ..audit import audit
from ..auth import User
from ..errors import AppError, BadGatewayError, ServiceUnavailableError, UnauthorizedError
from . import Block, block_dependency, contract, register
from ._calls import BlockHttp

PATTERN = "ACTIVEPIECES_FLOW_<NAME>_URL"
log = structlog.get_logger(__name__)
WAIT_TIMEOUT = 60.0   # seconds a synchronous flow may take


class FlowAnswer(BaseModel):
    status: int
    body: Any = None      # JSON when the flow answers JSON, else its text
    run: str | None = None   # the id of the run (header X-Flow-Run): the flow tells how it ended with it


def flow_name(key: str) -> str:
    """NEW_PET -> new-pet."""
    return key.lower().replace("_", "-")


@register
class Flows(Block):
    name = "flows"

    def __init__(self, urls: Mapping[str, str], transport: httpx.AsyncBaseTransport | None = None, *, key: str = "",
                 callback_url: str = "", events: Mapping[str, list[str]] | None = None) -> None:
        self.urls = {flow_name(key): url for key, url in urls.items()}
        self.key, self.callback_url = key, callback_url
        self.events = {event: list(names) for event, names in (events or {}).items()}
        # where the runs are recorded (refresquito_fastapi.platform.flow_runs, create_app(flow_runs=...)); None: nowhere
        self.recorder: Any = None
        # one client for every webhook (they are all on the same Activepieces): absolute URLs
        self.http = BlockHttp("flows", "", timeout=WAIT_TIMEOUT, transport=transport)

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> Self:
        try:
            events = json.loads(env.get("ACTIVEPIECES_EVENTS") or "{}")
        except ValueError as exc:
            raise contract.PlatformConfigError(f"block flows: ACTIVEPIECES_EVENTS is not JSON ({exc})") from exc
        return cls(contract.items(env, PATTERN), key=env.get("ACTIVEPIECES_FLOW_KEY") or "",
                   callback_url=env.get("ACTIVEPIECES_CALLBACK_URL") or "", events=events)

    @classmethod
    def empty(cls) -> Self:
        """The block before the provisioner has given the API any webhook: every flow is not available yet."""
        return cls({})

    def names(self) -> list[str]:
        return sorted(self.urls)

    async def trigger(self, flow: str, data: Mapping[str, Any] | list[Any] | None = None, *, wait: bool = False,
                      headers: Mapping[str, str] | None = None, event: str | None = None) -> FlowAnswer:
        """Start a flow with `data` as the body of its webhook. With wait=True, wait for it and return what its step
        Return Response answers; without, Activepieces only acknowledges it."""
        url = self.urls.get(flow)
        if url is None:
            raise ServiceUnavailableError(
                f"The flow {flow} is not available: no {contract.item_key(flow).join(PATTERN.split('<NAME>'))}. Either "
                "the application does not declare platform.flows, or the platform has not imported "
                f"platform/flows/{flow}.json yet (the API gets its webhook once it is published).",
                code="flow_not_available",
            )

        def errors(response: httpx.Response) -> AppError | None:
            if response.status_code in (404, 410):
                return ServiceUnavailableError(f"Activepieces does not run the flow {flow} (disabled or not published)",
                                               code="flow_not_available")
            return None

        run = str(uuid.uuid4())
        sent = {**({"X-Platform-Api": self.callback_url} if self.callback_url else {}), "X-Flow-Run": run,
                **dict(headers or {})}
        if self.recorder is not None:
            await self.recorder.started(run, flow, event, structlog.contextvars.get_contextvars().get("user"))
        try:
            response = await self.http.request("trigger_sync" if wait else "trigger", "POST",
                                               url + ("/sync" if wait else ""), json=data if data is not None else {},
                                               headers=sent, errors=errors)
        except AppError as exc:
            if self.recorder is not None:
                await self.recorder.failed(run, f"not started: {exc.detail}")
            raise
        audit("flows.trigger", resource=f"flow/{flow}", wait=wait, status=response.status_code)
        if not wait and response.status_code >= 400:
            raise BadGatewayError(f"Activepieces refused the flow {flow} ({response.status_code})", code="flows_rejected")
        try:
            body: Any = response.json() if response.content else None
        except ValueError:
            body = response.text
        return FlowAnswer(status=response.status_code, body=body, run=run)

    async def publish(self, event: str, data: Mapping[str, Any] | None = None) -> list[str]:
        """Start every flow that takes the event (its file says `"platform": {"events": [...]}`), without waiting for them.
        A flow that cannot be started is logged and the others still are: what an event starts never fails the request.
        Returns the flows started."""
        started = []
        for name in self.events.get(event, []):
            try:
                await self.trigger(name, {"event": event, **dict(data or {})}, event=event)
                started.append(name)
            except AppError as exc:
                log.warning("flow_event_not_delivered", event_name=event, flow=name, code=exc.code, error=exc.detail)
        audit("flows.publish", resource=f"event/{event}", flows=started)
        return started

    def caller(self, presented: str | None) -> bool:
        """Whether the header X-Flow-Key a call carries is the key of the application: as it is, or as Activepieces
        renders the connection app-api-key in a header ({"type": "SECRET_TEXT", "secret_text": ...})."""
        if not self.key or not presented:
            return False
        value = presented
        if presented.lstrip().startswith("{"):
            try:
                value = str(json.loads(presented).get("secret_text") or "")
            except (ValueError, AttributeError):
                return False
        return hmac.compare_digest(value.encode(), self.key.encode())

    async def check(self) -> None:
        if not self.urls:
            return
        parts = urlsplit(next(iter(self.urls.values())))
        response = await self.http.request("flags", "GET", f"{parts.scheme}://{parts.netloc}/api/v1/flags")
        if response.status_code >= 400:
            raise RuntimeError(f"Activepieces answered {response.status_code}")

    async def close(self) -> None:
        await self.http.close()


FlowsDep = Annotated[Flows, Depends(block_dependency("flows"))]
FLOW_USER = User(sub="activepieces", username="flow", roles=frozenset({"flow"}))


async def flow_caller(request: Request, flows: FlowsDep) -> User:
    """A route that the flows of the application may call: the header X-Flow-Key must be the key of the application
    (401 `invalid_flow_key` otherwise). The caller is the user `flow` (what it writes is audited as it)."""
    if not flows.caller(request.headers.get("x-flow-key")):
        raise UnauthorizedError("This route is for the flows of the application: X-Flow-Key is missing or wrong",
                                code="invalid_flow_key")
    request.state.user = FLOW_USER
    structlog.contextvars.bind_contextvars(user=FLOW_USER.username)
    return FLOW_USER


FlowCaller = Annotated[User, Depends(flow_caller)]
