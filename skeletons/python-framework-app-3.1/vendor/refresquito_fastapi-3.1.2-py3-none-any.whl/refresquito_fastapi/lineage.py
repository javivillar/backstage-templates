"""Where the data of an endpoint comes from and goes to, in its OpenAPI, for the data catalog.

    from refresquito_fastapi import lineage

    @router.get("/api/orders", openapi_extra=lineage.source("table:order"))
    @router.post("/api/orders", openapi_extra=lineage.target("table:order"))
    @router.post("/api/orders/{id}/review", openapi_extra=lineage.source("table:order") | lineage.target("process:review"))

The OpenAPI of the service then says, for each operation, x-refresquito-source (what it reads) and
x-refresquito-target (what it writes). The platform publishes that OpenAPI in the gateway (block gateway) and the
ingestion of DataHub draws the lineage of the operation: from its sources, to its targets.

References: table:<table> (a table of the database of the service), process:<key>, flow:<file name>,
bucket:<bucket>, site:<site> (names as the service declares them in its platform blocks, without its own name).
"""

import re
from typing import Any

SOURCE, TARGET = "x-refresquito-source", "x-refresquito-target"
KINDS = ("table", "process", "flow", "bucket", "site")
_REFERENCE = re.compile(r"^(" + "|".join(KINDS) + r"):[A-Za-z0-9_][A-Za-z0-9_./-]*$")


def _checked(refs: tuple[str, ...]) -> list[str]:
    if not refs:
        raise ValueError("lineage: name at least one reference, e.g. table:order")
    wrong = [r for r in refs if not _REFERENCE.match(r)]
    if wrong:
        raise ValueError(f"lineage: {', '.join(map(repr, wrong))}: a reference is <kind>:<name>, "
                         f"kind one of {', '.join(KINDS)}")
    return sorted(set(refs))


def source(*refs: str) -> dict[str, Any]:
    """openapi_extra of an operation that reads these (x-refresquito-source)."""
    return {SOURCE: _checked(refs)}


def target(*refs: str) -> dict[str, Any]:
    """openapi_extra of an operation that writes these (x-refresquito-target)."""
    return {TARGET: _checked(refs)}
