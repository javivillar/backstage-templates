import * as i0 from '@angular/core';
import { Signal, InjectionToken, ErrorHandler, EnvironmentProviders } from '@angular/core';
import Keycloak, { KeycloakConfig } from 'keycloak-js';
import { CanActivateFn } from '@angular/router';
import { HttpContextToken, HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';

/** The signed-in user, as the token of Keycloak describes it. */
interface RqUser {
    username: string;
    name?: string;
    email?: string;
    /** Realm roles plus the roles of the client of the application. */
    roles: string[];
}
/**
 * Who is using the application. The implementation talks to Keycloak; tests provide a fake one
 * (`provideRefresquitoTesting`), so components never import keycloak-js.
 */
declare abstract class AuthService {
    abstract readonly user: Signal<RqUser | null>;
    readonly isLoggedIn: Signal<boolean>;
    /** True if the user has any of these roles. */
    hasRole(...roles: string[]): boolean;
    abstract init(): Promise<void>;
    /** Send the browser to the login page of Keycloak, and back to `redirectUrl` (default: here). */
    abstract login(redirectUrl?: string): Promise<void>;
    abstract logout(redirectUrl?: string): Promise<void>;
    /** A token that is still valid (refreshed if it was about to expire), or null if nobody is signed in. */
    abstract token(): Promise<string | null>;
}
/** How the Keycloak client is built. Replaced in tests. */
declare const RQ_KEYCLOAK_FACTORY: InjectionToken<(config: KeycloakConfig) => Keycloak>;
declare class KeycloakAuthService extends AuthService {
    private readonly configuration;
    private readonly options;
    private readonly factory;
    private readonly log;
    private keycloak?;
    private readonly current;
    readonly user: Signal<RqUser | null>;
    init(): Promise<void>;
    login(redirectUrl?: string): Promise<void>;
    logout(redirectUrl?: string): Promise<void>;
    token(): Promise<string | null>;
    private client;
    private absolute;
    private read;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeycloakAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KeycloakAuthService>;
}

/**
 * A route for signed-in users only, and optionally only for some roles:
 *
 *     { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } }
 *
 * Nobody signed in: the browser goes to Keycloak and comes back to the route. Signed in without
 * any of the roles: the route `data.forbiddenUrl`, or `/forbidden`.
 */
declare const authGuard: CanActivateFn;

/** What `config.json` holds: everything that changes from one cluster to another. */
interface RqConfig {
    /** Base URL of the API of the application, without the final slash. */
    apiUrl: string;
    keycloak: {
        /** `https://iam.<domain>` */
        url: string;
        realm: string;
        clientId: string;
    };
    /** `debug`, `info` (default), `warn` or `error`. */
    logLevel?: 'debug' | 'info' | 'warn' | 'error';
    /** Anything else the application wants to read at runtime. */
    [key: string]: unknown;
}
interface RqOptions {
    /** Where the configuration is served. Default: `config.json`, next to `index.html`. */
    configUrl?: string;
    /**
     * `check-sso` (default): the application opens for everybody and each route decides with
     * `authGuard`. `login-required`: nothing is shown before signing in.
     */
    onLoad?: 'check-sso' | 'login-required';
}
declare const RQ_OPTIONS: InjectionToken<RqOptions>;
/**
 * The configuration of the running application, read once at start-up from `config.json`. The
 * same build runs on any cluster: only that file changes.
 */
declare class ConfigService {
    private readonly options;
    private readonly value;
    /** The configuration. It throws if it is read before the application has started. */
    readonly config: i0.Signal<RqConfig>;
    get apiUrl(): string;
    load(fetcher?: typeof fetch): Promise<RqConfig>;
    set(config: RqConfig): RqConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfigService>;
}

/**
 * Renders its content only for users with one of the roles:
 *
 *     <button *rqHasRole="'petstore-admin'">Delete</button>
 *     <a *rqHasRole="['petstore-admin', 'petstore-viewer']" routerLink="/pets">Pets</a>
 *
 * It only hides: what must not happen is refused by the API.
 */
declare class RqHasRole {
    readonly rqHasRole: i0.InputSignal<string | string[]>;
    private readonly auth;
    private readonly template;
    private readonly container;
    private shown;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<RqHasRole, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RqHasRole, "[rqHasRole]", never, { "rqHasRole": { "alias": "rqHasRole"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** An error answer of an API of the platform (RFC 9457, as refresquito-fastapi writes it). */
interface ProblemDetails {
    type?: string;
    title?: string;
    status: number;
    /** The stable part: what the application can act on. */
    code?: string;
    detail?: string;
    instance?: string;
    request_id?: string;
    /** Validation errors, field by field. */
    errors?: {
        field: string;
        message: string;
    }[];
    [key: string]: unknown;
}
/** What a failed call throws: the problem document, or the closest thing when the answer was not one. */
declare class RqHttpError extends Error {
    readonly status: number;
    readonly code: string;
    readonly problem: ProblemDetails | null;
    readonly cause_: HttpErrorResponse;
    constructor(status: number, code: string, message: string, problem: ProblemDetails | null, cause_: HttpErrorResponse);
    get requestId(): string | undefined;
    /** The message of each invalid field, by field name. */
    get fieldErrors(): Record<string, string>;
}
declare function toRqHttpError(response: HttpErrorResponse): RqHttpError;
/** Set it on a request whose errors the caller shows by itself: `context: new HttpContext().set(RQ_SILENT, true)`. */
declare const RQ_SILENT: HttpContextToken<boolean>;
/** Adds the token of the signed-in user to the calls to the API of the application, and to no other. */
declare const authInterceptor: HttpInterceptorFn;
/** Turns a failed call into an `RqHttpError` and tells the user, unless the request is `RQ_SILENT`. */
declare const errorInterceptor: HttpInterceptorFn;
/** Anything nobody caught: logged, and the user told that something failed. */
declare class RqErrorHandler implements ErrorHandler {
    private readonly log;
    private readonly notifications;
    handleError(error: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RqErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RqErrorHandler>;
}

type LogLevel = 'debug' | 'info' | 'warn' | 'error';
/** Console logs with a level and a context object, filtered by `logLevel` of the configuration. */
declare class LoggerService {
    private readonly configuration;
    debug(message: string, context?: object): void;
    info(message: string, context?: object): void;
    warn(message: string, context?: object): void;
    error(message: string, context?: object): void;
    private level;
    private write;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}

interface RqNotification {
    id: number;
    kind: 'info' | 'success' | 'error';
    message: string;
    /** What to quote when asking for help: the `request_id` of the failed call. */
    reference?: string;
}
/** Messages for the user. Show them with `<rq-notifications />` or read `messages` yourself. */
declare class NotificationService {
    private next;
    private readonly list;
    readonly messages: i0.Signal<RqNotification[]>;
    info(message: string): number;
    success(message: string): number;
    error(message: string, reference?: string): number;
    dismiss(id: number): void;
    clear(): void;
    private add;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotificationService>;
}
/** The pending notifications, each with a button to dismiss it. Style the `rq-notification` classes. */
declare class RqNotifications {
    protected readonly notifications: NotificationService;
    static ɵfac: i0.ɵɵFactoryDeclaration<RqNotifications, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RqNotifications, "rq-notifications", never, {}, {}, never, never, true, never>;
}

/**
 * Everything of the framework, in `app.config.ts`:
 *
 *     providers: [provideRouter(routes), provideRefresquito()]
 *
 * Before the application starts it reads `config.json` and asks Keycloak who is signed in.
 * HttpClient comes configured: calls to the API carry the token, and errors are
 * `RqHttpError` and are shown to the user.
 */
declare function provideRefresquito(options?: RqOptions): EnvironmentProviders;

export { AuthService, ConfigService, KeycloakAuthService, LoggerService, NotificationService, RQ_KEYCLOAK_FACTORY, RQ_OPTIONS, RQ_SILENT, RqErrorHandler, RqHasRole, RqHttpError, RqNotifications, authGuard, authInterceptor, errorInterceptor, provideRefresquito, toRqHttpError };
export type { LogLevel, ProblemDetails, RqConfig, RqNotification, RqOptions, RqUser };
