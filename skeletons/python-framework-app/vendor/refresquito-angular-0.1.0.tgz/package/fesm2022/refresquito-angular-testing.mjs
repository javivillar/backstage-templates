import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import * as i0 from '@angular/core';
import { signal, Injectable, makeEnvironmentProviders, provideEnvironmentInitializer, inject } from '@angular/core';
import { AuthService, authInterceptor, errorInterceptor, ConfigService } from 'refresquito-angular';

const TEST_CONFIG = {
    apiUrl: 'http://api.test',
    keycloak: { url: 'http://iam.test', realm: 'test', clientId: 'test-app' },
};
/** An AuthService without Keycloak: the test decides who is signed in. */
class FakeAuthService extends AuthService {
    current = signal(null, ...(ngDevMode ? [{ debugName: "current" }] : []));
    user = this.current.asReadonly();
    /** Where `login()` was asked to come back to, most recent last. */
    logins = [];
    logouts = 0;
    /** What `token()` answers while somebody is signed in. */
    accessToken = 'test-token';
    /** Sign somebody in (or nobody, with null). */
    signIn(user) {
        this.current.set(user ? { username: 'test-user', roles: [], ...user } : null);
    }
    async init() { }
    async login(redirectUrl) {
        this.logins.push(redirectUrl);
    }
    async logout() {
        this.logouts++;
        this.current.set(null);
    }
    async token() {
        return this.current() ? this.accessToken : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: FakeAuthService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: FakeAuthService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: FakeAuthService, decorators: [{
            type: Injectable
        }] });
/**
 * The framework for a test: the configuration is `TEST_CONFIG`, nobody talks to Keycloak and
 * HttpClient is the testing one, with the real interceptors.
 *
 *     TestBed.configureTestingModule({ providers: [provideRefresquitoTesting({ user: { roles: ['petstore-admin'] } })] });
 *     const auth = TestBed.inject(AuthService) as FakeAuthService;
 */
function provideRefresquitoTesting(options = {}) {
    return makeEnvironmentProviders([
        FakeAuthService,
        { provide: AuthService, useExisting: FakeAuthService },
        provideHttpClient(withInterceptors([authInterceptor, errorInterceptor])),
        provideHttpClientTesting(),
        provideEnvironmentInitializer(() => {
            inject(ConfigService).set({ ...TEST_CONFIG, ...options.config });
            inject(FakeAuthService).signIn(options.user ?? null);
        }),
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { FakeAuthService, TEST_CONFIG, provideRefresquitoTesting };
//# sourceMappingURL=refresquito-angular-testing.mjs.map
