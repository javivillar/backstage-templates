import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, Injectable, input, TemplateRef, ViewContainerRef, effect, Directive, ChangeDetectionStrategy, Component, makeEnvironmentProviders, ErrorHandler, provideAppInitializer } from '@angular/core';
import Keycloak from 'keycloak-js';
import { Router } from '@angular/router';
import { HttpContextToken, HttpErrorResponse, provideHttpClient, withInterceptors } from '@angular/common/http';
import { from, switchMap, catchError, throwError } from 'rxjs';

const RQ_OPTIONS = new InjectionToken('RQ_OPTIONS', { factory: () => ({}) });
/**
 * The configuration of the running application, read once at start-up from `config.json`. The
 * same build runs on any cluster: only that file changes.
 */
class ConfigService {
    options = inject(RQ_OPTIONS);
    value = signal(null, ...(ngDevMode ? [{ debugName: "value" }] : []));
    /** The configuration. It throws if it is read before the application has started. */
    config = computed(() => {
        const config = this.value();
        if (!config) {
            throw new Error('The configuration is not loaded yet: is provideRefresquito() in the providers?');
        }
        return config;
    }, ...(ngDevMode ? [{ debugName: "config" }] : []));
    get apiUrl() {
        return this.config().apiUrl;
    }
    async load(fetcher = fetch) {
        const url = this.options.configUrl ?? 'config.json';
        const response = await fetcher(url, { cache: 'no-store' });
        if (!response.ok) {
            throw new Error(`Cannot read the configuration from ${url}: HTTP ${response.status}`);
        }
        return this.set((await response.json()));
    }
    set(config) {
        const missing = [
            !config?.apiUrl && config?.apiUrl !== '' ? 'apiUrl' : null,
            !config?.keycloak?.url ? 'keycloak.url' : null,
            !config?.keycloak?.realm ? 'keycloak.realm' : null,
            !config?.keycloak?.clientId ? 'keycloak.clientId' : null,
        ].filter(Boolean);
        if (missing.length) {
            throw new Error(`The configuration has no ${missing.join(', ')}`);
        }
        const clean = { ...config, apiUrl: config.apiUrl.replace(/\/+$/, '') };
        this.value.set(clean);
        return clean;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: ConfigService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const ORDER = ['debug', 'info', 'warn', 'error'];
/** Console logs with a level and a context object, filtered by `logLevel` of the configuration. */
class LoggerService {
    configuration = inject(ConfigService);
    debug(message, context) {
        this.write('debug', message, context);
    }
    info(message, context) {
        this.write('info', message, context);
    }
    warn(message, context) {
        this.write('warn', message, context);
    }
    error(message, context) {
        this.write('error', message, context);
    }
    level() {
        try {
            return this.configuration.config().logLevel ?? 'info';
        }
        catch {
            return 'info'; // before the configuration is loaded
        }
    }
    write(level, message, context) {
        if (ORDER.indexOf(level) < ORDER.indexOf(this.level())) {
            return;
        }
        const args = [`[${level}] ${message}`];
        if (context !== undefined) {
            args.push(context);
        }
        console[level](...args);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Who is using the application. The implementation talks to Keycloak; tests provide a fake one
 * (`provideRefresquitoTesting`), so components never import keycloak-js.
 */
class AuthService {
    isLoggedIn = computed(() => this.user() !== null, ...(ngDevMode ? [{ debugName: "isLoggedIn" }] : []));
    /** True if the user has any of these roles. */
    hasRole(...roles) {
        const mine = this.user()?.roles ?? [];
        return roles.some((role) => mine.includes(role));
    }
}
/** How the Keycloak client is built. Replaced in tests. */
const RQ_KEYCLOAK_FACTORY = new InjectionToken('RQ_KEYCLOAK_FACTORY', {
    factory: () => (config) => new Keycloak(config),
});
class KeycloakAuthService extends AuthService {
    configuration = inject(ConfigService);
    options = inject(RQ_OPTIONS);
    factory = inject(RQ_KEYCLOAK_FACTORY);
    log = inject(LoggerService);
    keycloak;
    current = signal(null, ...(ngDevMode ? [{ debugName: "current" }] : []));
    user = this.current.asReadonly();
    async init() {
        const { url, realm, clientId } = this.configuration.config().keycloak;
        this.keycloak = this.factory({ url, realm, clientId });
        this.keycloak.onAuthLogout = () => this.current.set(null);
        this.keycloak.onAuthRefreshSuccess = () => this.read();
        await this.keycloak.init({
            onLoad: this.options.onLoad ?? 'check-sso',
            pkceMethod: 'S256',
            // the session iframe needs third-party cookies, which browsers block
            checkLoginIframe: false,
        });
        this.read();
    }
    async login(redirectUrl) {
        await this.client().login({ redirectUri: this.absolute(redirectUrl) });
    }
    async logout(redirectUrl) {
        await this.client().logout({ redirectUri: this.absolute(redirectUrl ?? '/') });
    }
    async token() {
        const keycloak = this.client();
        if (!keycloak.authenticated) {
            return null;
        }
        try {
            await keycloak.updateToken(30);
        }
        catch (error) {
            // the session ended in Keycloak: nobody is signed in any more
            this.log.warn('The token could not be refreshed', { error: String(error) });
            this.current.set(null);
            return null;
        }
        return keycloak.token ?? null;
    }
    client() {
        if (!this.keycloak) {
            throw new Error('AuthService is used before the application has started');
        }
        return this.keycloak;
    }
    absolute(url) {
        return new URL(url ?? window.location.href, window.location.href).toString();
    }
    read() {
        const keycloak = this.client();
        const claims = keycloak.tokenParsed;
        if (!keycloak.authenticated || !claims) {
            this.current.set(null);
            return;
        }
        const clientId = this.configuration.config().keycloak.clientId;
        const roles = new Set([
            ...(claims.realm_access?.roles ?? []),
            ...(claims.resource_access?.[clientId]?.roles ?? []),
        ]);
        this.current.set({
            username: claims['preferred_username'] ?? claims.sub ?? '',
            name: claims['name'],
            email: claims['email'],
            roles: [...roles].sort(),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: KeycloakAuthService, decorators: [{
            type: Injectable
        }] });

/**
 * A route for signed-in users only, and optionally only for some roles:
 *
 *     { path: 'pets/new', component: PetForm, canActivate: [authGuard], data: { roles: ['petstore-admin'] } }
 *
 * Nobody signed in: the browser goes to Keycloak and comes back to the route. Signed in without
 * any of the roles: the route `data.forbiddenUrl`, or `/forbidden`.
 */
const authGuard = async (route, state) => {
    const auth = inject(AuthService);
    const router = inject(Router);
    if (!auth.isLoggedIn()) {
        await auth.login(state.url);
        return false;
    }
    const roles = route.data?.['roles'] ?? [];
    if (roles.length && !auth.hasRole(...roles)) {
        return router.parseUrl(route.data?.['forbiddenUrl'] ?? '/forbidden');
    }
    return true;
};

/**
 * Renders its content only for users with one of the roles:
 *
 *     <button *rqHasRole="'petstore-admin'">Delete</button>
 *     <a *rqHasRole="['petstore-admin', 'petstore-viewer']" routerLink="/pets">Pets</a>
 *
 * It only hides: what must not happen is refused by the API.
 */
class RqHasRole {
    rqHasRole = input.required(...(ngDevMode ? [{ debugName: "rqHasRole" }] : []));
    auth = inject(AuthService);
    template = inject((TemplateRef));
    container = inject(ViewContainerRef);
    shown = false;
    constructor() {
        effect(() => {
            const roles = this.rqHasRole();
            const allowed = this.auth.hasRole(...(Array.isArray(roles) ? roles : [roles]));
            if (allowed && !this.shown) {
                this.container.createEmbeddedView(this.template);
            }
            else if (!allowed && this.shown) {
                this.container.clear();
            }
            this.shown = allowed;
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqHasRole, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.33", type: RqHasRole, isStandalone: true, selector: "[rqHasRole]", inputs: { rqHasRole: { classPropertyName: "rqHasRole", publicName: "rqHasRole", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqHasRole, decorators: [{
            type: Directive,
            args: [{ selector: '[rqHasRole]' }]
        }], ctorParameters: () => [], propDecorators: { rqHasRole: [{ type: i0.Input, args: [{ isSignal: true, alias: "rqHasRole", required: true }] }] } });

/** Messages for the user. Show them with `<rq-notifications />` or read `messages` yourself. */
class NotificationService {
    next = 1;
    list = signal([], ...(ngDevMode ? [{ debugName: "list" }] : []));
    messages = this.list.asReadonly();
    info(message) {
        return this.add('info', message);
    }
    success(message) {
        return this.add('success', message);
    }
    error(message, reference) {
        return this.add('error', message, reference);
    }
    dismiss(id) {
        this.list.update((all) => all.filter((n) => n.id !== id));
    }
    clear() {
        this.list.set([]);
    }
    add(kind, message, reference) {
        const id = this.next++;
        this.list.update((all) => [...all, { id, kind, message, reference }]);
        return id;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: NotificationService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/** The pending notifications, each with a button to dismiss it. Style the `rq-notification` classes. */
class RqNotifications {
    notifications = inject(NotificationService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqNotifications, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.33", type: RqNotifications, isStandalone: true, selector: "rq-notifications", ngImport: i0, template: `
    @for (n of notifications.messages(); track n.id) {
      <div class="rq-notification rq-notification-{{ n.kind }}" [attr.role]="n.kind === 'error' ? 'alert' : 'status'">
        <span class="rq-notification-message">{{ n.message }}</span>
        @if (n.reference) {
          <small class="rq-notification-reference">Ref. {{ n.reference }}</small>
        }
        <button type="button" class="rq-notification-dismiss" aria-label="Dismiss" (click)="notifications.dismiss(n.id)">×</button>
      </div>
    }
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqNotifications, decorators: [{
            type: Component,
            args: [{
                    selector: 'rq-notifications',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @for (n of notifications.messages(); track n.id) {
      <div class="rq-notification rq-notification-{{ n.kind }}" [attr.role]="n.kind === 'error' ? 'alert' : 'status'">
        <span class="rq-notification-message">{{ n.message }}</span>
        @if (n.reference) {
          <small class="rq-notification-reference">Ref. {{ n.reference }}</small>
        }
        <button type="button" class="rq-notification-dismiss" aria-label="Dismiss" (click)="notifications.dismiss(n.id)">×</button>
      </div>
    }
  `,
                }]
        }] });

/** What a failed call throws: the problem document, or the closest thing when the answer was not one. */
class RqHttpError extends Error {
    status;
    code;
    problem;
    cause_;
    constructor(status, code, message, problem, cause_) {
        super(message);
        this.status = status;
        this.code = code;
        this.problem = problem;
        this.cause_ = cause_;
        this.name = 'RqHttpError';
    }
    get requestId() {
        return this.problem?.request_id ?? this.cause_.headers?.get('X-Request-ID') ?? undefined;
    }
    /** The message of each invalid field, by field name. */
    get fieldErrors() {
        return Object.fromEntries((this.problem?.errors ?? []).map((e) => [e.field, e.message]));
    }
}
function toRqHttpError(response) {
    const body = response.error;
    const problem = body && typeof body === 'object' && typeof body.status === 'number' ? body : null;
    if (problem) {
        return new RqHttpError(response.status, problem.code ?? 'error', problem.detail ?? problem.title ?? 'Error', problem, response);
    }
    if (response.status === 0) {
        return new RqHttpError(0, 'network_error', 'The server cannot be reached', null, response);
    }
    return new RqHttpError(response.status, 'error', response.statusText || `HTTP ${response.status}`, null, response);
}
/** Set it on a request whose errors the caller shows by itself: `context: new HttpContext().set(RQ_SILENT, true)`. */
const RQ_SILENT = new HttpContextToken(() => false);
/** Adds the token of the signed-in user to the calls to the API of the application, and to no other. */
const authInterceptor = (request, next) => {
    const api = inject(ConfigService).apiUrl;
    const auth = inject(AuthService);
    const toApi = api === '' ? !/^https?:\/\//.test(request.url) : request.url === api || request.url.startsWith(`${api}/`);
    if (!toApi || !auth.isLoggedIn()) {
        return next(request);
    }
    return from(auth.token()).pipe(switchMap((token) => next(token ? request.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : request)));
};
/** Turns a failed call into an `RqHttpError` and tells the user, unless the request is `RQ_SILENT`. */
const errorInterceptor = (request, next) => {
    const notifications = inject(NotificationService);
    const log = inject(LoggerService);
    return next(request).pipe(catchError((response) => {
        if (!(response instanceof HttpErrorResponse)) {
            return throwError(() => response);
        }
        const error = toRqHttpError(response);
        log.warn(`${request.method} ${request.url} failed`, { status: error.status, code: error.code, requestId: error.requestId });
        // validation errors belong next to their fields: the form shows them
        if (!request.context.get(RQ_SILENT) && error.status !== 422) {
            notifications.error(error.message, error.requestId);
        }
        return throwError(() => error);
    }));
};
/** Anything nobody caught: logged, and the user told that something failed. */
class RqErrorHandler {
    log = inject(LoggerService);
    notifications = inject(NotificationService);
    handleError(error) {
        if (error instanceof RqHttpError) {
            return; // the interceptor already logged it and told the user
        }
        this.log.error('Unexpected error', { error });
        this.notifications.error('Something went wrong');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: RqErrorHandler, decorators: [{
            type: Injectable
        }] });

/**
 * Everything of the framework, in `app.config.ts`:
 *
 *     providers: [provideRouter(routes), provideRefresquito()]
 *
 * Before the application starts it reads `config.json` and asks Keycloak who is signed in.
 * HttpClient comes configured: calls to the API carry the token, and errors are
 * `RqHttpError` and are shown to the user.
 */
function provideRefresquito(options = {}) {
    return makeEnvironmentProviders([
        { provide: RQ_OPTIONS, useValue: options },
        { provide: AuthService, useClass: KeycloakAuthService },
        { provide: ErrorHandler, useClass: RqErrorHandler },
        provideHttpClient(withInterceptors([authInterceptor, errorInterceptor])),
        provideAppInitializer(async () => {
            const config = inject(ConfigService);
            const auth = inject(AuthService);
            await config.load();
            await auth.init();
        }),
    ]);
}

/*
 * Public API of refresquito-angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthService, ConfigService, KeycloakAuthService, LoggerService, NotificationService, RQ_KEYCLOAK_FACTORY, RQ_OPTIONS, RQ_SILENT, RqErrorHandler, RqHasRole, RqHttpError, RqNotifications, authGuard, authInterceptor, errorInterceptor, provideRefresquito, toRqHttpError };
//# sourceMappingURL=refresquito-angular.mjs.map
